<?php

 
include_once ("sql.php");

if (isset($_GET['Jobid']))
{
    deleteJobbyJobid($_GET['Jobid']);
}

header('location: recruiterJobPost.php');

?>