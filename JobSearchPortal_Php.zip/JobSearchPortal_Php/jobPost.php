<?php


session_start();

require_once ("sql.php");
  require_once ("logincheckRecruiter.php");
  
  $name1 = $_SESSION['userInfo']['name'];
  $emailid = $_SESSION['userInfo']['emailid'];  
  
   $companyList= getCompany($emailid);
   
     
    
    if(count($companyList)===0)
    {
      echo "<script type='text/javascript'>alert('Please add a company by Add Company button before posting a job');</script>";   
      
       echo "<script>window.location = 'recruiterJobPost.php'</script>";
    }
    
    

if (isset($_POST['jobPost']))
{
 
    if($_POST['company']==="notselected")
    {
       echo "<script type='text/javascript'>alert('Please Select Company from DropDown');</script>";  
    }
    
    else
    {
 $emailid = $_SESSION['userInfo']['emailid'];  
    
    addJob($_POST['title'], $_POST['description'],  $_POST['department'],
     $_POST['company'], $emailid  );
    
    header('location: recruiterJobPost.php' );
    }
    
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Job Post</title>

    <!-- Bootstrap -->
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    
    <link href="Styles.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>
    <!--header-->
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="">Job Portal</a>
            </div>

            <ul class="nav navbar-nav navbar-right">
                    <li class="hello" >Hello <?php echo $name1; ?>  !!</li>
                    <li class="active"><a href="recruiterProfile.php">Profile<span class="sr-only">(current)</span></a></li>
                    <li class="active"><a href="logout.php">Sign Out<span class="sr-only">(current)</span></a></li>
            </ul>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="AboutUs.php">About Us<span class="sr-only">(current)</span></a></li>
                </ul>
                <form class="navbar-form navbar-left" method="get" action="http://www.google.com/search" target="_blank">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Search" name="q" maxlength="255" value="">
                    </div>
                    <button type="submit" class="btn btn-default" value="Google Search">Google search</button>
                </form>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>

    <br /><br /><br /><br />

                        <div class="container">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        Post Job!
                                    </h3>
                                </div>

                                <div class="panel-footer">
                                    <div class="row">

                                        <div class="col-xs-6 col-sm-6 col-md-6">
                                            <br />

                                            <form class="div1" method="post" action="jobPost.php">
                                                

                                                <table>
                                                    <tr>
                                                        <td><label>Title:</label></td>
                                                        <td><input type="text" class="input-block-level" name="title" placeholder="Job title" required="required"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp</td>
                                                        <td>&nbsp</td>
                                                    </tr>
                                                    <tr>
                                                        <td><label>Department</label></td>
                                                        <td><input type="text" class="input-block-level" name="department" placeholder="Department" required="required"></td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp</td>
                                                        <td>&nbsp</td>
                                                    </tr>
                                                    <tr>
                                                        <td><label>Company</label></td>
                                                        <td>
                                                            <select id="Company" name="company" class="form-control input-lg selectpicker">
                                                                <option selected value="notselected">Select Company</option>
                                                                <?php
                                                                $emailid = $_SESSION['userInfo']['emailid'];
                                                                $companyList= getCompany($emailid);
                                                                
                                                                 
                                                               
                                                                 foreach ($companyList as $company)
                                                                {
                                                                      extract($company);
                                                                  
                                                                  echo '<option value="'.$companyid.'" >'.$name.'</option>' ;
                                                                                                                                    
                                                                    
                                                                 }
                                                                                                                                  
                                                                        
                                                                ?>
                                                                
                                                                                                                                
                                                                
                                                                 
                                                            </select>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp</td>
                                                        <td>&nbsp</td>
                                                    </tr>
                                                    <tr>
                                                        <td><label>Job Description:&nbsp;</label></td>
                                                        <td>
                                                            <textarea name="description" rows="10" cols="30" maxlength="300" max="300" required="required"></textarea>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td>&nbsp</td>
                                                        <td>&nbsp</td>
                                                    </tr>
                                                </table>
                                                <button class="btn btn-large btn-primary" type="submit"  name="jobPost">Post Job</button>
                                                <button class="btn btn-large btn-primary" type="button" onclick="location.href='recruiterJobPost.php'"  name="cancel">Cancel</button>
                                            </form>

                                         <br />
                                            <br />
                                        </div>
                                    </div>
                                </div>
                            
                            </div>
                        </div>
    <br />    <br />    <br />    <br />
        
   
  
                     
                <footer>
                    <nav class="navbar navbar-inverse navbar-fixed-bottom">
                        <div class="container">
                            <address style="color:white; text-align:center">
                                Developed by: Akanksha Kashyap, Devanshu Upadhyay and Shreesh Maurya
                                <br />
                                Fort Collins, CO USA
                            </address>
                        </div>
                    </nav>
                </footer>

</body>
</html>

   