
<?php
 require_once ("sql.php");
 

if (isset($_POST['recruiterRegister']))
{
 
 $userlist=  getRecruiterUserByEmail($_POST['emailid']);
      
  
         
    if(count($userlist)===0)
    {
     addRecruiter($_POST['emailid'], $_POST['createpassword'],  $_POST['name'],
    $_POST['phonenumber'], $_POST['companyname'],$_POST['userrole'] );
    
     header('location: index.php' );
    }
    
 else {
     echo "<script type='text/javascript'>alert('EmailId/Username already exist, Use Different one');</script>";   
  
 }
    
    
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Recruiter Registration</title>

    <!-- Bootstrap -->
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

     
    <script src="passwordValidation.js"></script> 
    <link href="Styles.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>
   
    <!--header-->
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="">Job Portal</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="AboutUs.php">About Us<span class="sr-only">(current)</span></a></li>
                </ul>
                <form class="navbar-form navbar-left" method="get" action="http://www.google.com/search" target="_blank">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Search" name="q" maxlength="255" value="">
                    </div>
                    <button type="submit" class="btn btn-default" value="Google Search">Google search</button>
                </form>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>

    <br /><br /><br />

    <div class="container id4">


        <div class="row">

            <div class="col-sm-12">

                <div class="col-sm-8">

                    <form class="div1"  method="post" action="recruiterRegistration.php" >
                        <h2 class="form-signin-heading">Recruiter Registration</h2> <br>  
                        <table>
                            <tr>
                                <td></td><td></td>
                            </tr>
                            <tr>
                                <td><label>Email Id:</label></td>
                                <td><input type="email" class="input-block-level" name="emailid" placeholder="Email address" required="required" title="email id should be in the form abc@xyz.com"></td>
                            </tr>
                            <tr>
                                <td><label>Create Password:</label></td>
                                <td><input type="password" id="password" class="input-block-level" onchange="validatePassword()" name="createpassword" placeholder="Password" required pattern="[a-zA-Z0-9].{5,15}" title="Must be at least 5 to 15 characters with no special characters" value="<?php echo $_POST['createpassword']; ?>"></td>
                            </tr>
                            <tr>
                                <td><label>Re-Enter Password:</label></td>
                                <td><input type="password"  id="confirm_password" onkeyup="validatePassword()" class="input-block-level" name="reenterpassword" placeholder="Password" required pattern="[a-zA-Z0-9].{5,15}" title="Must be at least 5 to 15 characters with no special characters" value="<?php echo $_POST['reenterpassword']; ?>" ></td>
                            </tr>
                            <tr>
                                <td><label>Name:</label></td>
                                <td><input type="text" class="input-block-level" name="name" placeholder="Name" required pattern="([a-zA-Z]{1,30}\s*)+" title="only alphabets allowed" value="<?php echo $_POST['name']; ?>"></td>
                            </tr>
                            <tr>
                                <td><label>Phone Number:</label></td>
                                <td><input type="tel" pattern="^\d{10}$" required title=" xxxxxxxxxx (10 numbers)" maxlength="10" max="10" class="input-block-level" name="phonenumber" placeholder="Phone Number" value="<?php echo $_POST['phonenumber']; ?>" required pattern="[0-9]{10}" title="Phone number should contain only numbers"></td>
                            </tr>
                            <tr>
                                <td><label>Company name:</label></td>
                                <td><input type="text" class="input-block-level" name="companyname" value="<?php echo $_POST['companyname']; ?>" placeholder="Company Name" required pattern="([a-zA-Z]{1,30}\s*)+" title="only alphabets allowed"></td>
                            </tr>
                                
                            <input type="hidden" name="userrole" value="recruiter" />
                        </table>

                         
                        <br />
                        <button class="btn btn-large btn-primary" type="submit"  name="recruiterRegister">Register</button> &nbsp &nbsp
                         <a href="index.php" class=""> <button class="btn btn-large btn-primary" type="button"  name="signin">Sign In</button></a>
                     
                      

                    </form>

                </div>


            </div>
        </div>
    </div>

    <br /><br /><br />

    <!--Footer-->
    <footer>
        <nav class="navbar navbar-inverse navbar-fixed-bottom">
            <div class="container">
                <address style="color:white; text-align:center">
                    Developed by: Akanksha Kashyap, Devanshu Upadhyay and Shreesh Maurya
                    <br />
                    Fort Collins, CO USA
                </address>
            </div>
        </nav>
    </footer>


</body>
</html>


