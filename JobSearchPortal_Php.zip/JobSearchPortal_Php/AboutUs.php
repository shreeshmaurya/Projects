<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Job Search Portal</title>

    <!-- Bootstrap -->
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
 

    <link href="Styles.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>

    <!--header-->
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">Job Portal</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="AboutUs.php">About Us<span class="sr-only">(current)</span></a></li>
                </ul>
                <form class="navbar-form navbar-left" method="get" action="http://www.google.com/search" target="_blank">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Search" name="q" maxlength="255" value="">
                    </div>
                    <button type="submit" class="btn btn-default" value="Google Search">Google search</button>
                </form>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>

    <br /><br /><br /><br />

    </div>
    <div class="container id5">
    <div class="panel panel-default">
        <div class="panel-body">
            <img src="jobs_img.jpg" alt="Job search" style="width:1104px;height:228px;">
            <h1>Looking for a Job is More Challenging Than Ever</h1>
            <p>
                The job marketplace is flooded with highly skilled job seekers, all of which are competing 
                for the same limited number of positions, there are more applicants saturating the job market 
                every single day. To say that the applicant pool for most new positions out there is competitive 
                would be an understatement. Recruiters are screening thousands of applicants as thoroughly as possible. 
                While combing over resumes, they’re also using the power of the internet to make sure they are picking 
                the cream of the crop to fill these limited open positions. Combine this with the fact that some jobs 
                become open and available without the ability to ever hear about them, and you’re looking at a very 
                difficult situation. Job Seeker that take advantage of the tools and resources offered by Job Seekers 
                Website have found the best kept secret for increasing their chances of finding the job they deserve.
              </p>  
            <p>
                Job Search Websites connect thousands of men and women with top employment opportunities, 
                Universe Jobs immediately gives you access to the kind of open positions that you would 
                expect to find on other premium job search websites. The positions listed are extremely 
                attractive, because of the industries that they are in (Technology, Healthcare, Medical, 
                Business, Finance, etc), and the high quality companies represented.

            </p>

        </div>
    </div>
    </div>
<br> <br> <br>
    <!--Footer-->
    <footer>
        <nav class="navbar navbar-inverse navbar-fixed-bottom">
            <div class="container">
                <address style="color:white; text-align:center">
                    Developed by: Devanshu Upadhyay, Akanksha Kashyayp, and Shreesh Maurya
                    <br />
                    Fort Collins, CO USA
                </address>
            </div>
        </nav>
    </footer>

</body>
</html>


