<?php

 session_start();

if (!isset($_SESSION['userInfo']))
{
     
    header('location: index.php' );
    die();
}
 elseif(!($_SESSION['userInfo']['userrole']=='recruiter'))
 {
    
     header('location: index.php' );
   die();  
 }


?>