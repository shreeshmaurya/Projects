<?php

 include_once ("sql.php");

if ((isset($_GET['Emailid'])) && (isset($_GET['Jobid'])))
{
    applyJob($_GET['Emailid'],$_GET['Jobid']);
}

header('location: seekerJobSearch.php');

?>
