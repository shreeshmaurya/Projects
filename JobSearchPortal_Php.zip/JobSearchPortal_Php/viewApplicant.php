<?php
 include_once ("sql.php");
 session_start();
 require_once ("logincheckRecruiter.php");
 $name1 = $_SESSION['userInfo']['name'];
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>View Applicants</title>

    <!-- Bootstrap -->
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

     

    <link href="Styles.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>
    <!--header-->
    <nav class="navbar navbar-inverse navbar-fixed-top">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="">Job Portal</a>
            </div>

            <ul class="nav navbar-nav navbar-right">
                    <li class="hello" >Hello <?php echo $name1; ?>  !!</li>
                    <li class="active"><a href="recruiterProfile.php">Profile<span class="sr-only">(current)</span></a></li>
                    <li class="active"><a href="logout.php">Sign Out<span class="sr-only">(current)</span></a></li>
            </ul>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="AboutUs.php">About Us<span class="sr-only">(current)</span></a></li>
                </ul>
                <form class="navbar-form navbar-left" method="get" action="http://www.google.com/search" target="_blank">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Search" name="q" maxlength="255" value="">
                    </div>
                    <button type="submit" class="btn btn-default" value="Google Search">Google search</button>
                </form>
            </div><!-- /.navbar-collapse -->
        </div><!-- /.container-fluid -->
    </nav>

    <br /><br /><br /><br />

                        <div class="container">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        View Applicants!
                                    </h3>
                                </div>

                                <div class="panel-footer">
                                    <div class="row">

                                        <div class="col-xs-6 col-sm-6 col-md-6">
                                            <br />

                                            
                                            <?php


    
 $jobid=$_GET['Jobid'];
 
 
 $applicantsList=getApplicantsByJobid($jobid);
 
 if(count($applicantsList)===0)
 {
     echo "<H3> No Applicants Found For This Job!!</H3>" ; 
 }
         else {
         
                                                       $print = <<<ABC
<div class="tableStyle">
   <table   >
   
                                                                <tr   >
                                                                <th    >Applicant Name</td> 
                                                                <th   >Email ID</td> 
                                                                <th   >Phone Number</td> 
                                                                <th   >Highest Education</td>             
                                                                <th    >Date Applied</td>
                                                                  
             
        </tr>
    
ABC;
  
    foreach ($applicantsList as $resultrow)
    {
        extract($resultrow);
        
        
        $print .= <<<ABC
         <tr   >
                                                               <td    >$name</td> 
                                                               <td    >$emailid</td> 
                                                               <td   >$phonenumber</td> 
                                                               <td   > $highesteducation</td>             
                                                               <td    >$dateposted</td>
                                                                </tr>
      
ABC;
    }
    
    
     
$print .= <<<ABC
 </table>
  </div> 
 
ABC;

echo $print;   
 
         }
    
 

?>
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            <br/>
                                            <button class="btn btn-large btn-primary" type="button" onclick="location.href='recruiterJobPost.php'"  name="cancel">Cancel</button>


                                            <br />
                                            <br />
                                        </div>
                                    </div>
                                </div>
                            
                            </div>
                        </div>
    <br />    <br />    <br />    <br />
                        
                     
                <footer>
                    <nav class="navbar navbar-inverse navbar-fixed-bottom">
                        <div class="container">
                            <address style="color:white; text-align:center">
                               Developed by: Akanksha Kashyap, Devanshu Upadhyay and Shreesh Maurya
                                <br />
                                Fort Collins, CO USA
                            </address>
                        </div>
                    </nav>
                </footer>

</body>
</html>