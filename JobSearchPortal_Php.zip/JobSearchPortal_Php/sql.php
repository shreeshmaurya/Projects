<?php

 

require_once 'dbConnExec.php';




function getRecruiterUser($userLogin, $userPassword)
{
    $query = <<<STR
Select * From tbRecruiter Where emailid = '$userLogin'
and password = '$userPassword'
STR;
   
return executeQuery($query);
}



function getRecruiterUserByEmail($emailid)
{
    $query = <<<STR
Select * From tbRecruiter Where emailid = '$emailid'
STR;
   
return executeQuery($query);
}



function getSeekerUser($userLogin, $userPassword)
{
    $query = <<<STR
Select * From tbSeeker Where emailid = '$userLogin'
and password = '$userPassword'
STR;

return executeQuery($query);

}

function addRecruiter($emailid,$password,$name,$phonenumber,$companyname, $userrole)
{
    $query = <<<STR
Insert Into tbRecruiter(emailid,password,name,phonenumber,companyname, userrole)
Values('$emailid','$password','$name','$phonenumber','$companyname','$userrole')
STR;

return executeQuery($query);
}


function addSeeker($emailid,$password,$name,$phonenumber,$highesteducation, $userrole)
{
    $query = <<<STR
Insert Into tbSeeker(emailid,password,name,phonenumber,highesteducation, userrole)
Values('$emailid','$password','$name','$phonenumber','$highesteducation','$userrole')
STR;

return executeQuery($query);
}


function addJob($title,$description,$department,$companyid,$emailid)
{
    $query = <<<STR
Insert Into tbJobsPosted(title,description,department,companyid,emailid)
Values('$title','$description','$department','$companyid','$emailid')
STR;
  
return executeQuery($query);
}



function getCompany($emailid)
{
    $query = <<<STR
Select * From company Where emailid = '$emailid'
STR;
    
return executeQuery($query);
}



function getJobsPosted( )
{
    $query = <<<STR
Select * From tbJobsPosted
STR;
    
return executeQuery($query);
}



function getTitleOfJobsPosted( )
{
    $query = <<<STR
Select distinct title From tbJobsPosted
STR;
    
return executeQuery($query);
}

function getDepartmentOfJobsPosted( )
{
    $query = <<<STR
Select distinct department From tbJobsPosted
STR;
    
return executeQuery($query);
}



function getCompanyFromJobPosted()
{
    $query = <<<STR
Select name,companyid from company where companyid in (Select companyid From tbJobsPosted)
STR;
  
return executeQuery($query);
}



function getSearchedJobs($title,$companyid,$department,$description, $emailid)
{
     $query = <<<STR
SELECT [Team126DB].[dbo].[company].name, [Team126DB].[dbo].[tbJobsPosted].*
FROM [Team126DB].[dbo].[tbJobsPosted]
INNER JOIN [Team126DB].[dbo].[company]
ON [Team126DB].[dbo].[company].companyid=[Team126DB].[dbo].[tbJobsPosted].companyid
Where 0=0
STR;
    if ($title != '')
    {
    $query .= <<<STR
 And [Team126DB].[dbo].[tbJobsPosted].title like '%$title%'
STR;
    }
    if ($companyid != '')
    {
    $query .= <<<STR
 And [company].companyid = '$companyid'
STR;
    }
    if ($department != '')
    {
    $query .= <<<STR
  And [Team126DB].[dbo].[tbJobsPosted].department like '%$department%'
STR;
    }
     if ($description != '')
    {
    $query .= <<<STR
  And [Team126DB].[dbo].[tbJobsPosted].description like '%$description%'
STR;
    }
     $query .= <<<STR
  And jobid NOT in(select jobid from [Team126DB].[dbo].[tbJobsApplied] where emailid='$emailid ')
STR;
    
       
    return executeQuery($query);
}


function getSeekerDetailsByEmailID($emailid)
{
    
    $query = <<<STR
Select * From tbSeeker Where emailid = '$emailid'
STR;
 
return executeQuery($query);
}




function updateseeker($emailid,$createpassword, $name,$phonenumber,$highesteducation)
{
    
$createpassword = str_replace('\'', '\'\'', trim($createpassword));
    $name = str_replace('\'', '\'\'', trim($name));
    $phonenumber = str_replace('\'', '\'\'',trim($phonenumber));
     $highesteducation = str_replace('\'', '\'\'',trim($highesteducation));
    

    $query = <<<STR
Update tbSeeker
Set password = '$createpassword', name = '$name', phonenumber = '$phonenumber', highesteducation = '$highesteducation'
Where emailid = '$emailid'
STR;

return executeQuery($query);
}




Function applyJob($emailid, $jobid)
{
  
    $date=  date('m/d/Y', time());
    $query = <<<STR
insert into tbJobsApplied(jobid, emailid, dateposted) Values ('$jobid','$emailid','$date')
STR;

return executeQuery($query);
}



Function withdrawJob($emailid, $jobid)
{
   
    $query = <<<STR
delete from tbJobsApplied where emailid='$emailid' and jobid='$jobid'
STR;

return executeQuery($query);
}









function updaterecruiter($emailid,$password, $name,$phonenumber,$companyname)
{
    
$password = str_replace('\'', '\'\'', trim($password));
    $name = str_replace('\'', '\'\'', trim($name));
    $phonenumber = str_replace('\'', '\'\'',trim($phonenumber));
     $companyname = str_replace('\'', '\'\'',trim($companyname));
    

    $query = <<<STR
Update tbRecruiter
Set password = '$password', name = '$name', phonenumber = '$phonenumber', companyname = '$companyname'
Where emailid = '$emailid'
STR;
echo $query;
    
return executeQuery($query);
}



function addCompany($name,$description,$emailid)
{
    $query = <<<STR
Insert Into company(name,description,emailid)
Values('$name','$description','$emailid')
STR;
   
return executeQuery($query);
}

Function getAppliedJobs($emailid1)
{
    $query = <<<STR
SELECT [Team126DB].[dbo].[tbJobsPosted].*, [Team126DB].[dbo].[tbJobsApplied].dateposted,[Team126DB].[dbo].[company].name
FROM [Team126DB].[dbo].[tbJobsPosted]
INNER JOIN [Team126DB].[dbo].[tbJobsApplied] 
ON [Team126DB].[dbo].[tbJobsApplied].jobid=[Team126DB].[dbo].[tbJobsPosted].jobid INNER JOIN [Team126DB].[dbo].[company] ON [Team126DB].[dbo].[company].companyid=[Team126DB].[dbo].[tbJobsPosted].companyid where [Team126DB].[dbo].[tbJobsApplied].emailid='$emailid1';
STR;
    
   return executeQuery($query); 
}



Function getJobsPostedbyEmailid($emailid1)
{
    $query = <<<STR
SELECT [Team126DB].[dbo].[company].name, [Team126DB].[dbo].[tbJobsPosted].*
FROM [Team126DB].[dbo].[tbJobsPosted]
INNER JOIN [Team126DB].[dbo].[company]
ON [Team126DB].[dbo].[company].companyid=[Team126DB].[dbo].[tbJobsPosted].companyid where [Team126DB].[dbo].[tbJobsPosted].emailid='$emailid1'
STR;
    
   return executeQuery($query); 
}


Function getApplicantsByJobid($jobid)
{
     $query = <<<STR
             SELECT [Team126DB].[dbo].[tbJobsApplied].jobid, [Team126DB].[dbo].[tbJobsApplied].dateposted,[Team126DB].[dbo].[tbSeeker].*
FROM [Team126DB].[dbo].[tbSeeker]
INNER JOIN [Team126DB].[dbo].[tbJobsApplied]
ON [Team126DB].[dbo].[tbJobsApplied].emailid=[Team126DB].[dbo].[tbSeeker].emailid where jobid ='$jobid';
STR;
    
   return executeQuery($query); 
}

Function deleteJobbyJobid($jobid)
{
    $query1 = <<<STR
             delete from tbJobsApplied where jobid = '$jobid' 
STR;
    
    executeQuery($query1);
    
     $query2 = <<<STR
             delete from tbJobsPosted where jobid = '$jobid' 
STR;
    
   return executeQuery($query2);
}



Function getJobbyJobid($jobid)
{
  
     $query = <<<STR
Select * From tbJobsPosted where jobid = '$jobid'
STR;
    
return executeQuery($query);

}




Function editJobbyJobid($title,$description,$department,$companyid,$jobid)
{
  $title = str_replace('\'', '\'\'', trim($title));
  $description = str_replace('\'', '\'\'', trim($description));
  $department = str_replace('\'', '\'\'',trim($department));
  $companyid = str_replace('\'', '\'\'',trim($companyid));
  $jobid = str_replace('\'', '\'\'',trim($jobid));
    

    $query = <<<STR
Update tbJobsPosted
Set title = '$title', description = '$description', department = '$department', companyid = '$companyid'
Where jobid = '$jobid'
STR;
echo $query;
    
return executeQuery($query);

}



?>