﻿'Copyright (c) 2009-2016 Dan Turk

#Region "Class / File Comment Header block"
'Program:            Banking
'File:               ClsCustomer.vb
'Author:             shreesh maurya
'Description:        implements business logic of customer class
'Date:               updated: 9 dec 2016
'                    14 nov 2016
'Tier:               Business logic
'Exceptions:         None
'Exception-Handling: None
'Events:             None
'Event-Handling:     None
#End Region 'Class / File Comment Header block

#Region "Option / Imports"
Option Explicit On      'Must declare variables before using them
Option Strict On        'Must perform explicit data type conversions
#End Region 'Option / Imports

Public Class Customer

#Region "Attributes"
    '******************************************************************
    'Attributes + Module-level Constants+Variables
    '******************************************************************


    '********** Module-level variables

    Private mCustId As String
    Private mCustName As String
    Private mBirthDate As Date
    Private mRefDate As Date
    Private mNumTxn As Integer
    Private mAge As Integer
    Private mIsChild As Boolean
    Private mTransaction As Transaction


#End Region 'Attributes

#Region "Constructors"
    '******************************************************************
    'Constructors
    '******************************************************************


    '********** Special constructor(s)
    '             - typically constructors have parameters 
    '               that are used to initialize attributes


    'special constructor for initializing variables of this class
    Public Sub New(
        ByVal pCustId As String,
        ByVal pCustName As String,
        ByVal pBirthDate As Date)


        _custId = pCustId
        _custName = pCustName
        _birthDate = pBirthDate
        _calculateAge()

    End Sub 'New

    Public Sub New(
        ByVal pCustId As String,
        ByVal pCustName As String,
        ByVal pBirthDate As Date,
        ByVal pRefDate As Date)


        _custId = pCustId
        _custName = pCustName
        _birthDate = pBirthDate
        _calculateAge(pRefDate)
        _refDate = pRefDate

    End Sub 'New

    '********** Copy constructor(s)
    '             - one parameter, an object of the same class

#End Region 'Constructors

#Region "Get/Set Methods"
    '******************************************************************
    'Get/Set Methods
    '******************************************************************


    '********** Public Get/Set Methods
    '             - call private get/set methods to implement

    Public Property custId As String
        Get
            Return _custId
        End Get
        Set(pValue As String)
            _custId = pValue
        End Set
    End Property

    Public Property custName As String
        Get
            Return _custName
        End Get
        Set(pValue As String)
            _custName = pValue
        End Set
    End Property

    Public Property birthDate As Date
        Get
            Return _birthDate
        End Get
        Set(pValue As Date)
            _birthDate = pValue
        End Set
    End Property

    Public Property refdate As Date
        Get
            Return _refdate
        End Get
        Set(pValue As Date)
            _refdate = pValue
        End Set
    End Property

    Public Property numTxn As Integer
        Get
            Return _numTxn
        End Get
        Set(pValue As Integer)
            _numTxn = pValue
        End Set
    End Property


    Public Property transaction As Transaction
        Get
            Return _transaction
        End Get
        Set(pValue As Transaction)
            _transaction = pValue
        End Set
    End Property

    Public Property age As Integer
        Get
            Return _age
        End Get
        Set(pValue As Integer)
            _age = pValue
        End Set
    End Property

    Public Property isChild As Boolean
        Get
            Return _isChild
        End Get
        Set(pValue As Boolean)
            _isChild = pValue
        End Set
    End Property



    '********** Private Get/Set Methods
    '             - access attributes, begin name with underscore (_)

    Private Property _custId As String
        Get
            Return mCustId
        End Get
        Set(pValue As String)
            mCustId = pValue
        End Set
    End Property

    Private Property _custName As String
        Get
            Return mCustName
        End Get
        Set(pValue As String)
            mCustName = pValue
        End Set
    End Property

    Private Property _birthDate As Date
        Get
            Return mBirthDate
        End Get
        Set(pValue As Date)
            mBirthDate = pValue
        End Set
    End Property

    Private Property _refDate As Date
        Get
            Return mRefDate
        End Get
        Set(pValue As Date)
            mRefDate = pValue
        End Set
    End Property

    Private Property _numTxn As Integer
        Get
            Return mNumTxn
        End Get
        Set(pValue As Integer)
            mNumTxn = pValue
        End Set
    End Property


    Private Property _transaction As Transaction
        Get
            Return mTransaction
        End Get
        Set(pValue As Transaction)
            mTransaction = pValue
        End Set
    End Property


    Private Property _age As Integer
        Get
            Return mAge
        End Get
        Set(pValue As Integer)
            mAge = pValue
        End Set
    End Property

    Private Property _isChild As Boolean
        Get
            Return mIsChild
        End Get
        Set(pValue As Boolean)
            mIsChild = pValue
        End Set
    End Property

#End Region 'Get/Set Methods

#Region "Behavioral Methods"
    '******************************************************************
    'Behavioral Methods
    '******************************************************************

    '********** Public Non-Shared Behavioral Methods

    Public Overrides Function ToString() As String

        Return _toString()

    End Function 'ToString()

    '********** Private Non-Shared Behavioral Methods

    'ToString implementation for this class
    Private Function _toString() As String

        Dim tmpStr As String

        tmpStr = "( Customer : " _
            & "customer id='" & _custId & "'" _
            & ",customer name='" & _custName & "'" _
            & ", birth date='" & _birthDate.ToString & "'" _
             & ", Age is='" & _age.ToString & "'" _
              & ", is Child='" & _isChild.ToString & "'" _
         & " )"



        Return tmpStr

    End Function '_toString()

    'it calculates age and sets value of ischild
    Private Function _calculateAge() As Long

        Dim numOfDay As Long
        Dim refDate As Date = Date.Now()


        numOfDay = DateDiff(DateInterval.Day, _birthDate, refDate)
        _age = CInt(numOfDay / 365)

        If _age < 13 Then
            _isChild = True
        Else
            _isChild = False
        End If

    End Function

    Private Function _calculateAge(ByRef refDate As Date) As Long

        Dim numOfDay As Long

        numOfDay = DateDiff(DateInterval.Day, _birthDate, refDate)
        _age = CInt(numOfDay / 365)

        If _age < 13 Then
            _isChild = True
        Else
            _isChild = False
        End If

    End Function

#End Region 'Behavioral Methods

#Region "Event Procedures"
    '******************************************************************
    'Event Procedures
    '******************************************************************

    'No Event Procedures are currently defined.


#End Region 'Event Procedures

#Region "Events"
    '******************************************************************
    'Events
    '******************************************************************

    'No Events are currently defined.


#End Region 'Events

End Class 'ClsCustomer
