﻿'Copyright (c) 2009-2016 Dan Turk

#Region "Class / File Comment Header block"
'Program:            Banking
'File:               ClsTransaction.vb
'Author:             shreesh maurya
'Description:        implements business logic of transaction class
'Date:               14 nov 2016
'                    updated: 9 dec 2016
'Tier:               Business logic
'Exceptions:         None
'Exception-Handling: None
'Events:             None
'Event-Handling:     None
#End Region 'Class / File Comment Header block

#Region "Option / Imports"
Option Explicit On      'Must declare variables before using them
Option Strict On        'Must perform explicit data type conversions
#End Region 'Option / Imports

Public Class Transaction

#Region "Attributes"
    '******************************************************************
    'Attributes + Module-level Constants+Variables
    '******************************************************************


    '********** Module-level variables

    Private mTxnId As String
    Private mTxnLine As String
    Private mType As TransactionType
    Private mAmount As Decimal
    Private mDateTime As Date

    Private mAccountId As String
    Private mAccountIdTo As String
    Private mCustId As String
    Private mTxnIdPrefix As String
    Private mTxnIdStart As String
    Private mTxnLineIdPrefix As String
    Private mTxnLineIdStart As String

    Private mFromTxnLineId As String
    Private mToTxnLineId As String



#End Region 'Attributes

#Region "Constructors"
    '******************************************************************
    'Constructors
    '******************************************************************

    '********** Special constructor(s)
    '             - typically constructors have parameters 
    '               that are used to initialize attributes

    'special constructor for initializing variable of this class
    Public Sub New(
        ByVal pTxnId As String,
        ByVal pTxnLine As String,
        ByVal pType As TransactionType,
        ByVal pAmount As Decimal,
        ByVal pDateTime As Date,
        ByVal pAccountId As String,
        ByVal pAccountIdTo As String,
        ByVal pCustId As String,
        ByVal pTxnIdPrefix As String,
        ByVal pTxnIdStart As String,
        ByVal pTxnLineIdPrefix As String,
        ByVal pTxnLineIdStart As String
                                  )

        _txnId = pTxnId
        _txnLine = pTxnLine
        _type = pType
        _amount = pAmount
        _dateTime = pDateTime
        _accountId = pAccountId
        _accountIdTo = pAccountIdTo
        _custId = pCustId
        _txnIdPrefix = pTxnIdPrefix
        _txnIdStart = pTxnIdStart
        _txnLineIdPrefix = pTxnLineIdPrefix
        _txnLineIdStart = pTxnLineIdStart



    End Sub 'New

    Public Sub New(
        ByVal pTxnId As String,
                ByVal pType As TransactionType,
        ByVal pAmount As Decimal,
        ByVal pDateTime As Date,
        ByVal pAccountId As String,
        ByVal pAccountIdTo As String,
        ByVal pCustId As String,
        ByVal pTxnIdPrefix As String,
        ByVal pTxnIdStart As String,
        ByVal pTxnLineIdPrefix As String,
        ByVal pTxnLineIdStart As String,
         ByVal pFromTxnLineId As String,
        ByVal pToTxnLineId As String
                                  )

        _txnId = pTxnId

        _type = pType
        _amount = pAmount
        _dateTime = pDateTime
        _accountId = pAccountId
        _accountIdTo = pAccountIdTo
        _custId = pCustId
        _txnIdPrefix = pTxnIdPrefix
        _txnIdStart = pTxnIdStart
        _txnLineIdPrefix = pTxnLineIdPrefix
        _txnLineIdStart = pTxnLineIdStart
        _fromTxnLineIdt = pFromTxnLineId
        _toTxnLineId = pToTxnLineId



    End Sub 'New

    Public Sub New(
        ByVal pTxnId As String,
        ByVal pTxnLine As String,
        ByVal pType As TransactionType,
        ByVal pAmount As Decimal,
        ByVal pDateTime As Date,
        ByVal pAccountId As String,
         ByVal pCustId As String
                                  )

        _txnId = pTxnId
        _txnLine = pTxnLine
        _type = pType
        _amount = pAmount
        _dateTime = pDateTime
        _accountId = pAccountId
        _custId = pCustId

    End Sub 'New

    '********** Copy constructor(s)
    '             - one parameter, an object of the same class

#End Region 'Constructors

#Region "Get/Set Methods"
    '******************************************************************
    'Get/Set Methods
    '******************************************************************

    'No Get/Set Methods are currently defined.

    '********** Public Get/Set Methods
    '             - call private get/set methods to implement

    Public Property txnId As String
        Get
            Return _txnId
        End Get
        Set(pValue As String)
            _txnId = pValue
        End Set
    End Property

    Public Property txnLine As String
        Get
            Return _txnLine
        End Get
        Set(pValue As String)
            _txnLine = pValue
        End Set
    End Property

    Public Property type As TransactionType
        Get
            Return _type
        End Get
        Set(pValue As TransactionType)
            _type = pValue
        End Set
    End Property

    Public Property amount As Decimal
        Get
            Return _amount
        End Get
        Set(pValue As Decimal)
            _amount = pValue
        End Set
    End Property

    Public Property dateTime As Date
        Get
            Return _dateTime
        End Get
        Set(pValue As Date)
            _dateTime = pValue
        End Set
    End Property


    Public Property accountId As String
        Get
            Return _accountId
        End Get
        Set(pValue As String)
            _accountId = pValue
        End Set
    End Property

    Public Property accountIdTo As String
        Get
            Return _accountIdTo
        End Get
        Set(pValue As String)
            _accountIdTo = pValue
        End Set
    End Property

    Public Property custId As String
        Get
            Return _custId
        End Get
        Set(pValue As String)
            _custId = pValue
        End Set
    End Property

    Public Property txnIdPrefix As String
        Get
            Return _txnIdPrefix
        End Get
        Set(pValue As String)
            _txnIdPrefix = pValue
        End Set
    End Property

    Public Property txnIdStart As String
        Get
            Return _txnIdStart
        End Get
        Set(pValue As String)
            _txnIdStart = pValue
        End Set
    End Property

    Public Property txnLineIdPrefix As String
        Get
            Return _txnLineIdPrefix
        End Get
        Set(pValue As String)
            _txnLineIdPrefix = pValue
        End Set
    End Property

    Public Property txnLineIdStart As String
        Get
            Return _txnLineIdStart
        End Get
        Set(pValue As String)
            _txnLineIdStart = pValue
        End Set
    End Property

    Public Property fromTxnLineIdt As String
        Get
            Return _fromTxnLineIdt
        End Get
        Set(pValue As String)
            _fromTxnLineIdt = pValue
        End Set
    End Property

    Public Property toTxnLineId As String
        Get
            Return _toTxnLineId
        End Get
        Set(pValue As String)
            _toTxnLineId = pValue
        End Set
    End Property





    '********** Private Get/Set Methods
    '             - access attributes, begin name with underscore (_)

    Private Property _txnId As String
        Get
            Return mTxnId
        End Get
        Set(pValue As String)
            mTxnId = pValue
        End Set
    End Property

    Private Property _txnLine As String
        Get
            Return mTxnLine
        End Get
        Set(pValue As String)
            mTxnLine = pValue
        End Set
    End Property

    Private Property _type As TransactionType
        Get
            Return mType
        End Get
        Set(pValue As TransactionType)
            mType = pValue
        End Set
    End Property

    Private Property _amount As Decimal
        Get
            Return mAmount
        End Get
        Set(pValue As Decimal)
            mAmount = pValue
        End Set
    End Property

    Private Property _dateTime As Date
        Get
            Return mDateTime
        End Get
        Set(pValue As Date)
            mDateTime = pValue
        End Set
    End Property

    Private Property _accountId As String
        Get
            Return mAccountId
        End Get
        Set(pValue As String)
            mAccountId = pValue
        End Set
    End Property

    Private Property _accountIdTo As String
        Get
            Return mAccountIdTo
        End Get
        Set(pValue As String)
            mAccountIdTo = pValue
        End Set
    End Property

    Private Property _custId As String
        Get
            Return mCustId
        End Get
        Set(pValue As String)
            mCustId = pValue
        End Set
    End Property

    Private Property _txnIdPrefix As String
        Get
            Return mTxnIdPrefix
        End Get
        Set(pValue As String)
            mTxnIdPrefix = pValue
        End Set
    End Property

    Private Property _txnIdStart As String
        Get
            Return mTxnIdStart
        End Get
        Set(pValue As String)
            mTxnIdStart = pValue
        End Set
    End Property

    Private Property _txnLineIdPrefix As String
        Get
            Return mTxnLineIdPrefix
        End Get
        Set(pValue As String)
            mTxnLineIdPrefix = pValue
        End Set
    End Property

    Private Property _txnLineIdStart As String
        Get
            Return mTxnLineIdStart
        End Get
        Set(pValue As String)
            mTxnLineIdStart = pValue
        End Set
    End Property

    Private Property _fromTxnLineIdt As String
        Get
            Return mFromTxnLineId
        End Get
        Set(pValue As String)
            mFromTxnLineId = pValue
        End Set
    End Property

    Private Property _toTxnLineId As String
        Get
            Return mToTxnLineId
        End Get
        Set(pValue As String)
            mToTxnLineId = pValue
        End Set
    End Property



#End Region 'Get/Set Methods

#Region "Behavioral Methods"
    '******************************************************************
    'Behavioral Methods
    '******************************************************************


    '********** Public Non-Shared Behavioral Methods

    Public Overrides Function ToString() As String

        Return _toString()

    End Function 'ToString()

    '********** Private Non-Shared Behavioral Methods

    'implementation of Tostring of transaction class
    Private Function _toString() As String

        Dim tmpStr As String

        tmpStr = "( Customer : " _
            & "transaction id='" & _txnId & "'" _
            & ", transaction line='" & _txnLine & "'" _
             & ", transaction type='" & _type.ToString & "'" _
            & ", amount='" & _amount & "'" _
            & ", date and time is='" & _dateTime.ToString & "'" _
            & ", account id is='" & _accountId & "'" _
            & ", account id to is='" & _accountIdTo & "'" _
            & ", customer id is='" & _custId & "'" _
            & ", txn id prefix is='" & _txnIdPrefix & "'" _
            & ", txn id start is='" & _txnIdStart & "'" _
            & ", txnline prefix is='" & _txnLineIdPrefix & "'" _
            & ", txnline id start is='" & _txnLineIdStart & "'" _
             & ", txnline from is='" & _fromTxnLineIdt & "'" _
              & ", txnline to is='" & _toTxnLineId & "'" _
             & " )"

        Return tmpStr

    End Function '_toString()

#End Region 'Behavioral Methods

#Region "Event Procedures"
    '******************************************************************
    'Event Procedures
    '******************************************************************


    '********** Business Logic Event Procedures
    '             - Initiated as a result of business logic
    '               method(s) running

#End Region 'Event Procedures

#Region "Events"
    '******************************************************************
    'Events
    '******************************************************************

    'No Events are currently defined.
    'These are all public.

#End Region 'Events

End Class 'ClsTransaction
