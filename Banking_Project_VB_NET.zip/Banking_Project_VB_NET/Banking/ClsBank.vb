﻿'Copyright (c) 2009-2016 Dan Turk

#Region "Class / File Comment Header block"
'Program:            Banking
'File:               ClsBank.vb
'Author:             shreesh maurya
'Description:        implements business logic ofbank class
'Date:               updated: 9 dec 2016
'                    18 oct 2016
'Tier:               Business logic
'Exceptions:         None
'Exception-Handling: None
'Events:             None
'Event-Handling:     None
#End Region 'Class / File Comment Header block

#Region "Option / Imports"
Option Explicit On      'Must declare variables before using them
Option Strict On        'Must perform explicit data type conversions
#End Region 'Option / Imports

Public Class Bank

#Region "Attributes"
    '******************************************************************
    'Attributes + Module-level Constants+Variables
    '******************************************************************


    '********** Module-level variables

    Private mBankName As String
    Private mNumCust As Integer
    Private mNumAccnt As Integer
    Private mNumTxn As Integer
    Private mNumTxnLines As Integer
    Private mAccount() As Account
    Private mCustomer() As Customer
    Private mTransaction() As Transaction
    Private mStringEntries() As String
    Private mNumStringEntries As Integer


    Private Const mARRAY_SIZE_DEFAULT As Integer = 2
    Private Const mARRAY_INCREMENT_DEFAULT As Integer = 2

    Private Const mARRAY_SIZE_DEFAULT_STRING As Integer = 5
    Private Const mARRAY_INCREMENT_DEFAULT_STRING As Integer = 5

    Private mMaxCustomer As Integer
    Private mMaxAccount As Integer
    Private mMaxTransaction As Integer
    Private mMaxStringEntries As Integer




#End Region 'Attributes

#Region "Constructors"
    '******************************************************************
    'Constructors
    '******************************************************************

    '********** Special constructor(s)
    '             - typically constructors have parameters 
    '               that are used to initialize attributes

    'special constructor initializes all the variables  
    Public Sub New(
        ByVal pBankName As String,
        ByVal pNumAccnt As Integer,
        ByVal pNumTxn As Integer,
        ByVal pNumTxnLines As Integer,
           ByVal pNumCust As Integer)


        _bankName = pBankName
        _numCust = pNumCust
        _numAccnt = pNumAccnt
        _numTxn = pNumTxn
        _numTxnLines = pNumTxnLines

        _maxCustomer = _ARRAY_SIZE_DEFAULT
        ReDim mCustomer(_maxCustomer - 1)
        _numCust = 0

        _maxAccount = _ARRAY_SIZE_DEFAULT
        ReDim mAccount(_maxAccount - 1)
        _numAccnt = 0

        _maxTransaction = _ARRAY_SIZE_DEFAULT
        ReDim mTransaction(_maxTransaction - 1)
        _numTxn = 0
        _numTxnLines = 0

        _maxStringEntries = _ARRAY_SIZE_DEFAULT_STRING
        ReDim mStringEntries(_maxStringEntries - 1)
        _numStringEntries = 0


    End Sub 'New

    '********** Copy constructor(s)
    '             - one parameter, an object of the same class

#End Region 'Constructors

#Region "Get/Set Methods"
    '******************************************************************
    'Get/Set Methods
    '******************************************************************


    '********** Public Get/Set Methods
    '             - call private get/set methods to implement

    Public Property bankName As String
        Get
            Return _bankName
        End Get
        Set(pValue As String)
            _bankName = pValue
        End Set
    End Property

    Public Property numCust As Integer
        Get
            Return _numCust
        End Get
        Set(pValue As Integer)
            _numCust = pValue
        End Set
    End Property

    Public Property numAccnt As Integer
        Get
            Return _numAccnt
        End Get
        Set(pValue As Integer)
            _numAccnt = pValue
        End Set
    End Property

    Public Property numTxn As Integer
        Get
            Return _numTxn
        End Get
        Set(pValue As Integer)
            _numTxn = pValue
        End Set
    End Property

    Public Property numTxnLines As Integer
        Get
            Return _numTxnLines
        End Get
        Set(pValue As Integer)
            _numTxnLines = pValue
        End Set
    End Property



    Public Property maxCustomer As Integer
        Get
            Return _maxCustomer
        End Get
        Set(pValue As Integer)
            _maxCustomer = pValue
        End Set
    End Property

    Public Property maxAccount As Integer
        Get
            Return _maxAccount
        End Get
        Set(pValue As Integer)
            _maxAccount = pValue
        End Set
    End Property

    Public Property maxTransaction As Integer
        Get
            Return _maxTransaction
        End Get
        Set(pValue As Integer)
            _maxTransaction = pValue
        End Set
    End Property

    Public Property numStringEntries As Integer
        Get
            Return _numStringEntries
        End Get
        Set(pValue As Integer)
            _numStringEntries = pValue
        End Set
    End Property
    Public Property maxStringEntries As Integer
        Get
            Return _maxStringEntries
        End Get
        Set(pValue As Integer)
            _maxStringEntries = pValue
        End Set
    End Property

    Public Property stringEntries() As String()
        Get
            Return _stringEntries
        End Get
        Set(pValue As String())
            _stringEntries = pValue
        End Set
    End Property



    '********** Private Get/Set Methods
    '             - access attributes, begin name with underscore (_)

    Private Property _bankName As String
        Get
            Return mBankName
        End Get
        Set(pValue As String)
            mBankName = pValue
        End Set
    End Property

    Private Property _numCust As Integer
        Get
            Return mNumCust
        End Get
        Set(pValue As Integer)
            mNumCust = pValue
        End Set
    End Property

    Private Property _numAccnt As Integer
        Get
            Return mNumAccnt
        End Get
        Set(pValue As Integer)
            mNumAccnt = pValue
        End Set
    End Property

    Private Property _numTxn As Integer
        Get
            Return mNumTxn
        End Get
        Set(pValue As Integer)
            mNumTxn = pValue
        End Set
    End Property

    Private Property _numTxnLines As Integer
        Get
            Return mNumTxnLines
        End Get
        Set(pValue As Integer)
            mNumTxnLines = pValue
        End Set
    End Property



    Private Property _maxCustomer As Integer
        Get
            Return mMaxCustomer
        End Get
        Set(pValue As Integer)
            mMaxCustomer = pValue
        End Set
    End Property

    Private Property _maxAccount As Integer
        Get
            Return mMaxAccount
        End Get
        Set(pValue As Integer)
            mMaxAccount = pValue
        End Set
    End Property

    Private Property _maxTransaction As Integer
        Get
            Return mMaxTransaction
        End Get
        Set(pValue As Integer)
            mMaxTransaction = pValue
        End Set
    End Property

    Private Property _numStringEntries As Integer
        Get
            Return mNumStringEntries
        End Get
        Set(pValue As Integer)
            mNumStringEntries = pValue
        End Set
    End Property
    Private Property _maxStringEntries As Integer
        Get
            Return mMaxStringEntries
        End Get
        Set(pValue As Integer)
            mMaxStringEntries = pValue
        End Set
    End Property

    Private ReadOnly Property _ARRAY_SIZE_DEFAULT As Integer
        Get
            Return mARRAY_SIZE_DEFAULT
        End Get
    End Property

    Private ReadOnly Property _ARRAY_INCREMENT_DEFAULT As Integer
        Get
            Return mARRAY_INCREMENT_DEFAULT
        End Get
    End Property

    Private ReadOnly Property _ARRAY_SIZE_DEFAULT_STRING As Integer
        Get
            Return mARRAY_SIZE_DEFAULT_STRING
        End Get
    End Property


    Private ReadOnly Property _ARRAY_INCREMENT_DEFAULT_STRING As Integer
        Get
            Return mARRAY_INCREMENT_DEFAULT_STRING
        End Get
    End Property

    'it returns value of ith object or sets it value
    Private Property _ithCustomer(ByVal pI As Integer) As Customer

        Get
            If pI >= 0 And pI < _maxCustomer Then
                Return mCustomer(pI)
            Else
                Throw New IndexOutOfRangeException
            End If
        End Get
        Set(ByVal pvalue As Customer)
            If pI >= 0 And pI < _maxCustomer Then
                mCustomer(pI) = pvalue
            Else
                Throw New IndexOutOfRangeException
            End If
        End Set
    End Property

    'it returns value of ith object or sets it value
    Private Property _ithAccount(ByVal pI As Integer) As Account

        Get
            If pI >= 0 And pI < _maxAccount Then
                Return mAccount(pI)
            Else
                Throw New IndexOutOfRangeException
            End If
        End Get
        Set(ByVal pvalue As Account)
            If pI >= 0 And pI < _maxAccount Then
                mAccount(pI) = pvalue
            Else
                Throw New IndexOutOfRangeException
            End If
        End Set
    End Property

    'it returns value of ith object or sets it value
    Private Property _ithTransaction(ByVal pI As Integer) As Transaction

        Get
            If pI >= 0 And pI < _maxTransaction Then
                Return mTransaction(pI)
            Else
                Throw New IndexOutOfRangeException
            End If
        End Get
        Set(ByVal pvalue As Transaction)
            If pI >= 0 And pI < _maxTransaction Then
                mTransaction(pI) = pvalue
            Else
                Throw New IndexOutOfRangeException
            End If
        End Set
    End Property

    'it returns value of ith object or sets it value
    Private Property _ithStringEntry(ByVal pI As Integer) As String

        Get
            If pI >= 0 And pI < _maxStringEntries Then
                Return mStringEntries(pI)
            Else
                Throw New IndexOutOfRangeException
            End If
        End Get
        Set(ByVal pvalue As String)
            If pI >= 0 And pI < _maxStringEntries Then
                mStringEntries(pI) = pvalue
            Else
                Throw New IndexOutOfRangeException
            End If
        End Set
    End Property

    Private Property _stringEntries As String()
        Get
            Return mStringEntries
        End Get
        Set(pValue As String())


        End Set
    End Property



#End Region 'Get/Set Methods

#Region "Behavioral Methods"
    '******************************************************************
    'Behavioral Methods
    '******************************************************************


    '********** Public Non-Shared Behavioral Methods


    'public method for calling ToString()
    Public Overrides Function ToString() As String

        Return _toString()

    End Function 'ToString()


    'public version for calling the private version
    Public Function createCustomer(
          ByVal pCustId As String,
          ByVal pCustName As String,
          ByVal pBirthDate As Date
          ) _
      As _
          Customer

        Return _createCustomer(pCustId, pCustName, pBirthDate)

    End Function 'createCustomer

    Public Function createCustomerWithRefDate(
          ByVal pCustId As String,
          ByVal pCustName As String,
          ByVal pBirthDate As Date,
          ByVal pRefDate As Date
          ) _
      As _
          Customer

        Return _createCustomerWithRefDate(pCustId, pCustName, pBirthDate, pRefDate)

    End Function 'createCustomerWithRefDate

    'public version for calling the private version
    Public Function createAccount(
        ByVal pAccId As String,
        ByVal pAccName As String,
        ByVal pNumOwners As String,
        ByVal pOwner() As Customer,
        ByVal pDateOpened As Date,
        ByVal pInterestRate As Decimal,
        ByVal pAccuralDate As Date,
        ByVal pType As AccountType,
        ByVal pIsClosed As Boolean,
        ByVal pClosedDate As Date,
        ByVal pTrxId As String,
        ByVal pTrxLineId As String,
         ByVal pAmount As Decimal
          ) _
      As _
          Account

        Return _createAccount(pAccId, pAccName, pNumOwners, pOwner, pDateOpened, pInterestRate, pAccuralDate, pType, pIsClosed, pClosedDate, pTrxId, pTrxLineId, pAmount)

    End Function 'createAccount

    Public Function modifyAccount(
                 ByVal pAccId As String,
          ByVal pAccName As String,
          ByVal pOwner() As Customer,
         ByVal pInterestRate As Decimal,
        ByVal pIsClosed As Boolean,
        ByVal pClosedDate As Date
          ) _
      As _
          Account

        Return _modifyAccount(pAccId, pAccName, pOwner, pInterestRate, pIsClosed, pClosedDate)

    End Function 'modifyAccount

    'public version for calling the private version
    Public Function makeDeposit(
        ByVal pTxnId As String,
        ByVal pTxnLine As String,
        ByVal pType As TransactionType,
        ByVal pAmount As Decimal,
        ByVal pDateTime As Date,
        ByVal pAccountId As String,
               ByVal pCustId As String
          ) _
      As _
          Transaction

        Return _makeDeposit(pTxnId, pTxnLine, pType, pAmount, pDateTime, pAccountId, pCustId)

    End Function 'makeDeposit

    'public version for calling the private version
    Public Function makeWithdrawl(
        ByVal pTxnId As String,
        ByVal pTxnLine As String,
        ByVal pType As TransactionType,
        ByVal pAmount As Decimal,
        ByVal pDateTime As Date,
        ByVal pAccountId As String,
        ByVal pCustId As String
          ) _
      As _
          Transaction

        Return _makeWithdrawl(pTxnId, pTxnLine, pType, pAmount, pDateTime, pAccountId, pCustId)

    End Function 'makeWithdrawl

    'public version for calling the private version
    Public Function makeUsedebitcard(
        ByVal pTxnId As String,
        ByVal pTxnLine As String,
        ByVal pType As TransactionType,
        ByVal pAmount As Decimal,
        ByVal pDateTime As Date,
        ByVal pAccountId As String,
        ByVal pCustId As String
          ) _
      As _
          Transaction

        Return _makeUsedebitcard(pTxnId, pTxnLine, pType, pAmount, pDateTime, pAccountId, pCustId)

    End Function 'makeUsedebitcard

    'public version for calling the private version
    Public Function makeChargePurchase(
        ByVal pTxnId As String,
        ByVal pTxnLine As String,
        ByVal pType As TransactionType,
        ByVal pAmount As Decimal,
        ByVal pDateTime As Date,
        ByVal pAccountId As String,
          ByVal pCustId As String
          ) _
      As _
          Transaction

        Return _makeChargePurchase(pTxnId, pTxnLine, pType, pAmount, pDateTime, pAccountId, pCustId)

    End Function 'makeChargePurchase


    'public version for calling the private version
    Public Function makePayment(
        ByVal pTxnId As String,
               ByVal pType As TransactionType,
        ByVal pAmount As Decimal,
        ByVal pDateTime As Date,
        ByVal pAccountId As String,
        ByVal pAccountIdTo As String,
        ByVal pCustId As String,
        ByVal pTxnIdPrefix As String,
        ByVal pTxnIdStart As String,
        ByVal pTxnLineIdPrefix As String,
        ByVal pTxnLineIdStart As String,
         ByVal pFromTxnLineId As String,
        ByVal pToTxnLineId As String
          ) _
      As _
          Transaction

        Return _makePayment(pTxnId, pType, pAmount, pDateTime, pAccountId, pAccountIdTo, pCustId, pTxnIdPrefix, pTxnIdStart, pTxnLineIdPrefix, pTxnLineIdStart, pFromTxnLineId, pToTxnLineId)

    End Function 'makePayment

    'public version for calling the private version
    Public Function makeTransferFund(
        ByVal pTxnId As String,
               ByVal pType As TransactionType,
        ByVal pAmount As Decimal,
        ByVal pDateTime As Date,
        ByVal pAccountId As String,
        ByVal pAccountIdTo As String,
        ByVal pCustId As String,
        ByVal pTxnIdPrefix As String,
        ByVal pTxnIdStart As String,
        ByVal pTxnLineIdPrefix As String,
        ByVal pTxnLineIdStart As String,
         ByVal pFromTxnLineId As String,
        ByVal pToTxnLineId As String
          ) _
      As _
          Transaction

        Return _makeTransferFund(pTxnId, pType, pAmount, pDateTime, pAccountId, pAccountIdTo, pCustId, pTxnIdPrefix, pTxnIdStart, pTxnLineIdPrefix, pTxnLineIdStart, pFromTxnLineId, pToTxnLineId)

    End Function 'makeTransferFund

    Public Function accureInterest(
        ByVal pTxnId As String,
        ByVal pTxnLine As String,
        ByVal pType As TransactionType,
        ByVal pAmount As Decimal,
        ByVal pDateTime As Date,
        ByVal pAccountId As String,
        ByVal pAccountIdTo As String,
        ByVal pCustId As String,
        ByVal pTxnIdPrefix As String,
        ByVal pTxnIdStart As String,
        ByVal pTxnLineIdPrefix As String,
        ByVal pTxnLineIdStart As String
          ) _
      As _
          Transaction

        Return _accureInterest(pTxnId, pTxnLine, pType, pAmount, pDateTime, pAccountId, pAccountIdTo, pCustId, pTxnIdPrefix, pTxnIdStart, pTxnLineIdPrefix, pTxnLineIdStart)

    End Function 'accureInterest


    Public Function findCustomer(
            ByVal pCustomerToFind As String
            ) _
        As _
            Customer

        'NOTICE that the public method (and thus public interface)
        'is different in this case than the private method
        '(and thus the private interface).  We need to know
        '*internally* where we found the item, but don't want
        'to make that information known *externally*.

        Dim locationFound As Integer

        Return _findCustomer(pCustomerToFind, locationFound)

    End Function 'findItem(pItemToFind)

    Public Function findAccount(
            ByVal pAccountToFind As String
            ) _
        As _
            Account

        'NOTICE that the public method (and thus public interface)
        'is different in this case than the private method
        '(and thus the private interface).  We need to know
        '*internally* where we found the item, but don't want
        'to make that information known *externally*.

        Dim locationFound As Integer

        Return _findAccount(pAccountToFind, locationFound)

    End Function 'findItem(pItemToFind)


    Public Function findTransaction(
            ByVal pTransactionToFind As String
            ) _
        As _
            Transaction

        'NOTICE that the public method (and thus public interface)
        'is different in this case than the private method
        '(and thus the private interface).  We need to know
        '*internally* where we found the item, but don't want
        'to make that information known *externally*.

        Dim locationFound As Integer

        Return _findTransaction(pTransactionToFind, locationFound)

    End Function 'findItem(pItemToFind)

    Public Function findTransactionLine(
            ByVal pTransactionToFind As String
            ) _
        As _
            Transaction

        'NOTICE that the public method (and thus public interface)
        'is different in this case than the private method
        '(and thus the private interface).  We need to know
        '*internally* where we found the item, but don't want
        'to make that information known *externally*.

        Dim locationFound As Integer

        Return _findTransactionLine(pTransactionToFind, locationFound)

    End Function 'findItem(pItemToFind)

    Public Function addOwner(
                             ByVal pDateTime As Date,
                              ByVal pCustId As String,
                              ByVal pAccId As String
            ) As Boolean



        Return _addOwner(pDateTime, pCustId, pAccId)

    End Function 'addOwner(pItemToFind)

    Public Function findNextAccuralDate(
                             ByVal pDate As Date
            ) As Date

        Return _findNextAccuralDate(pDate)

    End Function 'findNextAccuralDate

    Public Iterator Function iterateAccount() _
        As _
            IEnumerable

        Dim theObject As Object

        For Each theObject In _iterateAccount()
            Yield theObject
        Next theObject

    End Function 'iterateAccount()

    Public Iterator Function iterateTransaction() _
        As _
            IEnumerable

        Dim theObject As Object

        For Each theObject In _iterateTransaction()
            Yield theObject
        Next theObject

    End Function 'iterateTransaction()

    Public Iterator Function iterateCustomer() _
        As _
            IEnumerable

        Dim theObject As Object

        For Each theObject In _iterateCustomer()
            Yield theObject
        Next theObject

    End Function 'iterateCustomer()

    Public Function updateName(
        ByVal theAccount As Account,
        ByVal pAccName As String) _
 As _
 Account

        Return _updateName(theAccount, pAccName)


    End Function '_updateName

    Public Function updateInterestRate(
        ByVal theAccount As Account,
        ByVal pInterestRate As Decimal) _
 As _
 Account

        Return _updateInterestRate(theAccount, pInterestRate)


    End Function '_updateInterestRate

    'it closes the account
    Public Function closeAccount(
        ByVal theAccount As Account
       ) _
 As _
 Account

        Return _closeAccount(theAccount)

    End Function '_closeAccount

    'it updates the string array
    Public Function updateStringArray(
        ByVal theString As String
       ) _
 As _
 String

        Return _updateStringArray(theString)

    End Function '_closeAccount



    '********** Private Non-Shared Behavioral Methods

    'iterator method to iterate between objects
    Private Iterator Function _iterateAccount() _
        As _
            IEnumerable

        Dim i As Integer

        For i = 0 To _numAccnt - 1
            Yield _ithAccount(i)
        Next i

    End Function '_iterateAccount()

    'iterator method to iterate between objects
    Private Iterator Function _iterateTransaction() _
        As _
            IEnumerable

        Dim i As Integer

        For i = 0 To _numTxn - 1
            Yield _ithTransaction(i)
        Next i

    End Function '_iterateTransaction  ()

    'iterator method to iterate between objects

    Private Iterator Function _iterateCustomer() _
        As _
            IEnumerable

        Dim i As Integer

        For i = 0 To _numCust - 1
            Yield _ithCustomer(i)
        Next i

    End Function '_iterateCustomer()

    'it finds the element and returns the appropriate object
    Private Function _findAccount(
            ByVal pAccountToFind As String,
            ByRef pLocationFound As Integer
            ) _
        As _
            Account

        'NOTICE that the public method (and thus public interface)
        'is different in this case than the private method
        '(and thus the private interface).  We need to know
        '*internally* where we found the item, but don't want
        'to make that information known *externally*.

        'Dim item As Object
        Dim foundItem As Account
        Dim notfoundItem As Account

        For pLocationFound = 0 To mAccount.Length - 1
            foundItem = _ithAccount(pLocationFound)
            If foundItem.accId = pAccountToFind Then 'FOUND
                Return foundItem
            End If
        Next pLocationFound



        Return notfoundItem

    End Function '_findAccount

    'it adds owner to the account
    Private Function _addOwner(
              ByVal pDateTime As Date,
              ByVal pCustId As String,
              ByVal pAccId As String
            ) As Boolean


        Dim foundItem As Customer
        Dim foundCust As Customer

        For pLocationFound = 0 To mCustomer.Length - 1
            foundItem = _ithCustomer(pLocationFound)
            If foundItem.custId = pCustId Then 'FOUND
                foundCust = foundItem
                Exit For
            End If
        Next pLocationFound




        For Each acc As Account In iterateAccount()
            For pLocationFound = 0 To acc.owner.Length - 1
                If acc.accId = pAccId Then
                    ReDim Preserve acc.owner(acc.owner.Length)
                    acc.owner(acc.owner.Length - 1) = foundCust
                    Exit For
                End If
            Next pLocationFound
        Next acc


        Dim theString As String
        theString = pDateTime.ToString("yyyyMMdd") + "; " + pDateTime.ToString("HHmm") + "; Account ; AddOwner ;" + pCustId + ";" + pAccId
        _updateStringArray(theString)

        Return True

    End Function '_addOwner



    'it finds the element and returns the appropriate object
    Private Function _findCustomer(
            ByVal pCustomerToFind As String,
            ByRef pLocationFound As Integer
            ) _
        As _
            Customer

        'NOTICE that the public method (and thus public interface)
        'is different in this case than the private method
        '(and thus the private interface).  We need to know
        '*internally* where we found the item, but don't want
        'to make that information known *externally*.

        'Dim item As Object
        Dim foundItem As Customer

        For pLocationFound = 0 To mCustomer.Length - 1
            foundItem = _ithCustomer(pLocationFound)
            If foundItem.custId = pCustomerToFind Then 'FOUND
                Return foundItem
            End If
        Next pLocationFound



        '  Return  'NOT found

    End Function '_findItem(pItemToFind,pLocationFound)

    'it finds the element and returns the appropriate object
    Private Function _findTransaction(
            ByVal pTransactionToFind As String,
            ByRef pLocationFound As Integer
            ) _
        As _
            Transaction

        'NOTICE that the public method (and thus public interface)
        'is different in this case than the private method
        '(and thus the private interface).  We need to know
        '*internally* where we found the item, but don't want
        'to make that information known *externally*.

        'Dim item As Object
        Dim foundItem As Transaction


        Try
            For pLocationFound = mTransaction.Length - 1 To 0 Step -1
                foundItem = _ithTransaction(pLocationFound)
                If foundItem.txnId = pTransactionToFind Then 'FOUND
                    Return foundItem
                End If
            Next pLocationFound
        Catch ex As Exception
            Throw New Exception
        End Try



        '  Return  'NOT found

    End Function '_findItem(pItemToFind,pLocationFound)

    'it finds the element and returns the appropriate object
    Private Function _findTransactionLine(
            ByVal pTransactionToFind As String,
            ByRef pLocationFound As Integer
            ) _
        As _
            Transaction

        'NOTICE that the public method (and thus public interface)
        'is different in this case than the private method
        '(and thus the private interface).  We need to know
        '*internally* where we found the item, but don't want
        'to make that information known *externally*.

        'Dim item As Object
        Dim foundItem As Transaction


        Try
            For pLocationFound = mTransaction.Length - 1 To 0 Step -1
                foundItem = _ithTransaction(pLocationFound)
                If foundItem.txnLine = pTransactionToFind Then 'FOUND
                    Return foundItem

                ElseIf foundItem.toTxnLineId = pTransactionToFind Then 'FOUND
                    Return foundItem
                End If
            Next pLocationFound



        Catch ex As Exception
            Throw New Exception
        End Try



        '  Return  'NOT found

    End Function '_findItem(pItemToFind,pLocationFound)


    'it finds the element and returns the appropriate object
    Private Function _findNextAccuralDate(
            ByVal pDate As Date
            ) _
        As _
            Date

        Dim theNextAccuralDate As Date


        If pDate.AddDays(1).Day.Equals(1) Then
            theNextAccuralDate = pDate.AddDays(1).AddMonths(1).AddDays(-1).Date
        Else
            theNextAccuralDate = pDate.AddMonths(1).Date

        End If

        Return theNextAccuralDate

    End Function '_findNextAccuralDate


    Private Function _updateStringArray(
            ByVal pString As String
            ) _
        As _
            String

        If _numStringEntries >= _maxStringEntries Then
            _maxStringEntries += _ARRAY_INCREMENT_DEFAULT_STRING
            ReDim Preserve mStringEntries(_maxStringEntries - 1)
        End If

        'do processing
        Try
            _ithStringEntry(_numStringEntries) = pString
        Catch ex As Exception
            Throw New IndexOutOfRangeException
        End Try

        _numStringEntries += 1


        Return pString

    End Function '_findNextAccuralDate



    'implementation of ToString for this Bank class
    Private Function _toString() As String

        Dim tmpStr As String

        tmpStr = "( Customer : " _
            & "bank name='" & _bankName & "'" _
            & ", number of customer='" & _numCust & "'" _
            & ", number of account='" & _numAccnt & "'" _
            & ", number of transaction='" & _numTxn & "'" _
            & ", number of customers in array='" & mCustomer.Length & "'" _
                                        & " )"

        Return tmpStr

    End Function '_toString()

    'Implementation of private function
    Private Function _createCustomer(
            ByVal pCustId As String,
            ByVal pCustName As String,
            ByVal pBirthDate As Date
            ) _
        As _
            Customer

        Dim theCustomer As Customer

        For Each cus As Customer In iterateCustomer()

            If cus.custId = pCustId Then
                MessageBox.Show("customer id already exists , please enter new one ")
                Exit Function
            End If

        Next cus


        theCustomer =
            New Customer(
                pCustId,
                pCustName,
                pBirthDate
                                )



        If _numCust >= _maxCustomer Then
            _maxCustomer += _ARRAY_INCREMENT_DEFAULT
            ReDim Preserve mCustomer(_maxCustomer - 1)
        End If

        'do processing
        Try
            _ithCustomer(_numCust) = theCustomer
        Catch ex As Exception
            Throw New IndexOutOfRangeException
        End Try

        'it keeps tracks of total no. of customer
        _numCust += 1

        theCustomer.refdate = Date.Now()
        Dim theString As String
        theString = theCustomer.refdate.ToString("yyyyMMdd") + "; " + theCustomer.refdate.ToString("HHmm") + "; Customer;" + "Create; " + theCustomer.custId + " ; " + theCustomer.custName + " ; " + theCustomer.birthDate.ToString("yyyyMMdd") & vbCrLf


        _updateStringArray(theString)



        'event is raised from here and its handeled in frmMain
        RaiseEvent Bank_CustomerAdded(
            Me,
            New Customer_EventArgs_CustomerAdded(
                theCustomer
                )
            )

        RaiseEvent Bank_ChangedMetrics(
            Me,
            New Customer_EventArgs_CustomerAdded(
                theCustomer
                )
            )

        Return theCustomer

    End Function '_createCustomer

    Private Function _createCustomerWithRefDate(
            ByVal pCustId As String,
            ByVal pCustName As String,
            ByVal pBirthDate As Date,
            ByVal pRefDate As Date
            ) _
        As _
            Customer

        Dim theCustomer As Customer

        For Each cus As Customer In iterateCustomer()

            If cus.custId = pCustId Then
                MessageBox.Show("customer id already exists , please enter new one ")
                Exit Function
            End If

        Next cus

        theCustomer =
            New Customer(
                pCustId,
                pCustName,
                pBirthDate,
                pRefDate
                                )



        If _numCust >= _maxCustomer Then
            _maxCustomer += _ARRAY_INCREMENT_DEFAULT
            ReDim Preserve mCustomer(_maxCustomer - 1)
        End If

        'do processing
        Try
            _ithCustomer(_numCust) = theCustomer
        Catch ex As Exception
            Throw New IndexOutOfRangeException
        End Try
        'it keeps tracks of total no. of customer
        _numCust += 1



        Dim theString As String
        theString = theCustomer.refdate.ToString("yyyyMMdd") + "; " + theCustomer.refdate.ToString("HHmm") + "; Customer;" + "Create; " + theCustomer.custId + " ; " + theCustomer.custName + " ; " + theCustomer.birthDate.ToString("yyyyMMdd") & vbCrLf
        _updateStringArray(theString)


        'event is raised from here and its handeled in frmMain
        RaiseEvent Bank_CustomerAdded(
            Me,
            New Customer_EventArgs_CustomerAdded(
                theCustomer
                )
            )

        'event raised to update the metrics with new data
        RaiseEvent Bank_ChangedMetrics(
            Me,
            New Customer_EventArgs_CustomerAdded(
                theCustomer
                )
            )

        Return theCustomer

    End Function '_createCustomerWithRefDate

    'Implementation of private function
    Private Function _createAccount(
      ByVal pAccId As String,
          ByVal pAccName As String,
          ByVal pNumOwners As String,
          ByVal pOwner() As Customer,
        ByVal pDateOpened As Date,
        ByVal pInterestRate As Decimal,
        ByVal pAccuralDate As Date,
        ByVal pType As AccountType,
        ByVal pIsClosed As Boolean,
        ByVal pClosedDate As Date,
        ByVal pTrxId As String,
        ByVal pTrxLineId As String,
      ByVal pAmount As Decimal) _
      As _
      Account

        For Each acc As Account In iterateAccount()

            If acc.accId = pAccId Then
                MessageBox.Show("accountid already exists , please enter new one ")
                Exit Function
            End If

        Next acc

        For Each acc As Account In iterateAccount()

            If acc.trxLineId = pTrxLineId Then
                MessageBox.Show("txn line id  already exists , please enter new one ")
                Exit Function
            End If

        Next acc

        For Each acc As Account In iterateAccount()

            If acc.trxId = pTrxId Then
                MessageBox.Show("txn id  already exists , please enter new one ")
                Exit Function
            End If

        Next acc





        Dim theAccount As Account
        theAccount =
            New Account(
            pAccId,
            pAccName,
            pNumOwners,
            pOwner,
            pDateOpened,
            pInterestRate,
            pAccuralDate,
            pType,
            pIsClosed,
            pClosedDate,
            pTrxId,
           pTrxLineId,
            pAmount)



        If _numAccnt >= _maxAccount Then
            _maxAccount += _ARRAY_INCREMENT_DEFAULT
            ReDim Preserve mAccount(_maxAccount - 1)
        End If

        'do processing
        Try
            _ithAccount(_numAccnt) = theAccount
        Catch ex As Exception
            Throw New IndexOutOfRangeException
        End Try


        Dim theTransaction As Transaction
        theTransaction = _makeDeposit(pTrxId, pTrxLineId, TransactionType.MakeDeposit, pAmount, pDateOpened, pAccId, pOwner(0).custId)



        ''it keeps track of count of account created


        _numAccnt += 1

        Dim accountType As String
        If theAccount.type.ToString = "Checking" Then
            accountType = "Checking"
        ElseIf theAccount.type.ToString = "Credit Card" Then
            accountType = "CreditCard"
        ElseIf theAccount.type.ToString = "Loan" Then
            accountType = "Loan"
        End If

        Dim theString As String
        theString = theAccount.dateOpened.ToString("yyyyMMdd") + "; " + theAccount.dateOpened.ToString("HHmm") + "; Account ; Open ;" + accountType + "; " + theAccount.trxId + "; " + theAccount.trxLineId + "; " + theAccount.accId + "; " + theAccount.accName + "; " + theAccount.owner(0).custId + "; " + CType(theAccount.amount, String) + "; " + CType(theAccount.interestRate, String)
        _updateStringArray(theString)


        'event is raised from here and its handeled in frmMain
        RaiseEvent Bank_AccountCreated(
            Me,
            New Account_EventArgs_AccountCreated(
                theAccount
                )
            )

        'event raised to update the metrics with new data
        RaiseEvent Bank_ChangedMetrics(
            Me,
            New Account_EventArgs_AccountCreated(
                theAccount
                )
            )

        Return theAccount

    End Function '_createAccount

    Private Function _modifyAccount(
      ByVal pAccId As String,
          ByVal pAccName As String,
          ByVal pOwner() As Customer,
         ByVal pInterestRate As Decimal,
        ByVal pIsClosed As Boolean,
        ByVal pClosedDate As Date
          ) _
      As _
      Account

        Dim pLocationFound As Integer
        Dim theAccount As Account
        For Each acc As Account In iterateAccount()

            For pLocationFound = 0 To mAccount.Length - 1
                If acc.accId = pAccId Then
                    theAccount = acc
                End If
            Next pLocationFound
        Next acc

        If pIsClosed = True Then
            _closeAccount(theAccount)
        Else

            _updateName(theAccount, pAccName)
            _updateInterestRate(theAccount, pInterestRate)


            If pOwner.Length > 0 Then

                For pLocationFound = 0 To pOwner.Length - 1
                    _addOwner(theAccount.dateOpened, pOwner(pLocationFound).custId, theAccount.accId)
                Next pLocationFound
            End If

            'event is raised from here and its handled in frmMain
            RaiseEvent Bank_AccountModified(
           Me,
           New Account_EventArgs_AccountModified(
               theAccount
               )
           )

            Return theAccount


        End If


    End Function '_createAccount

    'Implementation of private function
    Private Function _makeDeposit(
     ByVal pTxnId As String,
        ByVal pTxnLine As String,
        ByVal pType As TransactionType,
        ByVal pAmount As Decimal,
        ByVal pDateTime As Date,
        ByVal pAccountId As String,
                ByVal pCustId As String
         ) _
      As _
      Transaction

        For Each acc As Account In iterateAccount()

            If acc.trxLineId = pTxnLine Then
                MessageBox.Show("txn line id  already exists , please enter new one ")
                Exit Function
            End If

        Next acc

        For Each acc As Account In iterateAccount()

            If acc.trxId = pTxnId Then
                MessageBox.Show("txn id  already exists , please enter new one ")
                Exit Function
            End If

        Next acc


        Dim theTransaction As Transaction
        theTransaction =
            New Transaction(
            pTxnId,
            pTxnLine,
            pType,
            pAmount,
            pDateTime,
            pAccountId,
            pCustId
)



        If _numTxn >= _maxTransaction Then
            _maxTransaction += _ARRAY_INCREMENT_DEFAULT
            ReDim Preserve mTransaction(_maxTransaction - 1)
        End If

        'do processing
        Try
            _ithTransaction(_numTxn) = theTransaction
        Catch ex As Exception
            Throw New IndexOutOfRangeException
        End Try

        _numTxn += 1
        _numTxnLines += 1



        'event is raised from here and its handled in frmMain
        RaiseEvent Bank_DepositMade(
            Me,
            New Transaction_EventArgs_TransactionProcessed(
                theTransaction
                )
            )

        Dim theString As String
        theString = pDateTime.ToString("yyyyMMdd") + "; " + pDateTime.ToString("HHmm") + "; Customer ; MakeDeposit ;" + pTxnId + "; " + pTxnLine + "; " + pCustId + "; " + pAccountId + "; " + pAmount.ToString
        _updateStringArray(theString)



        Return theTransaction

    End Function '_makeDeposit

    'Implementation of private function
    Private Function _makeWithdrawl(
     ByVal pTxnId As String,
        ByVal pTxnLine As String,
        ByVal pType As TransactionType,
        ByVal pAmount As Decimal,
        ByVal pDateTime As Date,
       ByVal pAccountId As String,
          ByVal pCustId As String
         ) _
      As _
      Transaction

        For Each acc As Account In iterateAccount()

            If acc.trxLineId = pTxnLine Then
                MessageBox.Show("txn line id  already exists , please enter new one ")
                Exit Function
            End If

        Next acc

        For Each acc As Account In iterateAccount()

            If acc.trxId = pTxnId Then
                MessageBox.Show("txn id  already exists , please enter new one ")
                Exit Function
            End If

        Next acc


        Dim theTransaction As Transaction
        theTransaction =
            New Transaction(
            pTxnId,
            pTxnLine,
            pType,
            pAmount,
            pDateTime,
             pAccountId,
              pCustId
)

        If _numTxn >= _maxTransaction Then
            _maxTransaction += _ARRAY_INCREMENT_DEFAULT
            ReDim Preserve mTransaction(_maxTransaction - 1)
        End If

        'do processing
        Try
            _ithTransaction(_numTxn) = theTransaction
        Catch ex As Exception
            Throw New IndexOutOfRangeException
        End Try


        _numTxn += 1
        _numTxnLines += 1

        'event is raised from here and its handled in frmMain
        RaiseEvent Bank_WithdrawlMade(
            Me,
            New Transaction_EventArgs_TransactionProcessed(
                theTransaction
                )
            )

        Dim theString As String
        theString = pDateTime.ToString("yyyyMMdd") + "; " + pDateTime.ToString("HHmm") + "; Customer ; MakeWithdrawal ;" + pTxnId + "; " + pTxnLine + "; " + pCustId + "; " + pAccountId + "; " + pAmount.ToString
        _updateStringArray(theString)

        Return theTransaction

    End Function '_makeWithdrawl

    'Implementation of private function
    Private Function _makeUsedebitcard(
     ByVal pTxnId As String,
        ByVal pTxnLine As String,
        ByVal pType As TransactionType,
        ByVal pAmount As Decimal,
        ByVal pDateTime As Date,
        ByVal pAccountId As String,
        ByVal pCustId As String
      ) _
      As _
      Transaction

        For Each acc As Account In iterateAccount()

            If acc.trxLineId = pTxnLine Then
                MessageBox.Show("txn line id  already exists , please enter new one ")
                Exit Function
            End If

        Next acc

        For Each acc As Account In iterateAccount()

            If acc.trxId = pTxnId Then
                MessageBox.Show("txn id  already exists , please enter new one ")
                Exit Function
            End If

        Next acc


        Dim theTransaction As Transaction
        theTransaction =
            New Transaction(
            pTxnId,
            pTxnLine,
            pType,
            pAmount,
            pDateTime,
           pAccountId,
              pCustId
                      )

        If _numTxn >= _maxTransaction Then
            _maxTransaction += _ARRAY_INCREMENT_DEFAULT
            ReDim Preserve mTransaction(_maxTransaction - 1)
        End If

        'do processing
        Try
            _ithTransaction(_numTxn) = theTransaction
        Catch ex As Exception
            Throw New IndexOutOfRangeException
        End Try


        _numTxn += 1
        _numTxnLines += 1

        'event is raised from here and its handled in frmMain
        RaiseEvent Bank_DebitCardUsed(
            Me,
            New Transaction_EventArgs_TransactionProcessed(
                theTransaction
                )
            )

        Dim theString As String
        theString = pDateTime.ToString("yyyyMMdd") + "; " + pDateTime.ToString("HHmm") + "; Customer ; UseDebitCard ;" + pTxnId + "; " + pTxnLine + "; " + pCustId + "; " + pAccountId + "; " + pAmount.ToString
        _updateStringArray(theString)

        Return theTransaction

    End Function '_makeUsedebitcard

    'Implementation of private function
    Private Function _makeChargePurchase(
     ByVal pTxnId As String,
        ByVal pTxnLine As String,
        ByVal pType As TransactionType,
        ByVal pAmount As Decimal,
        ByVal pDateTime As Date,
        ByVal pAccountId As String,
        ByVal pCustId As String
      ) _
      As _
      Transaction

        For Each acc As Account In iterateAccount()

            If acc.trxLineId = pTxnLine Then
                MessageBox.Show("txn line id  already exists , please enter new one ")
                Exit Function
            End If

        Next acc

        For Each acc As Account In iterateAccount()

            If acc.trxId = pTxnId Then
                MessageBox.Show("txn id  already exists , please enter new one ")
                Exit Function
            End If

        Next acc


        Dim theTransaction As Transaction
        theTransaction =
            New Transaction(
            pTxnId,
            pTxnLine,
            pType,
            pAmount,
            pDateTime,
            pAccountId,
              pCustId
            )

        If _numTxn >= _maxTransaction Then
            _maxTransaction += _ARRAY_INCREMENT_DEFAULT
            ReDim Preserve mTransaction(_maxTransaction - 1)
        End If

        'do processing
        Try
            _ithTransaction(_numTxn) = theTransaction
        Catch ex As Exception
            Throw New IndexOutOfRangeException
        End Try



        _numTxn += 1
        _numTxnLines += 1

        'event is raised from here and its handled in frmMain
        RaiseEvent Bank_ChargePurchased(
            Me,
            New Transaction_EventArgs_TransactionProcessed(
                theTransaction
                )
            )

        Dim theString As String
        theString = pDateTime.ToString("yyyyMMdd") + "; " + pDateTime.ToString("HHmm") + "; Customer ; ChargePurchase ;" + pTxnId + "; " + pTxnLine + "; " + pCustId + "; " + pAccountId + "; " + pAmount.ToString
        _updateStringArray(theString)


        Return theTransaction

    End Function '_makeChargePurchase

    'Implementation of private function
    Private Function _makePayment(
   ByVal pTxnId As String,
            ByVal pType As TransactionType,
      ByVal pAmount As Decimal,
      ByVal pDateTime As Date,
      ByVal pAccountId As String,
        ByVal pAccountIdTo As String,
        ByVal pCustId As String,
        ByVal pTxnIdPrefix As String,
        ByVal pTxnIdStart As String,
        ByVal pTxnLineIdPrefix As String,
        ByVal pTxnLineIdStart As String,
          ByVal pFromTxnLineId As String,
        ByVal pToTxnLineId As String) _
    As _
    Transaction




        Dim theTransaction As Transaction
        theTransaction =
            New Transaction(
            pTxnId,
            pType,
            pAmount,
            pDateTime,
            pAccountId,
            pAccountIdTo,
            pCustId,
            pTxnIdPrefix,
            pTxnIdStart,
            pTxnLineIdPrefix,
            pTxnLineIdStart,
            pFromTxnLineId,
             pToTxnLineId
            )

        For Each acc As Account In iterateAccount()

            If acc.trxId = pTxnId Then
                MessageBox.Show("txn id  already exists , please enter new one ")
                Exit Function
            End If

        Next acc

        For Each acc As Account In iterateAccount()

            If acc.trxLineId = pTxnIdPrefix Then
                MessageBox.Show("txn line id  already exists , please enter new one ")
                Exit Function
            End If

        Next acc

        If _numTxn >= _maxTransaction Then
            _maxTransaction += _ARRAY_INCREMENT_DEFAULT
            ReDim Preserve mTransaction(_maxTransaction - 1)
        End If

        'do processing
        Try
            _ithTransaction(_numTxn) = theTransaction
        Catch ex As Exception
            Throw New IndexOutOfRangeException
        End Try



        _numTxn += 1
        _numTxnLines += 1

        'event is raised from here and its handled in frmMain
        RaiseEvent Bank_PaymentMade(
            Me,
            New Transaction_EventArgs_TransactionProcessed(
                theTransaction
                )
            )

        Dim theString As String
        theString = pDateTime.ToString("yyyyMMdd") + "; " + pDateTime.ToString("HHmm") + "; Customer ; MakePayment ;" + pTxnId + "; " + pFromTxnLineId + "; " + pToTxnLineId + "; " + pCustId + "; " + pAccountIdTo + ";" + pAccountId + ";" + pAmount.ToString
        _updateStringArray(theString)

        Return theTransaction

    End Function '_makePayment


    'Implementation of private function
    Private Function _makeTransferFund(
 ByVal pTxnId As String,
        ByVal pType As TransactionType,
    ByVal pAmount As Decimal,
    ByVal pDateTime As Date,
    ByVal pAccountId As String,
        ByVal pAccountIdTo As String,
        ByVal pCustId As String,
        ByVal pTxnIdPrefix As String,
        ByVal pTxnIdStart As String,
        ByVal pTxnLineIdPrefix As String,
        ByVal pTxnLineIdStart As String,
  ByVal pFromTxnLineId As String,
        ByVal pToTxnLineId As String) _
  As _
  Transaction
        Dim theTransaction As Transaction
        theTransaction =
            New Transaction(
            pTxnId,
             pType,
            pAmount,
            pDateTime,
           pAccountId,
            pAccountIdTo,
            pCustId,
            pTxnIdPrefix,
            pTxnIdStart,
            pTxnLineIdPrefix,
            pTxnLineIdStart,
              pFromTxnLineId,
             pToTxnLineId
            )




        If _numTxn >= _maxTransaction Then
            _maxTransaction += _ARRAY_INCREMENT_DEFAULT
            ReDim Preserve mTransaction(_maxTransaction - 1)
        End If

        'do processing
        Try
            _ithTransaction(_numTxn) = theTransaction
        Catch ex As Exception
            Throw New IndexOutOfRangeException
        End Try



        _numTxn += 1
        _numTxnLines += 1

        'event is raised from here and its handled in frmMain
        RaiseEvent Bank_TransferMade(
            Me,
            New Transaction_EventArgs_TransactionProcessed(
                theTransaction
                )
            )

        Dim theString As String
        theString = pDateTime.ToString("yyyyMMdd") + "; " + pDateTime.ToString("HHmm") + "; Customer ; TransferFunds ;" + pTxnId + "; " + pFromTxnLineId + "; " + pToTxnLineId + "; " + pCustId + "; " + pAccountIdTo + ";" + pAccountId + ";" + pAmount.ToString
        _updateStringArray(theString)

        Return theTransaction

    End Function '_makeTransferFund

    Private Function _accureInterest(
    ByVal pTxnId As String,
   ByVal pTxnLine As String,
   ByVal pType As TransactionType,
   ByVal pAmount As Decimal,
   ByVal pDateTime As Date,
   ByVal pAccountId As String,
        ByVal pAccountIdTo As String,
        ByVal pCustId As String,
        ByVal pTxnIdPrefix As String,
        ByVal pTxnIdStart As String,
        ByVal pTxnLineIdPrefix As String,
        ByVal pTxnLineIdStart As String) _
 As _
 Transaction
        Dim theTransaction As Transaction
        theTransaction =
            New Transaction(
            pTxnId,
            pTxnLine,
            pType,
            pAmount,
            pDateTime,
            pAccountId,
            pAccountIdTo,
            pCustId,
            pTxnIdPrefix,
            pTxnIdStart,
            pTxnLineIdPrefix,
            pTxnLineIdStart
             )


        If _numTxn >= _maxTransaction Then
            _maxTransaction += _ARRAY_INCREMENT_DEFAULT
            ReDim Preserve mTransaction(_maxTransaction - 1)
        End If

        'do processing
        Try
            _ithTransaction(_numTxn) = theTransaction
        Catch ex As Exception
            Throw New IndexOutOfRangeException
        End Try



        _numTxn += 1
        _numTxnLines += 1

        'event is raised from here and its handled in frmMain


        If (theTransaction.type.ToString = "SpecificAccount") Then

            Dim pLocationFound As Integer
            Dim rate As Decimal

            Try
                For pLocationFound = 0 To mAccount.Length - 1

                    If mAccount(pLocationFound).accId = theTransaction.accountId Then
                        rate = mAccount(pLocationFound).interestRate / 12

                        mAccount(pLocationFound).amount = mAccount(pLocationFound).amount + (mAccount(pLocationFound).amount * rate)
                        Exit For
                    End If


                Next pLocationFound
            Catch ex As Exception
            End Try

            Dim theString As String
            theString = pDateTime.ToString("yyyyMMdd") + "; " + pDateTime.ToString("HHmm") + ";" + "Account" + ";" + "AccrueInterestIndividual" + ";" + pTxnId + "; " + pTxnLine + "; " + pAccountId
            _updateStringArray(theString)

        End If

        If (theTransaction.type.ToString = "AllAccounts") Then
            Dim rate As Decimal

            Try
                For pLocationFound = 0 To mAccount.Length - 1

                    rate = mAccount(pLocationFound).interestRate / 12
                    mAccount(pLocationFound).amount = mAccount(pLocationFound).amount + (mAccount(pLocationFound).amount * rate)

                Next pLocationFound
            Catch ex As Exception
            End Try


            Dim theString As String
            theString = pDateTime.ToString("yyyyMMdd") + "; " + pDateTime.ToString("HHmm") + ";" + "Account" + ";" + "AccrueInterestAll" + ";" + pTxnIdPrefix + "; " + pTxnIdStart + "; " + pTxnLineIdPrefix + "; " + pTxnLineIdStart
            _updateStringArray(theString)

        End If

        RaiseEvent Bank_InterestAccured(
            Me,
            New Transaction_EventArgs_TransactionProcessed(
                theTransaction
                )
            )

        Return theTransaction

    End Function '__accureInterest

    Private Function _updateName(
        ByVal theAccount As Account,
        ByVal pAccName As String) _
 As _
 Account

        Dim pLocationFound As Integer

        For pLocationFound = 0 To mAccount.Length - 1

            If mAccount(pLocationFound).accId = theAccount.accId Then
                mAccount(pLocationFound).accName = pAccName
                Exit For
            End If


        Next pLocationFound

        Dim theDate As Date
        theDate = Date.Now
        Dim theString As String
        theString = theDate.ToString("yyyyMMdd") + "; " + theDate.ToString("HHmm") + "; Account ; UpdateName ;" + theAccount.accId + "; " + theAccount.accName
        _updateStringArray(theString)



        Return mAccount(pLocationFound)

    End Function '_updateName

    Private Function _updateInterestRate(
        ByVal theAccount As Account,
        ByVal pInterestRate As Decimal) _
 As _
 Account
        'it updates the interest rate with new interest rate given by user

        Dim pLocationFound As Integer

        For pLocationFound = 0 To mAccount.Length - 1

            If mAccount(pLocationFound).accId = theAccount.accId Then
                mAccount(pLocationFound).interestRate = pInterestRate
                Exit For
            End If


        Next pLocationFound

        Dim theDate As Date
        theDate = Date.Now
        Dim theString As String
        theString = theDate.ToString("yyyyMMdd") + "; " + theDate.ToString("HHmm") + "; Account ; UpdateInterestRate ;" + theAccount.accId + ";" + pInterestRate.ToString
        _updateStringArray(theString)



        Return mAccount(pLocationFound)

    End Function '_updateInterestRate

    Private Function _closeAccount(
        ByVal theAccount As Account
       ) _
 As _
 Account

        Dim theDate As Date
        theDate = Date.Now
        Dim theString As String
        theString = theDate.ToString("yyyyMMdd") + "; " + theDate.ToString("HHmm") + "; Account ; Close ;" + theAccount.accId
        _updateStringArray(theString)


        Return theAccount

    End Function '_closeAccount





#End Region 'Behavioral Methods

#Region "Event Procedures"
    '******************************************************************
    'Event Procedures
    '******************************************************************

    'No Event Procedures are currently defined.

#End Region 'Event Procedures

#Region "Events"
    '******************************************************************
    'Events
    '******************************************************************

    'declaration of all the events raised by this bank class
    Public Event Bank_CustomerAdded(
        ByVal sender As System.Object,
        ByVal e As System.EventArgs)

    Public Event Bank_AccountCreated(
       ByVal sender As System.Object,
       ByVal e As System.EventArgs)

    Public Event Bank_AccountModified(
       ByVal sender As System.Object,
       ByVal e As System.EventArgs)

    Public Event Bank_DepositMade(
       ByVal sender As System.Object,
       ByVal e As System.EventArgs)

    Public Event Bank_WithdrawlMade(
       ByVal sender As System.Object,
       ByVal e As System.EventArgs)

    Public Event Bank_DebitCardUsed(
       ByVal sender As System.Object,
       ByVal e As System.EventArgs)

    Public Event Bank_ChargePurchased(
       ByVal sender As System.Object,
       ByVal e As System.EventArgs)

    Public Event Bank_PaymentMade(
       ByVal sender As System.Object,
       ByVal e As System.EventArgs)

    Public Event Bank_TransferMade(
       ByVal sender As System.Object,
       ByVal e As System.EventArgs)

    Public Event Bank_InterestAccured(
       ByVal sender As System.Object,
       ByVal e As System.EventArgs)

    Public Event Bank_ChangedMetrics(
      ByVal sender As System.Object,
      ByVal e As System.EventArgs)


#End Region 'Events

End Class 'ClsBank
