﻿'Copyright (c) 2009-2016 Dan Turk

#Region "Class / File Comment Header block"
'Program:              Banking
'File:                 ClsTransaction_EventArgs_TransactionProcessed
'Author:               shreesh maurya
'Description:          its event class 
'                      updated: 9 dec 2016
'Date:                 14 nov 2016
'Tier:                 event class
'Exceptions:           none
'Exception-Handling:   none
'Events:               none
'Event-Handling:       none
#End Region 'Class / File Comment Header block

#Region "Option / Imports"
Option Explicit On      'Must declare variables before using them
Option Strict On        'Must perform explicit data type conversions
#End Region 'Option / Imports

Public Class Transaction_EventArgs_TransactionProcessed
    Inherits System.EventArgs

#Region "Attributes"
    '******************************************************************
    'Attributes + Module-level Constants+Variables
    '******************************************************************


    '********** Module-level variables

    Private mTransaction As Transaction

#End Region 'Attributes

#Region "Constructors"
    '******************************************************************
    'Constructors
    '******************************************************************


    'These are all public.

    '********** Special constructor(s)
    '             - typically constructors have parameters 
    '               that are used to initialize attributes

    Public Sub New(
            ByVal pTransaction As Transaction
            )

        'Special constructor - create the EventArgs object.

        MyBase.New()

        _transaction = pTransaction

    End Sub

    '********** Copy constructor(s)
    '             - one parameter, an object of the same class

#End Region 'Constructors

#Region "Get/Set Methods"
    '******************************************************************
    'Get/Set Methods
    '******************************************************************

    '********** Public Get/Set Methods
    '             - call private get/set methods to implement
    Public ReadOnly Property transaction As Transaction
        Get
            Return _transaction
        End Get
    End Property

    'Private Get/Set Methods - access attributes, 
    '                          begin name with underscore (_)

    Private Property _transaction As Transaction
        Get
            Return mTransaction
        End Get
        Set(pValue As Transaction)
            mTransaction = pValue
        End Set
    End Property





#End Region 'Get/Set Methods

#Region "Behavioral Methods"
    '******************************************************************
    'Behavioral Methods
    '******************************************************************


    '********** Public Non-Shared Behavioral Methods

    Public Overrides Function ToString() As String

        'ToString() is the public interface that
        'provides a String version of the data
        'stored in the class attributes.

        Return _toString()

    End Function 'ToString()

    'Private Non-Shared Behavioral Methods

    Private Function _toString() As String

        '_toString() is the private interface that
        'provides a String version of the data
        'stored in the class attributes.
        '_toString() does the actual work of composing
        'and formatting the string.

        Dim tmpStr As String

        tmpStr =
            "( Customer EVENT_ARGS Customer_ADDED: " _
            & "Customer=" & _transaction.ToString _
            & " )"

        Return tmpStr

    End Function '_toString()

#End Region 'Behavioral Methods

#Region "Event Procedures"
    '******************************************************************
    'Event Procedures
    '******************************************************************


#End Region 'Event Procedures

#Region "Events"
    '******************************************************************
    'Events
    '******************************************************************

    'No Events are currently defined.
    'These are all public.

#End Region 'Events

End Class 'Transaction_EventArgs_TransactionProcessed


