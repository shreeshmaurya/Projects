﻿'Copyright (c) 2009-2016 Dan Turk

#Region "Class / File Comment Header block"
'Program:            Banking
'File:               FrmMain.vb
'Author:             Shreesh Maurya
'Description:        User Interface for the Banking project.
'Date:               2016 dec 9 - further implemntationaccording to Project 4
'                    2016 Nov 14 - further implemntationaccording to Project 3
'                    2016 Sep 29
'                      - UI finalized: Dan Turk.  Starting point for Project 2.
'                    2016 18 oct Implementation of classes
'Tier:               User Interface.
'Exceptions:         None Defined.
'Exception-Handling: None.
'Events:             None Defined.
'Event-Handling:     Regular User-Interface Events handled.
#End Region 'Class / File Comment Header block

#Region "Option / Imports"
Option Explicit On      'Must declare variables before using them
Option Strict On        'Must perform explicit data type conversions
Imports System.IO
#End Region 'Option / Imports

Public Class FrmMain

#Region "Attributes"
    '******************************************************************
    'Attributes + Module-level Constants+Variables
    '******************************************************************

    Private Const mFORM_TITLE_DEFAULT As String =
        "BANKING APPLICATION"

    '********** Module-level variables

    Private WithEvents mBank As Bank


#End Region 'Attributes

#Region "Constructors"
    '******************************************************************
    'Constructors
    '******************************************************************

    'No Constructors are currently defined.


#End Region 'Constructors

#Region "Get/Set Methods"
    '******************************************************************
    'Get/Set Methods
    '******************************************************************

    '********** Private Get/Set Methods
    '             - access attributes, begin name with underscore (_)

    Private Property _theBank As Bank
        Get
            Return mBank
        End Get
        Set(pValue As Bank)
            mBank = pValue
        End Set
    End Property



#End Region 'Get/Set Methods

#Region "Behavioral Methods"
    '******************************************************************
    'Behavioral Methods
    '******************************************************************

    '********** Private Non-Shared Behavioral Methods

    Private Sub _initializeBusinessLogic()

        'all the objects are initialized first to be used later on

        _theBank = New Bank("icici", 0, 0, 0, 0)


    End Sub '_initializeBusinessLogic()

    '_processTestData to test all teh constructors and functions
    Private Sub _processTestData()

        Dim theDate = New Date(2016, 9, 9)
        Dim theCustomer1 As Customer
        Dim theCustomer2 As Customer
        Dim theCustomer3 As Customer
        Dim theCustomer4 As Customer

        Dim theAccount1 As Account
        Dim theAccount2 As Account
        Dim theAccount3 As Account
        Dim theAccount4 As Account
        Dim theAccount5 As Account
        Dim theAccount6 As Account
        Dim theAccount7 As Account

        Dim theTransaction1 As Transaction
        Dim theTransaction2 As Transaction
        Dim theTransaction3 As Transaction
        Dim theTransaction4 As Transaction
        Dim theTransaction5 As Transaction

        Dim theTransaction6 As Transaction

        Dim theTransaction7 As Transaction
        Dim theTransaction8 As Transaction

        Dim theTransaction9 As Transaction
        Dim theTransaction10 As Transaction
        Dim theTransaction11 As Transaction
        ' Dim theTransaction12 As Transaction

        Dim custArray() As Customer

        ReDim custArray(0)





        txtTrxLog.Text &=
            vbCrLf _
            & "***** Testing with Constructors *****"

        txtTrxLog.Text &=
        vbCrLf _
           & "-Bank initialized : " & _theBank.ToString




        '********** Testing with Constructors & Behavioral Methods **********

        txtTrxLog.Text &=
            vbCrLf & vbCrLf _
            & "***** Testing with Constructors & Behavioral Methods *****"


        theCustomer1 = _theBank.createCustomerWithRefDate("C1", "SAM SMITH ", New Date(1998, 8, 15), New Date(2016, 11, 4))

        txtTrxLog.Text &=
         vbCrLf _
            & "- customer ADDED: " & theCustomer1.ToString

        theCustomer2 = _theBank.createCustomerWithRefDate("C2", "SALLY JONES ", New Date(2000, 1, 1), New Date(2016, 11, 4))

        txtTrxLog.Text &=
         vbCrLf _
            & "- customer ADDED: " & theCustomer2.ToString

        theCustomer3 = _theBank.createCustomerWithRefDate("C3", "TIM ALFONSO ", New Date(2002, 12, 25), New Date(2016, 11, 4))

        txtTrxLog.Text &=
         vbCrLf _
            & "- customer ADDED: " & theCustomer3.ToString

        theCustomer4 = _theBank.createCustomerWithRefDate("C4", "TERESA WILLABY ", New Date(2002, 12, 1), New Date(2016, 11, 4))

        txtTrxLog.Text &=
         vbCrLf _
            & "- customer ADDED: " & theCustomer4.ToString

        custArray(0) = theCustomer1
        theAccount1 = _theBank.createAccount("A1", "Sam's checking", "1", custArray, New Date(2016, 11, 4), 1.5D, New Date(2016, 12, 4), AccountType.Checking, False, New Date(2029, 10, 10), "T1", "TL1", 1000D)


        txtTrxLog.Text &=
         vbCrLf _
            & "- account created: " & theAccount1.ToString

        custArray(0) = theCustomer1
        theAccount2 = _theBank.createAccount("A2", "Sam's credit card", "1", custArray, New Date(2016, 11, 4), 20D, New Date(2016, 12, 4), AccountType.CreditCard, False, New Date(2029, 10, 10), "T2", "TL2", 0D)

        txtTrxLog.Text &=
         vbCrLf _
            & "- account created: " & theAccount2.ToString

        custArray(0) = theCustomer1
        theAccount3 = _theBank.createAccount("A3", "Sam's house loan", "1", custArray, New Date(2016, 11, 4), 3D, New Date(2016, 12, 4), AccountType.Loan, False, New Date(2029, 10, 10), "T3", "TL3", 100000D)

        txtTrxLog.Text &=
         vbCrLf _
            & "- account created: " & theAccount3.ToString

        custArray(0) = theCustomer1
        theAccount4 = _theBank.createAccount("A4", "Sam's 2nd checking", "1", custArray, New Date(2016, 11, 4), 0D, New Date(2016, 12, 4), AccountType.Checking, False, New Date(2029, 10, 10), "T4", "TL4", 500D)

        txtTrxLog.Text &=
         vbCrLf _
            & "- account created: " & theAccount4.ToString


        custArray(0) = theCustomer2
        theAccount5 = _theBank.createAccount("A5", "Sally's  checking", "1", custArray, New Date(2016, 11, 4), 0.5D, New Date(2016, 12, 4), AccountType.Checking, False, New Date(2029, 10, 10), "T5", "TL5", 1500D)

        txtTrxLog.Text &=
         vbCrLf _
            & "- account created: " & theAccount5.ToString


        custArray(0) = theCustomer4
        theAccount6 = _theBank.createAccount("A6", "Tims's  checking", "1", custArray, New Date(2016, 11, 4), 1D, New Date(2016, 12, 4), AccountType.Checking, False, New Date(2029, 10, 10), "T6", "TL6", 2000D)

        txtTrxLog.Text &=
         vbCrLf _
            & "- account created: " & theAccount6.ToString

        custArray(0) = theCustomer4
        theAccount7 = _theBank.createAccount("A7", "Teresa's  checking", "1", custArray, New Date(2016, 11, 4), 2D, New Date(2016, 12, 4), AccountType.Checking, False, New Date(2029, 10, 10), "T7", "TL7", 100D)

        txtTrxLog.Text &=
         vbCrLf _
            & "- account created: " & theAccount7.ToString




        theTransaction1 = _theBank.makeDeposit("T8", "TL8", TransactionType.MakeDeposit, 500, New Date(2016, 11, 4), "A1", "C1")
        txtTrxLog.Text &=
         vbCrLf _
            & "- deposit made : " & theTransaction1.ToString

        theTransaction2 = _theBank.makeWithdrawl("T9", "TL9", TransactionType.MakeWithdrawal, 250, New Date(2016, 11, 4), "A1", "C1")
        txtTrxLog.Text &=
         vbCrLf _
            & "- withdrawl made : " & theTransaction2.ToString

        theTransaction3 = _theBank.makeUsedebitcard("T10", "TL10", TransactionType.UseDebitCard, 25, New Date(2016, 11, 4), "A1", "C1")
        txtTrxLog.Text &=
         vbCrLf _
             & "- use debit card : " & theTransaction3.ToString

        theTransaction4 = _theBank.makeChargePurchase("T11", "TL11", TransactionType.ChargePurchase, 75, New Date(2016, 11, 4), "A2", "C1")
        txtTrxLog.Text &=
         vbCrLf _
           & "- make charge purchase: " & theTransaction4.ToString

        theTransaction5 = _theBank.makeTransferFund("T12", TransactionType.TransferFunds, 150, New Date(2016, 11, 4), "A4", "A1", "C1", "Placeholder", "Placeholder", "Placeholder", "Placeholder", "TL12", "TL13")
        txtTrxLog.Text &=
         vbCrLf _
            & "- transfer fund : " & theTransaction5.ToString

        theTransaction6 = _theBank.makePayment("T13", TransactionType.MakePayment, 50, New Date(2016, 11, 4), "A1", "A2", "C1", "Placeholder", "Placeholder", "Placeholder", "Placeholder", "TL14", "TL15")
        txtTrxLog.Text &=
         vbCrLf _
            & "- payment made : " & theTransaction6.ToString

        theTransaction7 = _theBank.makePayment("T14", TransactionType.MakePayment, 1500, New Date(2016, 11, 4), "A1", "A3", "C1", "Placeholder", "Placeholder", "Placeholder", "Placeholder", "TL16", "TL17")
        txtTrxLog.Text &=
         vbCrLf _
            & "- payment made : " & theTransaction7.ToString



        theTransaction8 = _theBank.accureInterest("T15", "TL18", TransactionType.SpecificAccount, 0, New Date(2016, 11, 4), "A1", "Placeholder", "Placeholder", "Placeholder", "Placeholder", "Placeholder", "Placeholder")
        txtTrxLog.Text &=
         vbCrLf _
            & "- interest accure : " & theTransaction8.ToString

        theTransaction9 = _theBank.accureInterest("T16", "TL19", TransactionType.SpecificAccount, 0, New Date(2016, 11, 4), "A2", "Placeholder", "Placeholder", "Placeholder", "Placeholder", "Placeholder", "Placeholder")
        txtTrxLog.Text &=
         vbCrLf _
            & "- interest accure  : " & theTransaction9.ToString

        theTransaction10 = _theBank.accureInterest("T17", "TL20", TransactionType.SpecificAccount, 0, New Date(2016, 11, 4), "A3", "Placeholder", "Placeholder", "Placeholder", "Placeholder", "Placeholder", "Placeholder")
        txtTrxLog.Text &=
         vbCrLf _
            & "- interest accure  : " & theTransaction10.ToString

        theTransaction11 = _theBank.accureInterest("T17", "TL20", TransactionType.AllAccounts, 0, New Date(2016, 11, 4), "A3", "Placeholder", "Placeholder", "T", "Placeholder", "TL", "Placeholder")
        txtTrxLog.Text &=
         vbCrLf _
            & "- interest accure  : " & theTransaction11.ToString


        _theBank.addOwner(New Date(2016, 11, 4), "C2", "A1")


        txtTrxLog.Text &=
      vbCrLf _
         & "-Bank final : " & _theBank.ToString



    End Sub '_processTestData

    Private Sub _initializeUserInterface()



        'setting the form titile
        Me.Text = mFORM_TITLE_DEFAULT


    End Sub '_initializeUserInterface()


#End Region 'Behavioral Methods

#Region "Event Procedures"
    '******************************************************************
    'Event Procedures
    '******************************************************************

    'No Event Procedures are currently defined.
    'These are all private.

    '********** User-Interface Event Procedures
    '             - Initiated explicitly by user

    'create customer button implementation on customer tab
    Private Sub _btnCreateCustomerGrpCreateTabCustomerTbcMain_Click(
           sender As Object,
           e As EventArgs) _
       Handles _
           btnCreateCustomerGrpCreateTabCustomerTbcMain.Click

        Dim theID As String
        Dim theName As String
        Dim theDate As Date
        Dim theCustomer As Customer

        Me.AcceptButton = btnCreateCustomerGrpCreateTabCustomerTbcMain

        'Validation to check whether the fields are emoty and values entered is according to their type.
        theID = cboCustomerIDTabCustomerTbcMain.Text
        If theID = "" Then
            MessageBox.Show(
                "No Account ID entered.  " _
                & "Please enter a   ID.  ")
            cboCustomerIDTabCustomerTbcMain.SelectAll()
            cboCustomerIDTabCustomerTbcMain.Focus()
            Exit Sub
        End If

        For Each cus As Customer In _theBank.iterateCustomer

            If cus.custId = theID Then
                MessageBox.Show("customer id already exists , please enter new one ")
                Exit Sub
            End If

        Next cus



        theName = txtNameGrpCreateTabCustomerTbcMain.Text
        If theName = "" Then
            MessageBox.Show(
                "No NAME entered.  " _
                & "Please enter a  NAME  ")
            txtNameGrpCreateTabCustomerTbcMain.SelectAll()
            txtNameGrpCreateTabCustomerTbcMain.Focus()
            Exit Sub
        End If


        'Validation for checking whether date entered is not ahead of time
        Try
            theDate = CDate(dtpBirthdateGrpCreateTabCustomerTbcMain.Text)
            If theDate > DateTime.Now _
            Then Throw New Exception

        Catch ex As Exception
            MessageBox.Show("invalid date, Please enter valid")

        End Try

        theCustomer = _theBank.createCustomer(theID, theName, theDate)

        txtTrxLog.Text &=
      vbCrLf _
         & "-Bank final : " & _theBank.ToString

        'txtTrxLog.Text &=
        ' vbCrLf _
        '    & "- customer ADDED: " & theCustomer.ToString

        'Getting ready for new entry
        cboCustomerIDTabCustomerTbcMain.Text = ""
        txtNameGrpCreateTabCustomerTbcMain.Text = ""
        dtpBirthdateGrpCreateTabCustomerTbcMain.Text = ""

    End Sub '_btnCreateCustomerGrpCreateTabCustomerTbcMain_Click


    'implementation of create account button from Accounts tab
    Private Sub _btnCreateAccountTabAccountTbcMain_Click(
           sender As Object,
           e As EventArgs) _
       Handles _
           btnCreateAccountTabAccountTbcMain.Click

        Dim theAccId As String
        Dim theAccName As String
        Dim theNumOwners As String
        Dim theOwner() As Customer
        Dim theDateOpened As Date
        Dim theInterestRate As Decimal
        Dim theAccuralDate As Date
        Dim theType As AccountType
        Dim theIsClosed As Boolean
        Dim theClosedDate As Date
        Dim theTrxId As String
        Dim theTrxLineId As String
        Dim theAmount As Decimal
        Dim theAccount As Account

        'sets the accept button to Create account
        Me.AcceptButton = btnCreateAccountTabAccountTbcMain

        theAccId = cboAccountIDTabAccountTbcMain.Text
        If theAccId = "" Then
            MessageBox.Show(
                "No Account ID entered.  " _
                & "Please enter a Account ID.  "
                                )
            cboAccountIDTabAccountTbcMain.SelectAll()
            cboAccountIDTabAccountTbcMain.Focus()
            Exit Sub
        End If

        For Each acc As Account In _theBank.iterateAccount

            If acc.accId = theAccId Then
                MessageBox.Show("accountid already exists , please enter new one ")
                Exit Sub
            End If

        Next acc


        theAccName = txtNameGrpCreateModifyTabAccountTbcMain.Text
        If theAccName = "" Then
            MessageBox.Show(
                "No Account name entered.  " _
                & "Please enter a Account name.  "
                                )
            txtNameGrpCreateModifyTabAccountTbcMain.SelectAll()
            txtNameGrpCreateModifyTabAccountTbcMain.Focus()
            Exit Sub
        End If



        Try
            theDateOpened = CDate(dtpDateOpenedGrpCreateModifyTabAccountTbcMain.Text)
            If theDateOpened > Date.Now _
            Then Throw New Exception
        Catch ex As Exception
            MessageBox.Show("invalid date, Please enter valid date again")
            Exit Sub
        End Try


        Try
            theInterestRate = Decimal.Parse(nudAPRGrpCreateModifyTabAccountTbcMain.Text)
        Catch ex As Exception
            MessageBox.Show(
                "Invalid Interest rate entered.  " _
                & "Please enter a valid number  " _
                & "Ex: 1"
                )

            nudAPRGrpCreateModifyTabAccountTbcMain.Focus()
            Exit Sub
        End Try




        theAccuralDate = CDate(dtpNextInterestAccrualDateGrpCreateModifyTabAccountTbcMain.Text)




        'gets the radio button selected  
        Dim rButton As RadioButton =
        grpTypeGrpCreateModifyTabAccountTbcMain.Controls.OfType(Of RadioButton).FirstOrDefault(Function(r) r.Checked = True)

        'setting type of account as per the radio button text fetched
        If rButton.Text = "Checking" Then
            theType = AccountType.Checking
        ElseIf rButton.Text = "Loan" Then
            theType = AccountType.Loan
        Else
            theType = AccountType.CreditCard
        End If


        theIsClosed = chkClosedGrpClosedTabAccountTbcMain.Checked

        Try
            theClosedDate = CDate(dtpClosedDateGrpClosedTabAccountTbcMain.Text)
            If theClosedDate > DateTime.Now _
            Then Throw New Exception
        Catch ex As Exception
            MessageBox.Show("invalid accural date, Please enter valid")

        End Try


        theTrxId = txtTrxIDGrpCreateModifyTabAccountTbcMain.Text

        If theTrxId = "" Then
            MessageBox.Show(
                "No transaction id entered.  " _
                & "Please enter a transaction id.  "
                                )
            txtTrxIDGrpCreateModifyTabAccountTbcMain.SelectAll()
            txtTrxIDGrpCreateModifyTabAccountTbcMain.Focus()
            Exit Sub
        End If

        For Each acc As Account In _theBank.iterateAccount

            If acc.trxId = theTrxId Then
                MessageBox.Show("txn id  already exists , please enter new one ")
                Exit Sub
            End If

        Next acc



        Try
            theAmount = Decimal.Parse(txtAmountGrpCreateModifyTabAccountTbcMain.Text)
        Catch ex As Exception
            MessageBox.Show(
                "Invalid amount entered.  " _
                & "Please enter a valid number  " _
                & "Ex: 1"
                )

            txtAmountGrpCreateModifyTabAccountTbcMain.Focus()
            Exit Sub
        End Try

        theTrxLineId = txtTrxLineIDGrpCreateModifyTabAccountTbcMain.Text

        If theTrxLineId = "" Then
            MessageBox.Show(
                "No transaction line id name entered.  " _
                & "Please enter a transaction line id.  "
                                )
            txtTrxLineIDGrpCreateModifyTabAccountTbcMain.SelectAll()
            txtTrxLineIDGrpCreateModifyTabAccountTbcMain.Focus()
            Exit Sub
        End If

        For Each acc As Account In _theBank.iterateAccount

            If acc.trxLineId = theTrxLineId Then
                MessageBox.Show("txn line id  already exists , please enter new one ")
                Exit Sub
            End If

        Next acc


        If lstNewOwnerIDGrpCreateModifyTabAccountTbcMain.Items.Count = 0 Then
            MessageBox.Show(
                "No owner selected, please select owner  "
                                              )
            cboCustomerIDGrpCreateModifyTabAccountTbcMain.SelectAll()
            cboCustomerIDGrpCreateModifyTabAccountTbcMain.Focus()
            Exit Sub
        End If



        theNumOwners = CType(lstNewOwnerIDGrpCreateModifyTabAccountTbcMain.Items.Count, String)
        Dim foundCust As Customer

        ReDim theOwner(lstNewOwnerIDGrpCreateModifyTabAccountTbcMain.Items.Count - 1)

        Dim i As Integer
        i = 0

        For pLocationFound = 0 To lstNewOwnerIDGrpCreateModifyTabAccountTbcMain.Items.Count - 1
            foundCust = mBank.findCustomer(lstNewOwnerIDGrpCreateModifyTabAccountTbcMain.Items(i).ToString)

            theOwner(i) = foundCust
                i = i + 1

        Next pLocationFound




        theAccount = _theBank.createAccount(theAccId, theAccName, theNumOwners, theOwner, theDateOpened, theInterestRate, theAccuralDate, theType, theIsClosed, theClosedDate, theTrxId, theTrxLineId, theAmount)

        'txtTrxLog.Text &=
        ' vbCrLf _
        '    & "- account created: " & theAccount.ToString

        'getting ready for new input
        cboAccountIDTabAccountTbcMain.Text = ""
        cboCustomerIDGrpCreateModifyTabAccountTbcMain.Text = ""
        txtNameGrpCreateModifyTabAccountTbcMain.Text = ""
        nudAPRGrpCreateModifyTabAccountTbcMain.Text = ""
        txtTrxIDGrpCreateModifyTabAccountTbcMain.Text = ""
        txtTrxLineIDGrpCreateModifyTabAccountTbcMain.Text = ""
        dtpNextInterestAccrualDateGrpCreateModifyTabAccountTbcMain.Text = ""
        dtpClosedDateGrpClosedTabAccountTbcMain.Text = ""
        dtpDateOpenedGrpCreateModifyTabAccountTbcMain.Text = ""
        txtAmountGrpCreateModifyTabAccountTbcMain.Text = ""


    End Sub '_btnCreateAccountTabAccountTbcMain_Click

    'sub to handle click event on modify account
    Private Sub _btnModifyAccountTabAccountTbcMain_Click(
           sender As Object,
           e As EventArgs) _
       Handles _
           btnModifyAccountTabAccountTbcMain.Click

        Dim theAccId As String
        Dim theAccName As String

        Dim theOwner() As Customer

        Dim theInterestRate As Decimal

        Dim theIsClosed As Boolean
        Dim theClosedDate As Date


        Dim theAccount As Account


        theAccId = cboAccountIDTabAccountTbcMain.Text
        If theAccId = "" Then
            MessageBox.Show(
                "No Account ID entered.  " _
                & "Please enter a Account ID.  "
                                )
            cboAccountIDTabAccountTbcMain.SelectAll()
            cboAccountIDTabAccountTbcMain.Focus()
            Exit Sub
        End If



        theAccName = txtNameGrpCreateModifyTabAccountTbcMain.Text
        If theAccName = "" Then
            MessageBox.Show(
                "No Account name entered.  " _
                & "Please enter a Account name.  "
                                )
            txtNameGrpCreateModifyTabAccountTbcMain.SelectAll()
            txtNameGrpCreateModifyTabAccountTbcMain.Focus()
            Exit Sub
        End If






        Try
            theInterestRate = Decimal.Parse(nudAPRGrpCreateModifyTabAccountTbcMain.Text)
        Catch ex As Exception
            MessageBox.Show(
                "Invalid Interest rate entered.  " _
                & "Please enter a valid number  " _
                & "Ex: 1"
                )

            nudAPRGrpCreateModifyTabAccountTbcMain.Focus()
            Exit Sub
        End Try



        theIsClosed = chkClosedGrpClosedTabAccountTbcMain.Checked

        Try
            theClosedDate = CDate(dtpClosedDateGrpClosedTabAccountTbcMain.Text)
            If theClosedDate > DateTime.Now _
            Then Throw New Exception
        Catch ex As Exception
            MessageBox.Show("invalid accural date, Please enter valid")
            Exit Sub
        End Try


        Dim foundCust As Customer
        Dim maxOwner As Integer

        maxOwner = 2
        ReDim theOwner(lstNewOwnerIDGrpCreateModifyTabAccountTbcMain.Items.Count - 1)


        Dim i As Integer
        i = 0

        For pLocationFound = 0 To lstNewOwnerIDGrpCreateModifyTabAccountTbcMain.Items.Count - 1
            foundCust = mBank.findCustomer(lstNewOwnerIDGrpCreateModifyTabAccountTbcMain.Items(i).ToString)

            theOwner(i) = foundCust
            i = i + 1

        Next pLocationFound



        theAccount = _theBank.modifyAccount(theAccId, theAccName, theOwner, theInterestRate, theIsClosed, theClosedDate)

        'txtTrxLog.Text &=
        ' vbCrLf _
        '    & "- account modified: " & theAccount.ToString

        'getting ready for new input
        cboAccountIDTabAccountTbcMain.Text = ""
        cboCustomerIDGrpCreateModifyTabAccountTbcMain.Text = ""
        txtNameGrpCreateModifyTabAccountTbcMain.Text = ""
        nudAPRGrpCreateModifyTabAccountTbcMain.Text = ""
        txtTrxIDGrpCreateModifyTabAccountTbcMain.Text = ""
        txtTrxLineIDGrpCreateModifyTabAccountTbcMain.Text = ""
        dtpNextInterestAccrualDateGrpCreateModifyTabAccountTbcMain.Text = ""
        dtpClosedDateGrpClosedTabAccountTbcMain.Text = ""
        dtpDateOpenedGrpCreateModifyTabAccountTbcMain.Text = ""
        lstNewOwnerIDGrpCreateModifyTabAccountTbcMain.Items.Clear()
        cboCustomerIDGrpCreateModifyTabAccountTbcMain.Text = ""
        txtAmountGrpCreateModifyTabAccountTbcMain.Text = ""

        dtpDateOpenedGrpCreateModifyTabAccountTbcMain.Enabled = True
        txtAmountGrpCreateModifyTabAccountTbcMain.Enabled = True
        txtTrxIDGrpCreateModifyTabAccountTbcMain.Enabled = True
        txtTrxLineIDGrpCreateModifyTabAccountTbcMain.Enabled = True
        grpTypeGrpCreateModifyTabAccountTbcMain.Enabled = True
        grpCreateModifyTabAccountTbcMain.Enabled = True

    End Sub '_btnModifyAccountTabAccountTbcMain_Click

    'implements click on Process transaction button of tab Make deposits
    Private Sub _btnProcessTrxTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain_Click(
           sender As Object,
           e As EventArgs) _
       Handles _
           btnProcessTrxTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Click

        Dim theTxnId As String
        Dim theTxnLine As String
        Dim theAmount As Decimal
        Dim theDateTime As Date
        Dim theCustId As String
        Dim theAccountId As String
        Dim theTransaction As Transaction

        Me.AcceptButton = btnProcessTrxTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain

        theTxnId = txtTrxIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text
        If theTxnId = "" Then
            MessageBox.Show(
                "No transaction id entered.  " _
                & "Please enter a transaction id.  "
                                )
            txtTrxIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.SelectAll()
            txtTrxIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Focus()
            Exit Sub
        End If



        theTxnLine = txtTrxLineIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text
        If theTxnLine = "" Then
            MessageBox.Show(
                "No transaction line id entered.  " _
                & "Please enter a transaction line id.  "
                                )
            txtTrxLineIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.SelectAll()
            txtTrxLineIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Focus()
            Exit Sub
        End If


        Dim rButton As RadioButton =
        grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.OfType(Of RadioButton).FirstOrDefault(Function(r) r.Checked = True)
        '  theType = rButton.Text

        Try
            theAmount = Decimal.Parse(nudAmountTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text)
        Catch ex As Exception
            MessageBox.Show(
                "Invalid amount entered.  " _
                & "Please enter a valid amount  " _
                & "Ex: 1"
                )

            nudAmountTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Focus()
            Exit Sub
        End Try



        theDateTime = CDate(dtpTrxDateTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text)
        Try
            theDateTime = CDate(dtpTrxDateTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text)
            If theDateTime > DateTime.Now _
            Then Throw New Exception
        Catch ex As Exception
            MessageBox.Show("invalid  date, Please enter valid")

        End Try

        theCustId = cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text
        If theCustId = "" Then
            MessageBox.Show(
                "No customer id selected.    " _
                & "Please enter a customer id.  "
                                )
            cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.SelectAll()
            cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Focus()
            Exit Sub
        End If

        theAccountId = cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text
        If theAccountId = "" Then
            MessageBox.Show(
                "No from account id selected.    " _
                & "Please select from account id.  "
                                )
            cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.SelectAll()
            cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Focus()
            Exit Sub
        End If


        For Each acc As Account In _theBank.iterateAccount

            If acc.trxId = theTxnId Then
                MessageBox.Show("txn id  already exists , please enter new one ")
                Exit Sub
            End If

        Next acc

        For Each acc As Account In _theBank.iterateAccount

            If acc.trxLineId = theTxnLine Then
                MessageBox.Show("txn line id  already exists , please enter new one ")
                Exit Sub
            End If

        Next acc



        'calls appropriate function as per selection of radio button
        If rButton.Text = "Make Deposit" Then
            theTransaction = _theBank.makeDeposit(theTxnId, theTxnLine, TransactionType.MakeDeposit, theAmount, theDateTime, theAccountId, theCustId)
        End If

        If rButton.Text = "Make Withdrawal" Then
            theTransaction = _theBank.makeWithdrawl(theTxnId, theTxnLine, TransactionType.MakeWithdrawal, theAmount, theDateTime, theAccountId, theCustId)
        End If

        If rButton.Text = "Use Debit Card" Then
            theTransaction = _theBank.makeUsedebitcard(theTxnId, theTxnLine, TransactionType.UseDebitCard, theAmount, theDateTime, theAccountId, theCustId)
        End If

        If rButton.Text = "Charge Purchase" Then
            theTransaction = _theBank.makeChargePurchase(theTxnId, theTxnLine, TransactionType.ChargePurchase, theAmount, theDateTime, theAccountId, theCustId)
        End If


        'txtTrxLog.Text &=
        ' vbCrLf _
        '    & "- deposit made : " & theTransaction.ToString

        'getting ready for new input
        txtTrxIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = ""
        txtTrxLineIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = ""
        nudAmountTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = ""
        dtpTrxDateTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = ""
        cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = ""
        cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = ""



    End Sub '_btnProcessTrxTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain_Click

    'implements click on Process transaction button of tab Make payments
    Private Sub _btnProcessTransactionTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain_Click(
           sender As Object, e As EventArgs) _
       Handles _
           btnProcessTransactionTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Click

        Dim theTxnId As String
        Dim theFromTxnLine As String
        Dim theToTxnLine As String
        Dim theType As String
        Dim theAmount As Decimal
        Dim theDateTime As Date
        Dim theCustId As String
        Dim theAccountId As String
        Dim theAccountIdTo As String
        Dim theTransaction As Transaction

        Me.AcceptButton = btnProcessTransactionTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain


        theTxnId = txtTrxIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text
        If theTxnId = "" Then
            MessageBox.Show(
                "No transaction id entered.    " _
                & "Please enter a transaction id.  "
                                )
            txtTrxIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.SelectAll()
            txtTrxIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Focus()
            Exit Sub
        End If

        theCustId = cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text
        If theCustId = "" Then
            MessageBox.Show(
                "No customer id selected.    " _
                & "Please enter a customer id.  "
                                )
            cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.SelectAll()
            cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Focus()
            Exit Sub
        End If

        theAccountId = cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text
        If theAccountId = "" Then
            MessageBox.Show(
                "No from account id selected.    " _
                & "Please select from account id.  "
                                )
            cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.SelectAll()
            cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Focus()
            Exit Sub
        End If

        theAccountIdTo = cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text
        If theAccountIdTo = "" Then
            MessageBox.Show(
                "No from account id selected.    " _
                & "Please select from account id.  "
                                )
            cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.SelectAll()
            cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Focus()
            Exit Sub
        End If

        theFromTxnLine = txtFromTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text
        If theFromTxnLine = "" Then
            MessageBox.Show(
                "No fromtransaction line id entered.  " _
                & "Please enter a from transaction line id.  "
                                )
            txtFromTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.SelectAll()
            txtFromTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Focus()
            Exit Sub
        End If

        theToTxnLine = txtToTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text
        If theToTxnLine = "" Then
            MessageBox.Show(
                "No fromtransaction line id entered.  " _
                & "Please enter a from transaction line id.  "
                                )
            txtToTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.SelectAll()
            txtToTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Focus()
            Exit Sub
        End If


        Dim rButton As RadioButton =
        grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.OfType(Of RadioButton).FirstOrDefault(Function(r) r.Checked = True)
        theType = rButton.Text


        Try
            theAmount = Decimal.Parse(nudTrxLineAmountTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text)
        Catch ex As Exception
            MessageBox.Show(
                "Invalid amount entered.  " _
                & "Please enter a valid amount  " _
                & "Ex: 1"
                )

            nudTrxLineAmountTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Focus()
            Exit Sub
        End Try

        Try
            theDateTime = CDate(dtpTrxDateTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text)
            If theDateTime > DateTime.Now _
            Then Throw New Exception

        Catch ex As Exception
            MessageBox.Show("invalid dob enter valid")

        End Try

        If theFromTxnLine = theToTxnLine Then
            MessageBox.Show("transaction id , from and to cant be same.")
            txtToTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Focus()
            txtFromTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Focus()
            Exit Sub
        End If

        If theAccountId = theAccountIdTo Then
            MessageBox.Show("from and to account cant be same.")
            cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Focus()
            cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Focus()
            Exit Sub
        End If




        ' if selection used to call function as per the radio button selection
        If theType = "Make Payment" Then
            theTransaction = _theBank.makePayment(theTxnId, TransactionType.MakePayment, theAmount, theDateTime, theAccountId, theAccountIdTo, theCustId, "Placeholder", "Placeholder", "Placeholder", "Placeholder", theFromTxnLine, theToTxnLine)
        End If

        If theType = "Transfer Funds" Then
            theTransaction = _theBank.makeTransferFund(theTxnId, TransactionType.TransferFunds, theAmount, theDateTime, theAccountId, theAccountIdTo, theCustId, "Placeholder", "Placeholder", "Placeholder", "Placeholder", theFromTxnLine, theToTxnLine)
        End If



        txtTrxIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = ""

        nudTrxLineAmountTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = ""
        cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = ""
        cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = ""
        cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = ""
        dtpTrxDateTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = ""
        cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = ""
        cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = ""
        cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = ""
        txtFromTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = ""
        txtToTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = ""

    End Sub '_btnProcessTransactionTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain_Click



    'this reads files and calls differentmethods accordingly
    Private Sub btnOpenTabFilesTbcMain_Click(sender As Object, e As EventArgs) Handles btnOpenTabFilesTbcMain.Click

        Dim inputFile As StreamReader
        Dim line As String
        Dim field() As String
        Dim dateOpen As Date
        Dim birthDate As Date
        Dim accuralDate As Date
        Dim pOwner() As Customer
        ReDim pOwner(0)

        Dim fileName As String

        fileName = txtFileNameTabFilesTbcMain.Text
        If fileName = "" Then
            MessageBox.Show(
                "Please enter filename  "
                                )
            txtFileNameTabFilesTbcMain.SelectAll()
            txtFileNameTabFilesTbcMain.Focus()
            Exit Sub
        End If

        'checks if input file does not exist
        Try
            inputFile = New StreamReader(fileName)
        Catch ex As FileNotFoundException
            MessageBox.Show(
               "File not Found, enter correct file "
                               )
            Exit Sub
        End Try


        Do While Not inputFile.EndOfStream

            line = inputFile.ReadLine
            field = Split(line, ";")

            'skips line which are blank and starts with comments
            If line.StartsWith("# ") = True Then

                Continue Do
            End If

            If field.Count = 1 Then

                Continue Do
            End If

            If Trim(field(2)) = "Customer" And Trim(field(3)) = "Create" Then

                birthDate = New Date(Integer.Parse(Trim(field(6)).Substring(0, 4)), Integer.Parse(Trim(field(6)).Substring(4, 2)), Integer.Parse(Trim(field(6)).Substring(6, 2)))
                Dim date1 As DateTime
                date1 = New Date(Integer.Parse(Trim(field(0)).Substring(0, 4)), Integer.Parse(Trim(field(0)).Substring(4, 2)), Integer.Parse(Trim(field(0)).Substring(6, 2)))

                Dim theCustomer1 = _theBank.createCustomerWithRefDate(Trim(field(4)), Trim(field(5)), birthDate, date1)




            End If


            If Trim(field(3)) = "Open" Then
                Dim theAccount As Account
                dateOpen = New Date(Integer.Parse(Trim(field(0)).Substring(0, 4)), Integer.Parse(Trim(field(0)).Substring(4, 2)), Integer.Parse(Trim(field(0)).Substring(6, 2)))
                accuralDate = _theBank.findNextAccuralDate(dateOpen)

                pOwner(0) = _theBank.findCustomer(Trim(field(9)))

                If Trim(field(4)) = "Checking" Then
                    theAccount = _theBank.createAccount(Trim(field(7)), Trim(field(8)), "1", pOwner, dateOpen, CType(Trim(field(11)), Decimal), accuralDate, AccountType.Checking, False, New Date(2000, 1, 1), Trim(field(5)), Trim(field(6)), CType(Trim(field(10)), Decimal))
                End If

                If Trim(field(4)) = "CreditCard" Then
                    theAccount = _theBank.createAccount(Trim(field(7)), Trim(field(8)), "1", pOwner, dateOpen, CType(Trim(field(10)), Decimal), accuralDate, AccountType.CreditCard, False, New Date(2000, 1, 1), Trim(field(5)), Trim(field(6)), 0)
                End If

                If Trim(field(4)) = "Loan" Then
                    theAccount = _theBank.createAccount(Trim(field(7)), Trim(field(8)), "1", pOwner, dateOpen, CType(Trim(field(11)), Decimal), accuralDate, AccountType.Loan, False, New Date(2000, 1, 1), Trim(field(5)), Trim(field(6)), CType(Trim(field(10)), Decimal))
                End If


            End If

            If Trim(field(2)) = "Account" And Trim(field(3)) = "AddOwner" Then


                Dim theOwner = _theBank.addOwner(New Date(Integer.Parse(Trim(field(0)).Substring(0, 4)), Integer.Parse(Trim(field(0)).Substring(4, 2)), Integer.Parse(Trim(field(0)).Substring(6, 2))), Trim(field(5)), Trim(field(4)))

            End If

            If Trim(field(2)) = "Customer" Then

                Dim theTransaction As Transaction

                Dim date1 As Date
                date1 = New Date(Integer.Parse(Trim(field(0)).Substring(0, 4)), Integer.Parse(Trim(field(0)).Substring(4, 2)), Integer.Parse(Trim(field(0)).Substring(6, 2)))

                If Trim(field(3)) = "MakeDeposit" Then

                    theTransaction = _theBank.makeDeposit(Trim(field(4)), Trim(field(5)), TransactionType.MakeDeposit, CType(Trim(field(8)), Decimal), date1, Trim(field(7)), Trim(field(6)))

                ElseIf Trim(field(3)) = "MakeWithdrawal" Then

                    theTransaction = _theBank.makeWithdrawl(Trim(field(4)), Trim(field(5)), TransactionType.MakeWithdrawal, CType(Trim(field(8)), Decimal), date1, Trim(field(7)), Trim(field(6)))

                ElseIf Trim(field(3)) = "UseDebitCard" Then

                    theTransaction = _theBank.makeUsedebitcard(Trim(field(4)), Trim(field(5)), TransactionType.UseDebitCard, CType(Trim(field(8)), Decimal), date1, Trim(field(7)), Trim(field(6)))

                ElseIf Trim(field(3)) = "ChargePurchase" Then

                    theTransaction = _theBank.makeChargePurchase(Trim(field(4)), Trim(field(5)), TransactionType.ChargePurchase, CType(Trim(field(8)), Decimal), date1, Trim(field(7)), Trim(field(6)))

                ElseIf Trim(field(3)) = "TransferFunds" Then

                    theTransaction = _theBank.makeTransferFund(Trim(field(4)), TransactionType.TransferFunds, CType(Trim(field(10)), Decimal), date1, Trim(field(8)), Trim(field(9)), Trim(field(7)), "PLACEHOLDER", "PLACEHOLDER", "PLACEHOLDER", "PLACEHOLDER", Trim(field(5)), Trim(field(6)))

                ElseIf Trim(field(3)) = "MakePayment" Then

                    theTransaction = _theBank.makePayment(Trim(field(4)), TransactionType.MakePayment, CType(Trim(field(10)), Decimal), date1, Trim(field(8)), Trim(field(9)), Trim(field(7)), "PLACEHOLDER", "PLACEHOLDER", "PLACEHOLDER", "PLACEHOLDER", Trim(field(5)), Trim(field(6)))
                End If


            End If

            If Trim(field(2)) = "Account" And Trim(field(3)) = "AccrueInterestIndividual" Then

                Dim theTransaction As Transaction
                Dim date1 As Date
                date1 = New Date(Integer.Parse(Trim(field(0)).Substring(0, 4)), Integer.Parse(Trim(field(0)).Substring(4, 2)), Integer.Parse(Trim(field(0)).Substring(6, 2)))


                theTransaction = _theBank.accureInterest(Trim(field(4)), Trim(field(5)), TransactionType.SpecificAccount, 0D, date1, Trim(field(6)), "PLACEHOLDER", "PLACEHOLDER", "PLACEHOLDER", "PLACEHOLDER", "PLACEHOLDER", "PLACEHOLDER")



            End If

            If Trim(field(2)) = "Account" And Trim(field(3)) = "AccrueInterestAll" Then

                Dim theTransaction As Transaction
                Dim date1 As Date
                date1 = New Date(Integer.Parse(Trim(field(0)).Substring(0, 4)), Integer.Parse(Trim(field(0)).Substring(4, 2)), Integer.Parse(Trim(field(0)).Substring(6, 2)))


                theTransaction = _theBank.accureInterest("PLACEHOLDER", "PLACEHOLDER", TransactionType.AllAccounts, 0D, date1, "PLACEHOLDER", "PLACEHOLDER", "PLACEHOLDER", Trim(field(4)), Trim(field(5)), Trim(field(6)), Trim(field(7)))

            End If

            If Trim(field(2)) = "Account" And Trim(field(3)) = "UpdateName" Then

                Dim theAccount1 As Account
                Dim theAccount2 As Account
                theAccount1 = _theBank.findAccount(Trim(field(4)))
                theAccount2 = _theBank.updateName(theAccount1, Trim(field(4)))
                txtTrxLog.Text &=
                 vbCrLf _
                    & "- Name updated  : " & theAccount2.ToString
            End If

            If Trim(field(2)) = "Account" And Trim(field(3)) = "Close" Then

                Dim theAccount1 As Account
                Dim theAccount2 As Account
                theAccount1 = _theBank.findAccount(Trim(field(4)))
                theAccount2 = _theBank.closeAccount(theAccount1)
                txtTrxLog.Text &=
                 vbCrLf _
                    & "- Account Closed  : " & theAccount2.ToString
            End If

            If Trim(field(2)) = "Account" And Trim(field(3)) = "UpdateInterestRate" Then

                Dim theAccount1 As Account
                Dim theAccount2 As Account
                theAccount1 = _theBank.findAccount(Trim(field(4)))
                theAccount2 = _theBank.updateInterestRate(theAccount1, CType(Trim(field(5)), Decimal))
                txtTrxLog.Text &=
                 vbCrLf _
                    & "- Interest rate updated  : " & theAccount2.ToString()
            End If





        Loop
        inputFile.Close()


    End Sub


    'saves output to a new file given by user
    Private Sub btnSaveTabFilesTbcMain_Click(sender As Object, e As EventArgs) Handles btnSaveTabFilesTbcMain.Click


        Dim outputfile As StreamWriter

        Dim fileName As String

        fileName = txtFileNameTabFilesTbcMain.Text
        If fileName = "" Then
            MessageBox.Show(
                "Please enter filename  "
                                )
            txtFileNameTabFilesTbcMain.SelectAll()
            txtFileNameTabFilesTbcMain.Focus()
            Exit Sub
        End If


        outputfile = New StreamWriter(fileName)

        Dim intC As Integer = 0

        Do While intC < _theBank.stringEntries.Length
            outputfile.WriteLine(_theBank.stringEntries(intC))
            intC += 1
        Loop

        txtTrxLog.Text &=
                 vbCrLf _
                    & "- File saved  : "

        outputfile.Close()

    End Sub




    'implements click on Process data button
    Private Sub _btnProcessTestDataTabFilesTbcMain_Click(
           sender As Object,
           e As EventArgs) _
       Handles _
           btnProcessTestDataTabFilesTbcMain.Click

        'this process test data call private part which calls constructors and methods with hard coded values
        _processTestData()

    End Sub '_btnProcessTestDataTabFilesTbcMain_Click

    'implements accure interest on transaction tab
    Private Sub btnAccrueInterestTabAccrueInterestTbcTransactionsTabTransactionsTbcMain_Click(sender As Object, e As EventArgs) Handles btnAccrueInterestTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Click

        Dim theType As String
        Dim theTxnIdPrefix As String
        Dim theTxnIdStart As String
        Dim theTxnLineIdPrefix As String
        Dim theTxnLineIdStart As String
        Dim theAccountId As String
        Dim theTxnId As String
        Dim theTxnLineId As String
        Dim theTransaction As Transaction


        Dim rButton As RadioButton =
        tabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.OfType(Of RadioButton).FirstOrDefault(Function(r) r.Checked = True)
        theType = rButton.Text

        'selection according to the radio button selected 
        If theType = "All Accounts" Then

            theTxnIdPrefix = txtTrxIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text
            If theTxnIdPrefix = "" Then
                MessageBox.Show(
                "No transaction   id Prefix entered.  " _
                & "Please enter a transaction   id Prefix.  "
                                )
                txtTrxIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.SelectAll()
                txtTrxIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Focus()
                Exit Sub
            End If

            theTxnIdStart = txtTrxIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text
            If theTxnIdStart = "" Then
                MessageBox.Show(
                "No transaction   id Start entered.  " _
                & "Please enter a transaction   id start.  "
                                )
                txtTrxIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.SelectAll()
                txtTrxIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Focus()
                Exit Sub
            End If

            theTxnLineIdPrefix = txtTrxLineIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text
            If theTxnLineIdPrefix = "" Then
                MessageBox.Show(
                "No transaction line id prefix entered.  " _
                & "Please enter a transaction line id prefix.  "
                                )
                txtTrxLineIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.SelectAll()
                txtTrxLineIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Focus()
                Exit Sub
            End If

            theTxnLineIdStart = txtTrxLineIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text
            If theTxnLineIdStart = "" Then
                MessageBox.Show(
                "No transaction line id start entered.  " _
                & "Please enter a transaction line id start.  "
                                )
                txtTrxLineIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.SelectAll()
                txtTrxLineIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Focus()
                Exit Sub
            End If

            theTransaction = _theBank.accureInterest("Placeholder", "Placeholder", TransactionType.AllAccounts, 0, New Date(9999, 9, 9), "Placeholder", "Placeholder", "Placeholder", theTxnIdPrefix, theTxnIdStart, theTxnLineIdPrefix, theTxnLineIdStart)

        End If

        If theType = "Specific Account" Then

            theTxnId = txtTrxIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text
            If theTxnId = "" Then
                MessageBox.Show(
                "No transaction   id entered.  " _
                & "Please enter a transaction   id.  "
                                )
                txtTrxIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.SelectAll()
                txtTrxIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Focus()
                Exit Sub
            End If

            theTxnLineId = txtTrxLineIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text
            If theTxnLineId = "" Then
                MessageBox.Show(
                "No transaction line id entered.  " _
                & "Please enter a transaction line id.  "
                                )
                txtTrxLineIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.SelectAll()
                txtTrxLineIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Focus()
                Exit Sub
            End If

            theAccountId = cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text
            If theTxnId = "" Then
                MessageBox.Show(
                "No account   id entered.  " _
                & "Please enter a account   id.  "
                                )
                cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.SelectAll()
                cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Focus()
                Exit Sub
            End If

            theTransaction = _theBank.accureInterest(theTxnId, theTxnLineId, TransactionType.SpecificAccount, 0, New Date(9999, 9, 9), theAccountId, "Placeholder", "Placeholder", "Placeholder", "Placeholder", "Placeholder", "Placeholder")


        End If



        'getting ready for new input
        txtTrxIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text = ""
        txtTrxIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text = ""
        txtTrxLineIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text = ""
        txtTrxLineIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text = ""
        txtTrxIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text = ""
        txtTrxLineIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text = ""
        cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text = ""




    End Sub 'btnAccrueInterestTabAccrueInterestTbcTransactionsTabTransactionsTbcMain_Click


    'implementation of click on exit button
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub 'btnExit_Click


    '********** Business Logic Event Procedures
    '             - Initiated as a result of business logic
    '               method(s) running

    'this handles event raised by create customer function in bank class
    Private Sub _customerAdded(
            ByVal sender As System.Object,
            ByVal e As System.EventArgs) _
        Handles _
            mBank.Bank_CustomerAdded

        'Declare variables
        Dim theCustomer_EventArgs_CustomerAdded As _
            Customer_EventArgs_CustomerAdded
        Dim theCustomer As Customer

        'Get/validate data
        theCustomer_EventArgs_CustomerAdded =
            CType(
                e,
                Customer_EventArgs_CustomerAdded
                )
        theCustomer =
            theCustomer_EventArgs_CustomerAdded.customer

        'inserting data to regular list boxes as per the requirement
        lstCustomerIDTabSummaryTbcMain.Items.Add(theCustomer.custId)
        cboCustomerIDTabCustomerTbcMain.Items.Add(theCustomer.custId)
        cboCustomerIDGrpCreateModifyTabAccountTbcMain.Items.Add(theCustomer.custId)
        cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Items.Add(theCustomer.custId)
        cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Items.Add(theCustomer.custId)
        lblCountCustomerTabCustomerTbcMain.Text = CType(_theBank.numCust, String)

        ' lstCustomerIDTabAccountTbcMain.Items.Add(theCustomer.custId)
        lblCountOwnersTabAccountTbcMain.Text = CType(_theBank.numCust, String)


        'Display output
        txtTrxLog.Text &= vbCrLf & "- Customer ADDED: " & theCustomer.ToString


    End Sub '_customerAdded(sender,e)

    'this handles event raised by create account function in bank class
    Private Sub _accountCreated(
            ByVal sender As System.Object,
            ByVal e As System.EventArgs) _
        Handles mBank.Bank_AccountCreated

        'Declare variables
        Dim theAccount_EventArgs_AccountCreated As Account_EventArgs_AccountCreated
        Dim theAccount As Account

        'Get/validate data
        theAccount_EventArgs_AccountCreated =
            CType(e, Account_EventArgs_AccountCreated)
        theAccount = theAccount_EventArgs_AccountCreated.account

        'inserting values to different text boxes and list 
        cboAccountIDTabAccountTbcMain.Items.Add(theAccount.accId)
        lstAccountIDTabSummaryTbcMain.Items.Add(theAccount.accId)

        cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Items.Add(theAccount.accId)
        'lstTrxLineIDTabAccountTbcMain.Items.Add(theAccount.trxLineId)



        lblCountTrxLinesTabAccountTbcMain.Text = CType(_theBank.numAccnt, String)


        lblCountAccountTabSummaryTbcMain.Text = CType(_theBank.numAccnt, String)


        'Display output
        txtTrxLog.Text &= vbCrLf & "- Account created: " & theAccount.ToString



    End Sub '_acccreated(sender,e)

    'this handles event raised by modify account function in bank class
    Private Sub _accountModified(
            ByVal sender As System.Object,
            ByVal e As System.EventArgs) _
        Handles mBank.Bank_AccountModified

        'Declare variables
        Dim theAccount_EventArgs_AccountModified As Account_EventArgs_AccountModified
        Dim theAccount As Account

        'Get/validate data
        theAccount_EventArgs_AccountModified =
            CType(e, Account_EventArgs_AccountModified)
        theAccount = theAccount_EventArgs_AccountModified.account


        'Display output
        txtTrxLog.Text &= vbCrLf & "- Account modofied: " & theAccount.ToString



    End Sub '_accmodified(sender,e)

    'this handles event raised by make deposit function in bank class
    Private Sub _depositMade(
            ByVal sender As System.Object,
            ByVal e As System.EventArgs) _
        Handles mBank.Bank_DepositMade

        'Declare variables
        Dim theTransaction_EventArgs_TransactionProcessed As Transaction_EventArgs_TransactionProcessed
        Dim theTransaction As Transaction

        'Get/validate data
        theTransaction_EventArgs_TransactionProcessed =
            CType(e, Transaction_EventArgs_TransactionProcessed)
        theTransaction = theTransaction_EventArgs_TransactionProcessed.transaction

        'sets values to specific objects as required
        lstTrxIDTabSummaryTbcMain.Items.Add(theTransaction.txnId)
        lblCountTrxTabSummaryTbcMain.Text = CType(_theBank.numTxn, String)

        lstTrxLineIDTabSummaryTbcMain.Items.Add(theTransaction.txnLine)
        lblCountTrxLineTabSummaryTbcMain.Text = CType(_theBank.numTxnLines, String)

        txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = vbCrLf & "- Deposit Made: " & theTransaction.ToString

        ' Display output
        txtTrxLog.Text &= vbCrLf & "- Deposit Made: " & theTransaction.ToString

    End Sub '_depositMade(sender,e)

    'this handles event raised by make withdrwal function in bank class
    Private Sub _withdrawlMade(
            ByVal sender As System.Object,
            ByVal e As System.EventArgs) _
        Handles mBank.Bank_WithdrawlMade

        'Declare variables
        Dim theTransaction_EventArgs_TransactionProcessed As Transaction_EventArgs_TransactionProcessed
        Dim theTransaction As Transaction

        'Get/validate data
        theTransaction_EventArgs_TransactionProcessed =
            CType(e, Transaction_EventArgs_TransactionProcessed)
        theTransaction = theTransaction_EventArgs_TransactionProcessed.transaction

        'sets values of different objects in form ...
        lstTrxIDTabSummaryTbcMain.Items.Add(theTransaction.txnId)
        lblCountTrxTabSummaryTbcMain.Text = CType(_theBank.numTxn, String)

        lstTrxLineIDTabSummaryTbcMain.Items.Add(theTransaction.txnLine)
        lblCountTrxLineTabSummaryTbcMain.Text = CType(_theBank.numTxnLines, String)

        txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = vbCrLf & "- Withdrawl Made: " & theTransaction.ToString

        ' Display output
        txtTrxLog.Text &= vbCrLf & "- Withdrawl Made: " & theTransaction.ToString

    End Sub '_withdrawlMade(sender,e)

    'this handles event raised by use debit card function in bank class
    Private Sub _debitCardUsed(
            ByVal sender As System.Object,
            ByVal e As System.EventArgs) _
        Handles mBank.Bank_DebitCardUsed

        'Declare variables
        Dim theTransaction_EventArgs_TransactionProcessed As Transaction_EventArgs_TransactionProcessed
        Dim theTransaction As Transaction

        'Get/validate data
        theTransaction_EventArgs_TransactionProcessed =
            CType(e, Transaction_EventArgs_TransactionProcessed)
        theTransaction = theTransaction_EventArgs_TransactionProcessed.transaction


        'update values on form as required
        lstTrxIDTabSummaryTbcMain.Items.Add(theTransaction.txnId)
        lblCountTrxTabSummaryTbcMain.Text = CType(_theBank.numTxn, String)

        lstTrxLineIDTabSummaryTbcMain.Items.Add(theTransaction.txnLine)
        lblCountTrxLineTabSummaryTbcMain.Text = CType(_theBank.numTxnLines, String)

        txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = vbCrLf & "- Debit Card Purchase Made: " & theTransaction.ToString

        ' Display output
        txtTrxLog.Text &= vbCrLf & "- Debit Card Purchase Made: " & theTransaction.ToString

    End Sub '_debitCardUsed(sender,e)

    'this handles event raised by charge purchase function in bank class
    Private Sub _chargePurchased(
            ByVal sender As System.Object,
            ByVal e As System.EventArgs) _
        Handles mBank.Bank_ChargePurchased

        'Declare variables
        Dim theTransaction_EventArgs_TransactionProcessed As Transaction_EventArgs_TransactionProcessed
        Dim theTransaction As Transaction

        'Get/validate data
        theTransaction_EventArgs_TransactionProcessed =
            CType(e, Transaction_EventArgs_TransactionProcessed)
        theTransaction = theTransaction_EventArgs_TransactionProcessed.transaction

        'inserts data to different objects according to event raised
        lstTrxIDTabSummaryTbcMain.Items.Add(theTransaction.txnId)
        lblCountTrxTabSummaryTbcMain.Text = CType(_theBank.numTxn, String)

        lstTrxLineIDTabSummaryTbcMain.Items.Add(theTransaction.txnLine)
        lblCountTrxLineTabSummaryTbcMain.Text = CType(_theBank.numTxnLines, String)

        txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = vbCrLf & "- Charge Purchase Made: " & theTransaction.ToString

        ' Display output
        txtTrxLog.Text &= vbCrLf & "- Charge Purchase Made: " & theTransaction.ToString

    End Sub '_chargePurchased(sender,e)

    'this handles event raised by make payment function in bank class
    Private Sub _paymentMade(
            ByVal sender As System.Object,
            ByVal e As System.EventArgs) _
        Handles mBank.Bank_PaymentMade

        'Declare variables
        Dim theTransaction_EventArgs_TransactionProcessed As Transaction_EventArgs_TransactionProcessed
        Dim theTransaction As Transaction

        'Get/validate data
        theTransaction_EventArgs_TransactionProcessed =
            CType(e, Transaction_EventArgs_TransactionProcessed)
        theTransaction = theTransaction_EventArgs_TransactionProcessed.transaction

        'inserts data to different objects according to need
        lstTrxIDTabSummaryTbcMain.Items.Add(theTransaction.txnId)
        lblCountTrxTabSummaryTbcMain.Text = CType(_theBank.numTxn, String)

        lstTrxLineIDTabSummaryTbcMain.Items.Add(theTransaction.toTxnLineId)
        lblCountTrxLineTabSummaryTbcMain.Text = CType(_theBank.numTxnLines, String)

        txtToStringTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = vbCrLf & "- Payment Made: " & theTransaction.ToString

        ' Display output
        txtTrxLog.Text &= vbCrLf & "- Payment Made: " & theTransaction.ToString

    End Sub '_paymentMade(sender,e)

    'this handles event raised by make transfer function in bank class
    Private Sub _transferMade(
            ByVal sender As System.Object,
            ByVal e As System.EventArgs) _
        Handles mBank.Bank_TransferMade

        'Declare variables
        Dim theTransaction_EventArgs_TransactionProcessed As Transaction_EventArgs_TransactionProcessed
        Dim theTransaction As Transaction

        'Get/validate data
        theTransaction_EventArgs_TransactionProcessed =
            CType(e, Transaction_EventArgs_TransactionProcessed)
        theTransaction = theTransaction_EventArgs_TransactionProcessed.transaction


        'inserts data to different list boxes and text boxes according to the event raised
        lstTrxIDTabSummaryTbcMain.Items.Add(theTransaction.txnId)
        lblCountTrxTabSummaryTbcMain.Text = CType(_theBank.numTxn, String)

        lstTrxLineIDTabSummaryTbcMain.Items.Add(theTransaction.toTxnLineId)
        lblCountTrxLineTabSummaryTbcMain.Text = CType(_theBank.numTxnLines, String)

        txtToStringTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = vbCrLf & "- Transfer Made: " & theTransaction.ToString

        ' Display output
        txtTrxLog.Text &= vbCrLf & "- transfer Made: " & theTransaction.ToString

    End Sub '_transferMade(sender,e)

    'this handles event raised by accure interest function in bank class
    Private Sub _interestAccured(
            ByVal sender As System.Object,
            ByVal e As System.EventArgs) _
        Handles mBank.Bank_InterestAccured

        'Declare variables
        Dim theTransaction_EventArgs_TransactionProcessed As Transaction_EventArgs_TransactionProcessed
        Dim theTransaction As Transaction

        'Get/validate data
        theTransaction_EventArgs_TransactionProcessed =
            CType(e, Transaction_EventArgs_TransactionProcessed)
        theTransaction = theTransaction_EventArgs_TransactionProcessed.transaction

        'sets different list boxes according to the transaction type
        If theTransaction.type = TransactionType.SpecificAccount Then
            lstTrxIDTabSummaryTbcMain.Items.Add(theTransaction.txnId)
            lstTrxLineIDTabSummaryTbcMain.Items.Add(theTransaction.txnLine)
            txtToStringTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text = vbCrLf & "- Interest accured for Specific account: " & theTransaction.ToString
        Else
            lstTrxIDTabSummaryTbcMain.Items.Add(theTransaction.txnIdPrefix)
            lstTrxLineIDTabSummaryTbcMain.Items.Add(theTransaction.txnLineIdPrefix)

            txtToStringTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text = vbCrLf & "- Interest accured for All account: " & theTransaction.ToString

        End If


        lblCountTrxTabSummaryTbcMain.Text = CType(_theBank.numTxn, String)
        lblCountTrxLineTabSummaryTbcMain.Text = CType(_theBank.numTxnLines, String)


        'Display output
        txtTrxLog.Text &= vbCrLf & "- Interest accured: " & theTransaction.ToString



    End Sub '_interestAccured(sender,e)

    Private Sub _changedMetrics(
            ByVal sender As System.Object,
            ByVal e As System.EventArgs) _
        Handles mBank.Bank_ChangedMetrics

        'calculates the metrics displayed on the mainscree summary tab


        Dim totalbalance As Decimal
        Dim averagebalance As Decimal
        Dim totalAge As Decimal
        Dim averageAge As Decimal
        Dim maxAge As Integer
        maxAge = 0
        Dim noOfCheckingAccount As Integer
        noOfCheckingAccount = 0


        For Each acc As Account In _theBank.iterateAccount
            If acc.type.ToString = "Checking" Then
                totalbalance = totalbalance + acc.amount
                noOfCheckingAccount = noOfCheckingAccount + 1
            End If
        Next acc

        For Each cus As Customer In _theBank.iterateCustomer
            totalAge = totalAge + CType(cus.age, Decimal)
            If maxAge < cus.age Then
                maxAge = cus.age
            End If
        Next cus

        Try
            averagebalance = totalbalance / noOfCheckingAccount
            averageAge = totalAge / _theBank.numCust

        Catch ex As Exception
        End Try


        txtMetricsGrpMetricsTabSummaryTbcMain.Text = vbCrLf & "Average checking balance is: " & averagebalance & vbCrLf & "Average age : " & averageAge & vbCrLf & "Maximum age: " & maxAge


    End Sub '_changedMetrics(sender,e)

    'this handles event raised by selection of element in list box
    Private Sub _lstCustomerIDTabSummaryTbcMain_SelectedIndexChanged(
            sender As Object,
            e As EventArgs) _
        Handles _
            lstCustomerIDTabSummaryTbcMain.SelectedIndexChanged

        'prints toString of customer id selected in (summary tab) to ToString information box

        Dim customer = mBank.findCustomer(lstCustomerIDTabSummaryTbcMain.SelectedItem.ToString)

        txtToStringInfoTabSummaryTbcMain.Text = customer.ToString

    End Sub '_lstCustomerIDTabSummaryTbcMain_SelectedIndexChanged



    Private Sub _cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain_SelectedIndexChanged(
            sender As Object,
            e As EventArgs) _
        Handles _
            cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.SelectedIndexChanged

        'prints toString of customer id selected in (summary tab) to ToString information box
        cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Items.Clear()

        Dim customer = mBank.findCustomer(cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.SelectedItem.ToString)

        txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = customer.ToString



        For Each acc As Account In mBank.iterateAccount
            For pLocationFound = 0 To acc.owner.Length - 1
                If cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.SelectedItem.ToString = acc.owner(pLocationFound).custId Then

                    cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Items.Add(acc.accId)
                    'lstCustomerIDTabAccountTbcMain.Items.Add(acc.owner(pLocationFound).custId)
                End If
            Next pLocationFound
        Next acc





    End Sub '_cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain_SelectedIndexChanged


    'it sets the accout as perthe customer selected
    Private Sub _cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain_SelectedIndexChanged(
            sender As Object,
            e As EventArgs) _
        Handles _
            cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.SelectedIndexChanged

        cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Items.Clear()
        cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Items.Clear()

        'prints toString of customer id selected in (summary tab) to ToString information box

        Dim customer = mBank.findCustomer(cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.SelectedItem.ToString)

        txtToStringTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = customer.ToString


        For Each acc As Account In mBank.iterateAccount
            For pLocationFound = 0 To acc.owner.Length - 1
                If cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.SelectedItem.ToString = acc.owner(pLocationFound).custId Then

                    cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Items.Add(acc.accId)
                    cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Items.Add(acc.accId)

                End If
            Next pLocationFound
        Next acc


    End Sub '_cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain_SelectedIndexChanged



    Private Sub _cboCustomerIDTabCustomerTbcMain_SelectedIndexChanged(
            sender As Object,
            e As EventArgs) _
        Handles _
            cboCustomerIDTabCustomerTbcMain.SelectedIndexChanged

        'prints toString of customer id selected in (summary tab) to ToString information box

        Dim customer = mBank.findCustomer(cboCustomerIDTabCustomerTbcMain.SelectedItem.ToString)

        txtToStringInfoTabCustomerTbcMain.Text = customer.ToString

    End Sub '_lstCustomerIDTabSummaryTbcMain_SelectedIndexChanged

    'this handles event raised by selection of element in list box
    Private Sub _lstAccountIDTabSummaryTbcMain_SelectedIndexChanged(
            sender As Object,
            e As EventArgs) _
        Handles _
            lstAccountIDTabSummaryTbcMain.SelectedIndexChanged

        Dim account = mBank.findAccount(lstAccountIDTabSummaryTbcMain.SelectedItem.ToString)

        'prints toString of account id selected in (summary tab) to ToString information box
        txtToStringInfoTabSummaryTbcMain.Text = account.ToString

    End Sub '_lstAccountIDTabSummaryTbcMain_SelectedIndexChanged

    'this handles event raised by selection of element in list box
    Private Sub _chkClosedGrpClosedTabAccountTbcMain_Checked(
            sender As Object,
            e As EventArgs) _
        Handles _
            chkClosedGrpClosedTabAccountTbcMain.CheckedChanged


        If chkClosedGrpClosedTabAccountTbcMain.Checked = True Then
            grpCreateModifyTabAccountTbcMain.Enabled = False
        Else
            grpCreateModifyTabAccountTbcMain.Enabled = True
        End If

    End Sub '_chkClosedGrpClosedTabAccountTbcMain_Checked

    Private Sub _cboAccountIDTabAccountTbcMain_SelectedIndexChanged(
            sender As Object,
            e As EventArgs) _
        Handles _
            cboAccountIDTabAccountTbcMain.SelectedIndexChanged

        lstCustomerIDTabAccountTbcMain.Items.Clear()
        lstTrxLineIDTabAccountTbcMain.Items.Clear()

        Dim account = mBank.findAccount(cboAccountIDTabAccountTbcMain.SelectedItem.ToString)

        'prints toString of account id selected in (summary tab) to ToString information box
        txtToStringInfoTabAccountTbcMain.Text = account.ToString

        For Each acc As Account In mBank.iterateAccount
            If cboAccountIDTabAccountTbcMain.SelectedItem.ToString = acc.accId Then

                For pLocationFound = 0 To acc.owner.Length - 1
                    lstCustomerIDTabAccountTbcMain.Items.Add(acc.owner(pLocationFound).custId)
                Next pLocationFound

            End If

        Next acc

        For Each txn As Transaction In mBank.iterateTransaction
            If cboAccountIDTabAccountTbcMain.SelectedItem.ToString = txn.accountId Then
                Try
                    lstTrxLineIDTabAccountTbcMain.Items.Add(txn.txnLine)
                Catch ex As Exception
                    lstTrxLineIDTabAccountTbcMain.Items.Add(txn.fromTxnLineIdt)
                End Try
            End If

        Next txn

        lblCountOwnersTabAccountTbcMain.Text = CType(lstCustomerIDTabAccountTbcMain.Items.Count, String)
        lblCountTrxLinesTabAccountTbcMain.Text = CType(lstTrxLineIDTabAccountTbcMain.Items.Count, String)


        If account.type = AccountType.Checking Then
            radCheckingGrpTypeGrpCreateModifyTabAccountTbcMain.Select()
        End If

        If account.type = AccountType.Loan Then
            radLoanGrpTypeGrpCreateModifyTabAccountTbcMain.Select()
        End If

        If account.type = AccountType.CreditCard Then
            radCreditCardGrpTypeGrpCreateModifyTabAccountTbcMain.Select()
        End If

        txtNameGrpCreateModifyTabAccountTbcMain.Text = account.accName
        dtpDateOpenedGrpCreateModifyTabAccountTbcMain.Text = account.dateOpened.ToString
        txtAmountGrpCreateModifyTabAccountTbcMain.Text = account.amount.ToString
        txtTrxIDGrpCreateModifyTabAccountTbcMain.Text = account.trxId
        txtTrxLineIDGrpCreateModifyTabAccountTbcMain.Text = account.trxLineId
        nudAPRGrpCreateModifyTabAccountTbcMain.Text = account.interestRate.ToString
        '  nudAPRGrpCreateModifyTabAccountTbcMain.Text = CType(account.interestRate, String)
        dtpNextInterestAccrualDateGrpCreateModifyTabAccountTbcMain.Text = account.accuralDate.ToString

        dtpDateOpenedGrpCreateModifyTabAccountTbcMain.Enabled = False
        txtAmountGrpCreateModifyTabAccountTbcMain.Enabled = False
        txtTrxIDGrpCreateModifyTabAccountTbcMain.Enabled = False
        txtTrxLineIDGrpCreateModifyTabAccountTbcMain.Enabled = False
        grpTypeGrpCreateModifyTabAccountTbcMain.Enabled = False
        grpCreateModifyTabAccountTbcMain.Enabled = True

    End Sub '_cboAccountIDTabAccountTbcMain_SelectedIndexChanged

    Private Sub _cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain_SelectedIndexChanged(
            sender As Object,
            e As EventArgs) _
        Handles _
            cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.SelectedIndexChanged

        Dim account = mBank.findAccount(cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.SelectedItem.ToString)

        'prints toString of account id selected in (summary tab) to ToString information box
        txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = account.ToString

    End Sub '_cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain_SelectedIndexChanged

    Private Sub _cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain_SelectedIndexChanged(
            sender As Object,
            e As EventArgs) _
        Handles _
            cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.SelectedIndexChanged

        Dim account = mBank.findAccount(cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.SelectedItem.ToString)

        'prints toString of account id selected in (summary tab) to ToString information box
        txtToStringTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = account.ToString



        cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Items.Clear()

        'prints toString of customer id selected in (summary tab) to ToString information box


        For Each acc As Account In mBank.iterateAccount
            For pLocationFound = 0 To acc.owner.Length - 1
                If cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.SelectedItem.ToString = acc.owner(pLocationFound).custId Then


                    cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Items.Add(acc.accId)

                End If
            Next pLocationFound
        Next acc


        cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Items.Remove(cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.SelectedItem.ToString)



    End Sub '_cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain_SelectedIndexChanged

    Private Sub _cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain_SelectedIndexChanged(
            sender As Object,
            e As EventArgs) _
        Handles _
            cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.SelectedIndexChanged

        Dim account = mBank.findAccount(cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.SelectedItem.ToString)

        'prints toString of account id selected in (summary tab) to ToString information box
        txtToStringTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = account.ToString

    End Sub '_cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain_SelectedIndexChanged

    Private Sub _cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain_SelectedIndexChanged(
            sender As Object,
            e As EventArgs) _
        Handles _
            cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.SelectedIndexChanged

        Dim account = mBank.findAccount(cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.SelectedItem.ToString)

        'prints toString of account id selected in (summary tab) to ToString information box
        txtToStringTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text = account.ToString

    End Sub '_cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain_SelectedIndexChanged

    'this handles event raised by selection of element in list box
    Private Sub _lstTrxIDTabSummaryTbcMain_SelectedIndexChanged(
            sender As Object,
            e As EventArgs) _
        Handles _
            lstTrxIDTabSummaryTbcMain.SelectedIndexChanged

        Try
            Dim transaction = mBank.findTransaction(lstTrxIDTabSummaryTbcMain.SelectedItem.ToString)
            txtToStringInfoTabSummaryTbcMain.Text = transaction.ToString
        Catch ex As Exception

        End Try

    End Sub '_lstTrxIDTabSummaryTbcMain_SelectedIndexChanged

    'this handles event raised by selection of element in list box
    Private Sub _lstTrxLineIDTabSummaryTbcMain_SelectedIndexChanged(
            sender As Object,
            e As EventArgs) _
        Handles _
            lstTrxLineIDTabSummaryTbcMain.SelectedIndexChanged

        Try
            Dim transaction = mBank.findTransactionLine(lstTrxLineIDTabSummaryTbcMain.SelectedItem.ToString)
            txtToStringInfoTabSummaryTbcMain.Text = transaction.ToString
        Catch ex As Exception
        End Try



        'prints toString of trxLine id selected in (summary tab) to ToString information box

    End Sub '_lstTrxLineIDTabSummaryTbcMain_SelectedIndexChanged


    'this handles event raised by selection of element in list box
    Private Sub _lstTrxIDTabCustomerTbcMain_SelectedIndexChanged(
            sender As Object,
            e As EventArgs) _
        Handles _
            lstTrxIDTabCustomerTbcMain.SelectedIndexChanged

        'prints toString of customer created  in Customer tab to ToString information box
        txtToStringInfoTabCustomerTbcMain.Text = lstTrxIDTabCustomerTbcMain.SelectedItem.ToString

    End Sub '_lstTrxIDTabCustomerTbcMain_SelectedIndexChanged


    'this handles event raised by selection of element in list box
    Private Sub _lstTrxLineIDTabAccountTbcMain_SelectedIndexChanged(
            sender As Object,
            e As EventArgs) _
        Handles _
            lstTrxLineIDTabAccountTbcMain.SelectedIndexChanged


        Try
            Dim transaction = mBank.findTransactionLine(lstTrxLineIDTabAccountTbcMain.SelectedItem.ToString)
            txtToStringInfoTabAccountTbcMain.Text = transaction.ToString
        Catch ex As Exception
        End Try


    End Sub '_lstTrxLineIDTabAccountTbcMain_SelectedIndexChanged


    'this handles event raised by selection of element in list box
    Private Sub _lstCustomerIDTabAccountTbcMain_SelectedIndexChanged(
            sender As Object,
            e As EventArgs) _
        Handles _
            lstCustomerIDTabAccountTbcMain.SelectedIndexChanged



        Dim customer = mBank.findCustomer(lstCustomerIDTabAccountTbcMain.SelectedItem.ToString)

        'prints toString of account id selected in (summary tab) to ToString information box
        txtToStringInfoTabAccountTbcMain.Text = customer.ToString



    End Sub '_lstCustomerIDTabAccountTbcMain_SelectedIndexChanged

    'it handles event created in account tab, calculates next accural date 
    Private Sub _dtpDateOpenedGrpCreateModifyTabAccountTbcMain_ValueChanged(
            sender As Object,
            e As EventArgs) _
        Handles _
            dtpDateOpenedGrpCreateModifyTabAccountTbcMain.ValueChanged

        Dim theAccountOpenedDate As Date
        Dim theNextAccuralDate As Date
        theAccountOpenedDate = CDate(dtpDateOpenedGrpCreateModifyTabAccountTbcMain.Text)

        If theAccountOpenedDate.AddDays(1).Day.Equals(1) Then
            theNextAccuralDate = theAccountOpenedDate.AddDays(1).AddMonths(1).AddDays(-1).Date
        Else
            theNextAccuralDate = theAccountOpenedDate.AddMonths(1).Date

        End If

        dtpNextInterestAccrualDateGrpCreateModifyTabAccountTbcMain.Text = theNextAccuralDate.ToString



    End Sub '_dtpDateOpenedGrpCreateModifyTabAccountTbcMain_ValueChanged

    'this handles disabling of boxes according to radio buttonselected
    Private Sub _radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain_SelectedIndexChanged(
            sender As Object,
            e As EventArgs) _
        Handles _
            radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.CheckedChanged, radSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.CheckedChanged

        If radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Checked Then
            grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Enabled = True
            grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Enabled = False
        Else
            grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Enabled = False
            grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Enabled = True
        End If

    End Sub '_radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain

    'add Account owner implementation
    Private Sub btnAddAccountOwnerGrpCreateModifyTabAccountTbcMain_Click(sender As Object, e As EventArgs) Handles btnAddAccountOwnerGrpCreateModifyTabAccountTbcMain.Click

        lstNewOwnerIDGrpCreateModifyTabAccountTbcMain.Items.Add(cboCustomerIDGrpCreateModifyTabAccountTbcMain.SelectedItem.ToString)

    End Sub


    Private Sub btnDisplayBankTabFilesTbcMain_Click(sender As Object, e As EventArgs) Handles btnDisplayBankTabFilesTbcMain.Click
        txtTrxLog.Text &=
                 vbCrLf _
                    & "- Banks details : " & _theBank.ToString
        'it displays the tostring of bank method

    End Sub




    '********** User-Interface Event Procedures
    '             - Initiated automatically by system

    Private Sub _FrmMain_Load(
            sender As Object,
            e As EventArgs) _
        Handles _
            MyBase.Load

        _initializeBusinessLogic()
        _initializeUserInterface()

    End Sub '_FrmMain_Load(sender,e)

    'it automatically scrolls down whenever new text is added in the log 
    Private Sub _txtTrxLog_TextChanged(
            sender As Object,
            e As EventArgs) _
        Handles _
            txtTrxLog.TextChanged

        txtTrxLog.SelectionStart = txtTrxLog.TextLength
        txtTrxLog.ScrollToCaret()

    End Sub '_txtTrx_TextChanged(sender,e) 



#End Region 'Event Procedures

#Region "Events"
    '******************************************************************
    'Events
    '******************************************************************

    'No Events are currently defined.
    'These are all public.

#End Region 'Events

End Class 'FrmMain