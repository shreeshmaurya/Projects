﻿'Copyright (c) 2009-2016 Dan Turk

#Region "Class / File Comment Header block"
'Program:            Banking
'File:               ClsAccount.vb
'Author:             shreesh maurya
'Description:        implements business logic of account class
'Date:                updated: 9 dec 2016
'                    14 nov 2016
'Tier:               Business logic
'Exceptions:         None
'Exception-Handling: None
'Events:             None
'Event-Handling:     None
#End Region 'Class / File Comment Header block

#Region "Option / Imports"
Option Explicit On      'Must declare variables before using them
Option Strict On        'Must perform explicit data type conversions
#End Region 'Option / Imports

Public Class Account

#Region "Attributes"
    '******************************************************************
    'Attributes + Module-level Constants+Variables
    '******************************************************************



    '********** Module-level variables

    Private mAccId As String
    Private mAccName As String
    Private mNumOwners As String
    Private mOwner() As Customer
    Private mDateOpened As Date
    Private mInterestRate As Decimal
    Private mAccuralDate As Date
    Private mType As AccountType
    Private mIsClosed As Boolean
    Private mClosedDate As Date
    Private mNumTxn As Integer
    Private mTransaction As Transaction
    Private mTrxId As String
    Private mTrxLineId As String
    Private mAmount As Decimal


#End Region 'Attributes

#Region "Constructors"
    '******************************************************************
    'Constructors
    '******************************************************************



    '********** Special constructor(s)
    '             - typically constructors have parameters 
    '               that are used to initialize attributes

    'initializing variables of Account class
    Public Sub New(
          ByVal pAccId As String,
          ByVal pAccName As String,
          ByVal pNumOwners As String,
          ByVal pOwner() As Customer,
        ByVal pDateOpened As Date,
        ByVal pInterestRate As Decimal,
        ByVal pAccuralDate As Date,
        ByVal pType As AccountType,
        ByVal pIsClosed As Boolean,
        ByVal pClosedDate As Date,
        ByVal pTrxId As String,
          ByVal pTrxLineId As String,
           ByVal pAmount As Decimal
          )



        _accId = pAccId
        _accName = pAccName
        _numOwners = pNumOwners
        _owner = pOwner
        _dateOpened = pDateOpened
        _interestRate = pInterestRate
        _accuralDate = pAccuralDate
        _type = pType
        _isClosed = pIsClosed
        _closedDate = pClosedDate
        _trxId = pTrxId
        _trxLineId = pTrxLineId
        _amount = pAmount




    End Sub 'New

    '********** Copy constructor(s)
    '             - one parameter, an object of the same class

#End Region 'Constructors

#Region "Get/Set Methods"
    '******************************************************************
    'Get/Set Methods
    '******************************************************************


    '********** Public Get/Set Methods
    '             - call private get/set methods to implement

    Public Property accId As String
        Get
            Return _accId
        End Get
        Set(pValue As String)
            _accId = pValue
        End Set
    End Property

    Public Property accName As String
        Get
            Return _accName
        End Get
        Set(pValue As String)
            _accName = pValue
        End Set
    End Property

    Public Property trxId As String
        Get
            Return _trxId
        End Get
        Set(pValue As String)
            _trxId = pValue
        End Set
    End Property

    Public Property trxLineId As String
        Get
            Return _trxLineId
        End Get
        Set(pValue As String)
            _trxLineId = pValue
        End Set
    End Property

    Public Property numOwners As String
        Get
            Return _numOwners
        End Get
        Set(pValue As String)
            _numOwners = pValue
        End Set
    End Property

    Public Property owner() As Customer()
        Get
            Return _owner
        End Get
        Set(pValue As Customer())
            _owner = pValue
        End Set
    End Property

    Public Property dateOpened As Date
        Get
            Return _dateOpened
        End Get
        Set(pValue As Date)
            _dateOpened = pValue
        End Set
    End Property

    Public Property interestRate As Decimal
        Get
            Return _interestRate
        End Get
        Set(pValue As Decimal)
            _interestRate = pValue
        End Set
    End Property

    Public Property amount As Decimal
        Get
            Return _amount
        End Get
        Set(pValue As Decimal)
            _amount = pValue
        End Set
    End Property

    Public Property accuralDate As Date
        Get
            Return _accuralDate
        End Get
        Set(pValue As Date)
            _accuralDate = pValue
        End Set
    End Property

    Public Property type As AccountType
        Get
            Return _type
        End Get
        Set(pValue As AccountType)
            _type = pValue
        End Set
    End Property

    Public Property isClosed As Boolean
        Get
            Return _isClosed
        End Get
        Set(pValue As Boolean)
            _isClosed = pValue
        End Set
    End Property

    Public Property closedDate As Date
        Get
            Return _closedDate
        End Get
        Set(pValue As Date)
            _closedDate = pValue
        End Set
    End Property

    Public Property numTxn As Integer
        Get
            Return _numTxn
        End Get
        Set(pValue As Integer)
            _numTxn = pValue
        End Set
    End Property

    Public Property transaction As Transaction
        Get
            Return _transaction
        End Get
        Set(pValue As Transaction)
            _transaction = pValue
        End Set
    End Property



    '********** Private Get/Set Methods
    '             - access attributes, begin name with underscore (_)

    Private Property _accId As String
        Get
            Return mAccId
        End Get
        Set(pValue As String)
            mAccId = pValue
        End Set
    End Property

    Private Property _accName As String
        Get
            Return mAccName
        End Get
        Set(pValue As String)
            mAccName = pValue
        End Set
    End Property

    Private Property _trxId As String
        Get
            Return mTrxId
        End Get
        Set(pValue As String)
            mTrxId = pValue
        End Set
    End Property

    Private Property _trxLineId As String
        Get
            Return mTrxLineId
        End Get
        Set(pValue As String)
            mTrxLineId = pValue
        End Set
    End Property

    Private Property _numOwners As String
        Get
            Return mNumOwners
        End Get
        Set(pValue As String)
            mNumOwners = pValue
        End Set
    End Property

    Private Property _owner As Customer()
        Get
            Return mOwner
        End Get
        Set(pValue As Customer())

            _setOwnerArray(pValue)
        End Set
    End Property

    Private Property _dateOpened As Date
        Get
            Return mDateOpened
        End Get
        Set(pValue As Date)
            mDateOpened = pValue
        End Set
    End Property

    Private Property _interestRate As Decimal
        Get
            Return mInterestRate
        End Get
        Set(pValue As Decimal)
            mInterestRate = pValue
        End Set
    End Property

    Private Property _amount As Decimal
        Get
            Return mAmount
        End Get
        Set(pValue As Decimal)
            mAmount = pValue
        End Set
    End Property

    Private Property _accuralDate As Date
        Get
            Return mAccuralDate
        End Get
        Set(pValue As Date)
            mAccuralDate = pValue
        End Set
    End Property

    Private Property _type As AccountType
        Get
            Return mType
        End Get
        Set(pValue As AccountType)
            mType = pValue
        End Set
    End Property

    Private Property _isClosed As Boolean
        Get
            Return mIsClosed
        End Get
        Set(pValue As Boolean)
            mIsClosed = pValue
        End Set
    End Property

    Private Property _closedDate As Date
        Get
            Return mClosedDate
        End Get
        Set(pValue As Date)
            mClosedDate = pValue
        End Set
    End Property

    Private Property _numTxn As Integer
        Get
            Return mNumTxn
        End Get
        Set(pValue As Integer)
            mNumTxn = pValue
        End Set
    End Property

    Private Property _transaction As Transaction
        Get
            Return mTransaction
        End Get
        Set(pValue As Transaction)
            mTransaction = pValue
        End Set
    End Property

    Private Function _setOwnerArray(ByVal pValue() As Customer) As Customer

        ReDim mOwner(pValue.Length - 1)

        Dim pLocationFound As Integer
        For pLocationFound = 0 To mOwner.Length - 1
            mOwner(pLocationFound) = pValue(pLocationFound)

        Next pLocationFound

    End Function

    Private Function _getOwnerArrayString(ByVal pValue As Customer()) As String

        Dim str As String

        Dim pLocationFound As Integer
        For pLocationFound = 0 To pValue.Length - 1
            str = str + pValue(pLocationFound).ToString
        Next pLocationFound

        Return str

    End Function





#End Region 'Get/Set Methods

#Region "Behavioral Methods"
    '******************************************************************
    'Behavioral Methods
    '******************************************************************


    '********** Public Non-Shared Behavioral Methods

    Public Overrides Function ToString() As String

        Return _toString()

    End Function 'ToString()

    '********** Private Non-Shared Behavioral Methods


    'ToString implementation of of account class
    Private Function _toString() As String

        Dim tmpStr As String

        tmpStr = "( Customer : " _
            & "Account id='" & _accId & "'" _
            & ", Account name='" & _accName & "'" _
            & ", number of owners='" & _numOwners & "'" _
            & ", owners='" & _getOwnerArrayString(_owner) & "'" _
            & ", date opened='" & _dateOpened.ToString & "'" _
            & ", interest rate='" & _interestRate & "'" _
            & ", next interest accural date='" & _accuralDate.ToString & "'" _
            & ", account type='" & _type.ToString & "'" _
            & ", status of account='" & _isClosed & "'" _
            & ", account closed date='" & _closedDate.ToString & "'" _
         & ",  transaction id ='" & _trxId & "'" _
            & ",  transaction id line='" & _trxLineId & "'" _
           & " )"


        Return tmpStr

    End Function '_toString()

#End Region 'Behavioral Methods

#Region "Event Procedures"
    '******************************************************************
    'Event Procedures
    '******************************************************************

    'No Event Procedures are currently defined.


#End Region 'Event Procedures

#Region "Events"
    '******************************************************************
    'Events
    '******************************************************************

    'No Events are currently defined.
    'These are all public.

#End Region 'Events

End Class 'ClsAccount
