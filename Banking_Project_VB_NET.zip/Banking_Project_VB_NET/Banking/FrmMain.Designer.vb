﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.mnuMain = New System.Windows.Forms.MenuStrip()
        Me.mniFileMnuMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mniProcessTestDataMniFileMnuMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mniOpenMniFileMnuMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mniSaveMniFileMnuMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mniResetAllMniFileMnuMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mniExitMniFileMnuMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mniHelpMnuMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.mniAboutMniHelpMnuMain = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtTrxLog = New System.Windows.Forms.TextBox()
        Me.tbcMain = New System.Windows.Forms.TabControl()
        Me.tabSummaryTbcMain = New System.Windows.Forms.TabPage()
        Me.grpMetricsTabSummaryTbcMain = New System.Windows.Forms.GroupBox()
        Me.txtMetricsGrpMetricsTabSummaryTbcMain = New System.Windows.Forms.TextBox()
        Me.txtToStringInfoTabSummaryTbcMain = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblCountTrxLineTabSummaryTbcMain = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblCountTrxTabSummaryTbcMain = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.lblCountAccountTabSummaryTbcMain = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lblCountCustomerTabCustomerTbcMain = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lstTrxLineIDTabSummaryTbcMain = New System.Windows.Forms.ListBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lstTrxIDTabSummaryTbcMain = New System.Windows.Forms.ListBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lstAccountIDTabSummaryTbcMain = New System.Windows.Forms.ListBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lstCustomerIDTabSummaryTbcMain = New System.Windows.Forms.ListBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbcCustomerTbcMain = New System.Windows.Forms.TabPage()
        Me.grpCreateTabCustomerTbcMain = New System.Windows.Forms.GroupBox()
        Me.btnCreateCustomerGrpCreateTabCustomerTbcMain = New System.Windows.Forms.Button()
        Me.txtNameGrpCreateTabCustomerTbcMain = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.dtpBirthdateGrpCreateTabCustomerTbcMain = New System.Windows.Forms.DateTimePicker()
        Me.cboCustomerIDTabCustomerTbcMain = New System.Windows.Forms.ComboBox()
        Me.lblCountTrxTabCustomerTbcMain = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.lstTrxIDTabCustomerTbcMain = New System.Windows.Forms.ListBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtToStringInfoTabCustomerTbcMain = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.tabAccountTbcMain = New System.Windows.Forms.TabPage()
        Me.lblCountOwnersTabAccountTbcMain = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.grpClosedTabAccountTbcMain = New System.Windows.Forms.GroupBox()
        Me.dtpClosedDateGrpClosedTabAccountTbcMain = New System.Windows.Forms.DateTimePicker()
        Me.chkClosedGrpClosedTabAccountTbcMain = New System.Windows.Forms.CheckBox()
        Me.Label97 = New System.Windows.Forms.Label()
        Me.lstCustomerIDTabAccountTbcMain = New System.Windows.Forms.ListBox()
        Me.btnModifyAccountTabAccountTbcMain = New System.Windows.Forms.Button()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.grpCreateModifyTabAccountTbcMain = New System.Windows.Forms.GroupBox()
        Me.txtTrxIDGrpCreateModifyTabAccountTbcMain = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtTrxLineIDGrpCreateModifyTabAccountTbcMain = New System.Windows.Forms.TextBox()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.dtpNextInterestAccrualDateGrpCreateModifyTabAccountTbcMain = New System.Windows.Forms.DateTimePicker()
        Me.lstNewOwnerIDGrpCreateModifyTabAccountTbcMain = New System.Windows.Forms.ListBox()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label96 = New System.Windows.Forms.Label()
        Me.nudAPRGrpCreateModifyTabAccountTbcMain = New System.Windows.Forms.NumericUpDown()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.txtAmountGrpCreateModifyTabAccountTbcMain = New System.Windows.Forms.TextBox()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.grpTypeGrpCreateModifyTabAccountTbcMain = New System.Windows.Forms.GroupBox()
        Me.radCreditCardGrpTypeGrpCreateModifyTabAccountTbcMain = New System.Windows.Forms.RadioButton()
        Me.radLoanGrpTypeGrpCreateModifyTabAccountTbcMain = New System.Windows.Forms.RadioButton()
        Me.radCheckingGrpTypeGrpCreateModifyTabAccountTbcMain = New System.Windows.Forms.RadioButton()
        Me.btnAddAccountOwnerGrpCreateModifyTabAccountTbcMain = New System.Windows.Forms.Button()
        Me.cboCustomerIDGrpCreateModifyTabAccountTbcMain = New System.Windows.Forms.ComboBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtNameGrpCreateModifyTabAccountTbcMain = New System.Windows.Forms.TextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.dtpDateOpenedGrpCreateModifyTabAccountTbcMain = New System.Windows.Forms.DateTimePicker()
        Me.cboAccountIDTabAccountTbcMain = New System.Windows.Forms.ComboBox()
        Me.lblCountTrxLinesTabAccountTbcMain = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.lstTrxLineIDTabAccountTbcMain = New System.Windows.Forms.ListBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.txtToStringInfoTabAccountTbcMain = New System.Windows.Forms.TextBox()
        Me.btnCreateAccountTabAccountTbcMain = New System.Windows.Forms.Button()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.tabTransactionsTbcMain = New System.Windows.Forms.TabPage()
        Me.tbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.TabControl()
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.TabPage()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.dtpTrxDateTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.DateTimePicker()
        Me.Label100 = New System.Windows.Forms.Label()
        Me.nudAmountTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.NumericUpDown()
        Me.Label99 = New System.Windows.Forms.Label()
        Me.txtTrxLineIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.TextBox()
        Me.cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.ComboBox()
        Me.Label101 = New System.Windows.Forms.Label()
        Me.Label102 = New System.Windows.Forms.Label()
        Me.cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.ComboBox()
        Me.txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.TextBox()
        Me.Label103 = New System.Windows.Forms.Label()
        Me.btnProcessTrxTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.Button()
        Me.txtTrxIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.TextBox()
        Me.Label104 = New System.Windows.Forms.Label()
        Me.grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.GroupBox()
        Me.radChargePurchaseGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.RadioButton()
        Me.radUseDCGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.RadioButton()
        Me.radMakeWDGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.RadioButton()
        Me.radMakeDepositGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.RadioButton()
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.TabPage()
        Me.txtToTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.TextBox()
        Me.txtFromTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.TextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.dtpTrxDateTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.DateTimePicker()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.GroupBox()
        Me.radTransferFundsGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.RadioButton()
        Me.radMakePaymentGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.RadioButton()
        Me.cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.ComboBox()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.ComboBox()
        Me.nudTrxLineAmountTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.NumericUpDown()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.txtToStringTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.TextBox()
        Me.cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.ComboBox()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.btnProcessTransactionTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.Button()
        Me.txtTrxIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.TextBox()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.TabPage()
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.GroupBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.txtTrxIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.TextBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.txtTrxIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.TextBox()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.txtTrxLineIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.TextBox()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.txtTrxLineIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.TextBox()
        Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.GroupBox()
        Me.txtTrxIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.TextBox()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.txtTrxLineIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.TextBox()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.ComboBox()
        Me.radSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.RadioButton()
        Me.radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.RadioButton()
        Me.txtToStringTabAccrueInterestTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.TextBox()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.btnAccrueInterestTabAccrueInterestTbcTransactionsTabTransactionsTbcMain = New System.Windows.Forms.Button()
        Me.tabReportsTbcMain = New System.Windows.Forms.TabPage()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.tabFilesTbcMain = New System.Windows.Forms.TabPage()
        Me.btnDisplayBankTabFilesTbcMain = New System.Windows.Forms.Button()
        Me.txtFileNameTabFilesTbcMain = New System.Windows.Forms.TextBox()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.btnProcessTestDataTabFilesTbcMain = New System.Windows.Forms.Button()
        Me.btnResetAllTabFilesTbcMain = New System.Windows.Forms.Button()
        Me.btnSaveTabFilesTbcMain = New System.Windows.Forms.Button()
        Me.btnOpenTabFilesTbcMain = New System.Windows.Forms.Button()
        Me.tipMain = New System.Windows.Forms.ToolTip(Me.components)
        Me.dlgFileOpen = New System.Windows.Forms.OpenFileDialog()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.mnuMain.SuspendLayout()
        Me.tbcMain.SuspendLayout()
        Me.tabSummaryTbcMain.SuspendLayout()
        Me.grpMetricsTabSummaryTbcMain.SuspendLayout()
        Me.tbcCustomerTbcMain.SuspendLayout()
        Me.grpCreateTabCustomerTbcMain.SuspendLayout()
        Me.tabAccountTbcMain.SuspendLayout()
        Me.grpClosedTabAccountTbcMain.SuspendLayout()
        Me.grpCreateModifyTabAccountTbcMain.SuspendLayout()
        CType(Me.nudAPRGrpCreateModifyTabAccountTbcMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpTypeGrpCreateModifyTabAccountTbcMain.SuspendLayout()
        Me.tabTransactionsTbcMain.SuspendLayout()
        Me.tbcTransactionsTabTransactionsTbcMain.SuspendLayout()
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.SuspendLayout()
        CType(Me.nudAmountTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.SuspendLayout()
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.SuspendLayout()
        Me.grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.SuspendLayout()
        CType(Me.nudTrxLineAmountTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain.SuspendLayout()
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.SuspendLayout()
        Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.SuspendLayout()
        Me.tabReportsTbcMain.SuspendLayout()
        Me.tabFilesTbcMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(608, 629)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(2)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(50, 21)
        Me.btnExit.TabIndex = 4
        Me.btnExit.Text = "E&xit"
        Me.ToolTip1.SetToolTip(Me.btnExit, "exits")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'mnuMain
        '
        Me.mnuMain.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.mnuMain.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mniFileMnuMain, Me.mniHelpMnuMain})
        Me.mnuMain.Location = New System.Drawing.Point(0, 0)
        Me.mnuMain.Name = "mnuMain"
        Me.mnuMain.Padding = New System.Windows.Forms.Padding(4, 1, 0, 1)
        Me.mnuMain.Size = New System.Drawing.Size(1223, 24)
        Me.mnuMain.TabIndex = 0
        Me.mnuMain.Text = "MenuStrip1"
        '
        'mniFileMnuMain
        '
        Me.mniFileMnuMain.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mniProcessTestDataMniFileMnuMain, Me.mniOpenMniFileMnuMain, Me.mniSaveMniFileMnuMain, Me.mniResetAllMniFileMnuMain, Me.mniExitMniFileMnuMain})
        Me.mniFileMnuMain.Name = "mniFileMnuMain"
        Me.mniFileMnuMain.Size = New System.Drawing.Size(37, 22)
        Me.mniFileMnuMain.Text = "&File"
        '
        'mniProcessTestDataMniFileMnuMain
        '
        Me.mniProcessTestDataMniFileMnuMain.Name = "mniProcessTestDataMniFileMnuMain"
        Me.mniProcessTestDataMniFileMnuMain.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.T), System.Windows.Forms.Keys)
        Me.mniProcessTestDataMniFileMnuMain.Size = New System.Drawing.Size(202, 22)
        Me.mniProcessTestDataMniFileMnuMain.Text = "Process &Test Data"
        '
        'mniOpenMniFileMnuMain
        '
        Me.mniOpenMniFileMnuMain.Name = "mniOpenMniFileMnuMain"
        Me.mniOpenMniFileMnuMain.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.O), System.Windows.Forms.Keys)
        Me.mniOpenMniFileMnuMain.Size = New System.Drawing.Size(202, 22)
        Me.mniOpenMniFileMnuMain.Text = "&Open"
        '
        'mniSaveMniFileMnuMain
        '
        Me.mniSaveMniFileMnuMain.Name = "mniSaveMniFileMnuMain"
        Me.mniSaveMniFileMnuMain.ShortcutKeys = CType((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.S), System.Windows.Forms.Keys)
        Me.mniSaveMniFileMnuMain.Size = New System.Drawing.Size(202, 22)
        Me.mniSaveMniFileMnuMain.Text = "&Save"
        '
        'mniResetAllMniFileMnuMain
        '
        Me.mniResetAllMniFileMnuMain.Name = "mniResetAllMniFileMnuMain"
        Me.mniResetAllMniFileMnuMain.ShortcutKeys = CType(((System.Windows.Forms.Keys.Control Or System.Windows.Forms.Keys.Shift) _
            Or System.Windows.Forms.Keys.R), System.Windows.Forms.Keys)
        Me.mniResetAllMniFileMnuMain.Size = New System.Drawing.Size(202, 22)
        Me.mniResetAllMniFileMnuMain.Text = "&Reset All"
        '
        'mniExitMniFileMnuMain
        '
        Me.mniExitMniFileMnuMain.Name = "mniExitMniFileMnuMain"
        Me.mniExitMniFileMnuMain.ShortcutKeys = CType((System.Windows.Forms.Keys.Alt Or System.Windows.Forms.Keys.F4), System.Windows.Forms.Keys)
        Me.mniExitMniFileMnuMain.Size = New System.Drawing.Size(202, 22)
        Me.mniExitMniFileMnuMain.Text = "E&xit"
        '
        'mniHelpMnuMain
        '
        Me.mniHelpMnuMain.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mniAboutMniHelpMnuMain})
        Me.mniHelpMnuMain.Name = "mniHelpMnuMain"
        Me.mniHelpMnuMain.Size = New System.Drawing.Size(44, 22)
        Me.mniHelpMnuMain.Text = "&Help"
        '
        'mniAboutMniHelpMnuMain
        '
        Me.mniAboutMniHelpMnuMain.Name = "mniAboutMniHelpMnuMain"
        Me.mniAboutMniHelpMnuMain.ShortcutKeys = System.Windows.Forms.Keys.F1
        Me.mniAboutMniHelpMnuMain.Size = New System.Drawing.Size(232, 22)
        Me.mniAboutMniHelpMnuMain.Text = "&About the Banking Project"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 422)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Tr&x Log:"
        '
        'txtTrxLog
        '
        Me.txtTrxLog.Location = New System.Drawing.Point(23, 437)
        Me.txtTrxLog.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTrxLog.Multiline = True
        Me.txtTrxLog.Name = "txtTrxLog"
        Me.txtTrxLog.ReadOnly = True
        Me.txtTrxLog.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtTrxLog.Size = New System.Drawing.Size(1221, 168)
        Me.txtTrxLog.TabIndex = 3
        '
        'tbcMain
        '
        Me.tbcMain.Controls.Add(Me.tabSummaryTbcMain)
        Me.tbcMain.Controls.Add(Me.tbcCustomerTbcMain)
        Me.tbcMain.Controls.Add(Me.tabAccountTbcMain)
        Me.tbcMain.Controls.Add(Me.tabTransactionsTbcMain)
        Me.tbcMain.Controls.Add(Me.tabReportsTbcMain)
        Me.tbcMain.Controls.Add(Me.tabFilesTbcMain)
        Me.tbcMain.Location = New System.Drawing.Point(23, 36)
        Me.tbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.tbcMain.Name = "tbcMain"
        Me.tbcMain.SelectedIndex = 0
        Me.tbcMain.Size = New System.Drawing.Size(1168, 369)
        Me.tbcMain.TabIndex = 1
        '
        'tabSummaryTbcMain
        '
        Me.tabSummaryTbcMain.Controls.Add(Me.grpMetricsTabSummaryTbcMain)
        Me.tabSummaryTbcMain.Controls.Add(Me.txtToStringInfoTabSummaryTbcMain)
        Me.tabSummaryTbcMain.Controls.Add(Me.Label7)
        Me.tabSummaryTbcMain.Controls.Add(Me.lblCountTrxLineTabSummaryTbcMain)
        Me.tabSummaryTbcMain.Controls.Add(Me.Label12)
        Me.tabSummaryTbcMain.Controls.Add(Me.lblCountTrxTabSummaryTbcMain)
        Me.tabSummaryTbcMain.Controls.Add(Me.Label10)
        Me.tabSummaryTbcMain.Controls.Add(Me.lblCountAccountTabSummaryTbcMain)
        Me.tabSummaryTbcMain.Controls.Add(Me.Label8)
        Me.tabSummaryTbcMain.Controls.Add(Me.lblCountCustomerTabCustomerTbcMain)
        Me.tabSummaryTbcMain.Controls.Add(Me.Label6)
        Me.tabSummaryTbcMain.Controls.Add(Me.lstTrxLineIDTabSummaryTbcMain)
        Me.tabSummaryTbcMain.Controls.Add(Me.Label5)
        Me.tabSummaryTbcMain.Controls.Add(Me.lstTrxIDTabSummaryTbcMain)
        Me.tabSummaryTbcMain.Controls.Add(Me.Label4)
        Me.tabSummaryTbcMain.Controls.Add(Me.lstAccountIDTabSummaryTbcMain)
        Me.tabSummaryTbcMain.Controls.Add(Me.Label3)
        Me.tabSummaryTbcMain.Controls.Add(Me.lstCustomerIDTabSummaryTbcMain)
        Me.tabSummaryTbcMain.Controls.Add(Me.Label2)
        Me.tabSummaryTbcMain.Location = New System.Drawing.Point(4, 22)
        Me.tabSummaryTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.tabSummaryTbcMain.Name = "tabSummaryTbcMain"
        Me.tabSummaryTbcMain.Padding = New System.Windows.Forms.Padding(2)
        Me.tabSummaryTbcMain.Size = New System.Drawing.Size(1160, 343)
        Me.tabSummaryTbcMain.TabIndex = 0
        Me.tabSummaryTbcMain.Text = "Summary"
        Me.tabSummaryTbcMain.UseVisualStyleBackColor = True
        '
        'grpMetricsTabSummaryTbcMain
        '
        Me.grpMetricsTabSummaryTbcMain.Controls.Add(Me.txtMetricsGrpMetricsTabSummaryTbcMain)
        Me.grpMetricsTabSummaryTbcMain.Location = New System.Drawing.Point(23, 211)
        Me.grpMetricsTabSummaryTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.grpMetricsTabSummaryTbcMain.Name = "grpMetricsTabSummaryTbcMain"
        Me.grpMetricsTabSummaryTbcMain.Padding = New System.Windows.Forms.Padding(2)
        Me.grpMetricsTabSummaryTbcMain.Size = New System.Drawing.Size(1169, 114)
        Me.grpMetricsTabSummaryTbcMain.TabIndex = 18
        Me.grpMetricsTabSummaryTbcMain.TabStop = False
        Me.grpMetricsTabSummaryTbcMain.Text = "&Metrics"
        '
        'txtMetricsGrpMetricsTabSummaryTbcMain
        '
        Me.txtMetricsGrpMetricsTabSummaryTbcMain.Location = New System.Drawing.Point(4, 17)
        Me.txtMetricsGrpMetricsTabSummaryTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtMetricsGrpMetricsTabSummaryTbcMain.Multiline = True
        Me.txtMetricsGrpMetricsTabSummaryTbcMain.Name = "txtMetricsGrpMetricsTabSummaryTbcMain"
        Me.txtMetricsGrpMetricsTabSummaryTbcMain.ReadOnly = True
        Me.txtMetricsGrpMetricsTabSummaryTbcMain.ScrollBars = System.Windows.Forms.ScrollBars.Both
        Me.txtMetricsGrpMetricsTabSummaryTbcMain.Size = New System.Drawing.Size(1162, 94)
        Me.txtMetricsGrpMetricsTabSummaryTbcMain.TabIndex = 0
        '
        'txtToStringInfoTabSummaryTbcMain
        '
        Me.txtToStringInfoTabSummaryTbcMain.Location = New System.Drawing.Point(507, 31)
        Me.txtToStringInfoTabSummaryTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtToStringInfoTabSummaryTbcMain.Multiline = True
        Me.txtToStringInfoTabSummaryTbcMain.Name = "txtToStringInfoTabSummaryTbcMain"
        Me.txtToStringInfoTabSummaryTbcMain.ReadOnly = True
        Me.txtToStringInfoTabSummaryTbcMain.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtToStringInfoTabSummaryTbcMain.Size = New System.Drawing.Size(324, 152)
        Me.txtToStringInfoTabSummaryTbcMain.TabIndex = 17
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(504, 15)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(105, 13)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "ToString &Information:"
        '
        'lblCountTrxLineTabSummaryTbcMain
        '
        Me.lblCountTrxLineTabSummaryTbcMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCountTrxLineTabSummaryTbcMain.Location = New System.Drawing.Point(386, 181)
        Me.lblCountTrxLineTabSummaryTbcMain.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCountTrxLineTabSummaryTbcMain.Name = "lblCountTrxLineTabSummaryTbcMain"
        Me.lblCountTrxLineTabSummaryTbcMain.Size = New System.Drawing.Size(40, 15)
        Me.lblCountTrxLineTabSummaryTbcMain.TabIndex = 15
        Me.lblCountTrxLineTabSummaryTbcMain.Text = "Label7"
        Me.lblCountTrxLineTabSummaryTbcMain.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(343, 181)
        Me.Label12.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(38, 13)
        Me.Label12.TabIndex = 14
        Me.Label12.Text = "Count:"
        '
        'lblCountTrxTabSummaryTbcMain
        '
        Me.lblCountTrxTabSummaryTbcMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCountTrxTabSummaryTbcMain.Location = New System.Drawing.Point(279, 181)
        Me.lblCountTrxTabSummaryTbcMain.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCountTrxTabSummaryTbcMain.Name = "lblCountTrxTabSummaryTbcMain"
        Me.lblCountTrxTabSummaryTbcMain.Size = New System.Drawing.Size(40, 15)
        Me.lblCountTrxTabSummaryTbcMain.TabIndex = 11
        Me.lblCountTrxTabSummaryTbcMain.Text = "Label7"
        Me.lblCountTrxTabSummaryTbcMain.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(235, 181)
        Me.Label10.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(38, 13)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "Count:"
        '
        'lblCountAccountTabSummaryTbcMain
        '
        Me.lblCountAccountTabSummaryTbcMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCountAccountTabSummaryTbcMain.Location = New System.Drawing.Point(171, 181)
        Me.lblCountAccountTabSummaryTbcMain.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCountAccountTabSummaryTbcMain.Name = "lblCountAccountTabSummaryTbcMain"
        Me.lblCountAccountTabSummaryTbcMain.Size = New System.Drawing.Size(40, 15)
        Me.lblCountAccountTabSummaryTbcMain.TabIndex = 7
        Me.lblCountAccountTabSummaryTbcMain.Text = "Label7"
        Me.lblCountAccountTabSummaryTbcMain.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(128, 181)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(38, 13)
        Me.Label8.TabIndex = 6
        Me.Label8.Text = "Count:"
        '
        'lblCountCustomerTabCustomerTbcMain
        '
        Me.lblCountCustomerTabCustomerTbcMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCountCustomerTabCustomerTbcMain.Location = New System.Drawing.Point(64, 181)
        Me.lblCountCustomerTabCustomerTbcMain.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCountCustomerTabCustomerTbcMain.Name = "lblCountCustomerTabCustomerTbcMain"
        Me.lblCountCustomerTabCustomerTbcMain.Size = New System.Drawing.Size(40, 15)
        Me.lblCountCustomerTabCustomerTbcMain.TabIndex = 3
        Me.lblCountCustomerTabCustomerTbcMain.Text = "Label7"
        Me.lblCountCustomerTabCustomerTbcMain.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(21, 181)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(38, 13)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Count:"
        '
        'lstTrxLineIDTabSummaryTbcMain
        '
        Me.lstTrxLineIDTabSummaryTbcMain.FormattingEnabled = True
        Me.lstTrxLineIDTabSummaryTbcMain.Location = New System.Drawing.Point(345, 31)
        Me.lstTrxLineIDTabSummaryTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.lstTrxLineIDTabSummaryTbcMain.Name = "lstTrxLineIDTabSummaryTbcMain"
        Me.lstTrxLineIDTabSummaryTbcMain.Size = New System.Drawing.Size(81, 147)
        Me.lstTrxLineIDTabSummaryTbcMain.TabIndex = 13
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(343, 15)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 13)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Trx&Line List:"
        '
        'lstTrxIDTabSummaryTbcMain
        '
        Me.lstTrxIDTabSummaryTbcMain.FormattingEnabled = True
        Me.lstTrxIDTabSummaryTbcMain.Location = New System.Drawing.Point(238, 31)
        Me.lstTrxIDTabSummaryTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.lstTrxIDTabSummaryTbcMain.Name = "lstTrxIDTabSummaryTbcMain"
        Me.lstTrxIDTabSummaryTbcMain.Size = New System.Drawing.Size(81, 147)
        Me.lstTrxIDTabSummaryTbcMain.TabIndex = 9
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(235, 15)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(44, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "&Trx List:"
        '
        'lstAccountIDTabSummaryTbcMain
        '
        Me.lstAccountIDTabSummaryTbcMain.FormattingEnabled = True
        Me.lstAccountIDTabSummaryTbcMain.Location = New System.Drawing.Point(131, 31)
        Me.lstAccountIDTabSummaryTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.lstAccountIDTabSummaryTbcMain.Name = "lstAccountIDTabSummaryTbcMain"
        Me.lstAccountIDTabSummaryTbcMain.Size = New System.Drawing.Size(81, 147)
        Me.lstAccountIDTabSummaryTbcMain.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(130, 15)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(69, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "&Account List:"
        '
        'lstCustomerIDTabSummaryTbcMain
        '
        Me.lstCustomerIDTabSummaryTbcMain.FormattingEnabled = True
        Me.lstCustomerIDTabSummaryTbcMain.Location = New System.Drawing.Point(23, 31)
        Me.lstCustomerIDTabSummaryTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.lstCustomerIDTabSummaryTbcMain.Name = "lstCustomerIDTabSummaryTbcMain"
        Me.lstCustomerIDTabSummaryTbcMain.Size = New System.Drawing.Size(81, 147)
        Me.lstCustomerIDTabSummaryTbcMain.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(21, 15)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 13)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "&Customer List:"
        '
        'tbcCustomerTbcMain
        '
        Me.tbcCustomerTbcMain.Controls.Add(Me.grpCreateTabCustomerTbcMain)
        Me.tbcCustomerTbcMain.Controls.Add(Me.cboCustomerIDTabCustomerTbcMain)
        Me.tbcCustomerTbcMain.Controls.Add(Me.lblCountTrxTabCustomerTbcMain)
        Me.tbcCustomerTbcMain.Controls.Add(Me.Label16)
        Me.tbcCustomerTbcMain.Controls.Add(Me.lstTrxIDTabCustomerTbcMain)
        Me.tbcCustomerTbcMain.Controls.Add(Me.Label15)
        Me.tbcCustomerTbcMain.Controls.Add(Me.txtToStringInfoTabCustomerTbcMain)
        Me.tbcCustomerTbcMain.Controls.Add(Me.Label14)
        Me.tbcCustomerTbcMain.Controls.Add(Me.Label9)
        Me.tbcCustomerTbcMain.Location = New System.Drawing.Point(4, 22)
        Me.tbcCustomerTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.tbcCustomerTbcMain.Name = "tbcCustomerTbcMain"
        Me.tbcCustomerTbcMain.Padding = New System.Windows.Forms.Padding(2)
        Me.tbcCustomerTbcMain.Size = New System.Drawing.Size(1160, 343)
        Me.tbcCustomerTbcMain.TabIndex = 1
        Me.tbcCustomerTbcMain.Text = "Customer"
        Me.tbcCustomerTbcMain.UseVisualStyleBackColor = True
        '
        'grpCreateTabCustomerTbcMain
        '
        Me.grpCreateTabCustomerTbcMain.Controls.Add(Me.btnCreateCustomerGrpCreateTabCustomerTbcMain)
        Me.grpCreateTabCustomerTbcMain.Controls.Add(Me.txtNameGrpCreateTabCustomerTbcMain)
        Me.grpCreateTabCustomerTbcMain.Controls.Add(Me.Label11)
        Me.grpCreateTabCustomerTbcMain.Controls.Add(Me.Label13)
        Me.grpCreateTabCustomerTbcMain.Controls.Add(Me.dtpBirthdateGrpCreateTabCustomerTbcMain)
        Me.grpCreateTabCustomerTbcMain.Location = New System.Drawing.Point(26, 60)
        Me.grpCreateTabCustomerTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.grpCreateTabCustomerTbcMain.Name = "grpCreateTabCustomerTbcMain"
        Me.grpCreateTabCustomerTbcMain.Padding = New System.Windows.Forms.Padding(2)
        Me.grpCreateTabCustomerTbcMain.Size = New System.Drawing.Size(330, 158)
        Me.grpCreateTabCustomerTbcMain.TabIndex = 2
        Me.grpCreateTabCustomerTbcMain.TabStop = False
        Me.grpCreateTabCustomerTbcMain.Text = "&Create"
        '
        'btnCreateCustomerGrpCreateTabCustomerTbcMain
        '
        Me.btnCreateCustomerGrpCreateTabCustomerTbcMain.Location = New System.Drawing.Point(85, 118)
        Me.btnCreateCustomerGrpCreateTabCustomerTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.btnCreateCustomerGrpCreateTabCustomerTbcMain.Name = "btnCreateCustomerGrpCreateTabCustomerTbcMain"
        Me.btnCreateCustomerGrpCreateTabCustomerTbcMain.Size = New System.Drawing.Size(159, 21)
        Me.btnCreateCustomerGrpCreateTabCustomerTbcMain.TabIndex = 2
        Me.btnCreateCustomerGrpCreateTabCustomerTbcMain.Text = "&Create Customer"
        Me.ToolTip1.SetToolTip(Me.btnCreateCustomerGrpCreateTabCustomerTbcMain, "create customer")
        Me.btnCreateCustomerGrpCreateTabCustomerTbcMain.UseVisualStyleBackColor = True
        '
        'txtNameGrpCreateTabCustomerTbcMain
        '
        Me.txtNameGrpCreateTabCustomerTbcMain.Location = New System.Drawing.Point(79, 34)
        Me.txtNameGrpCreateTabCustomerTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtNameGrpCreateTabCustomerTbcMain.Name = "txtNameGrpCreateTabCustomerTbcMain"
        Me.txtNameGrpCreateTabCustomerTbcMain.Size = New System.Drawing.Size(235, 20)
        Me.txtNameGrpCreateTabCustomerTbcMain.TabIndex = 0
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(17, 36)
        Me.Label11.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(38, 13)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "&Name:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(17, 74)
        Me.Label13.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(52, 13)
        Me.Label13.TabIndex = 2
        Me.Label13.Text = "&Birthdate:"
        '
        'dtpBirthdateGrpCreateTabCustomerTbcMain
        '
        Me.dtpBirthdateGrpCreateTabCustomerTbcMain.Location = New System.Drawing.Point(79, 71)
        Me.dtpBirthdateGrpCreateTabCustomerTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpBirthdateGrpCreateTabCustomerTbcMain.Name = "dtpBirthdateGrpCreateTabCustomerTbcMain"
        Me.dtpBirthdateGrpCreateTabCustomerTbcMain.Size = New System.Drawing.Size(235, 20)
        Me.dtpBirthdateGrpCreateTabCustomerTbcMain.TabIndex = 1
        Me.dtpBirthdateGrpCreateTabCustomerTbcMain.Value = New Date(2016, 11, 10, 20, 1, 32, 0)
        '
        'cboCustomerIDTabCustomerTbcMain
        '
        Me.cboCustomerIDTabCustomerTbcMain.FormattingEnabled = True
        Me.cboCustomerIDTabCustomerTbcMain.Location = New System.Drawing.Point(96, 21)
        Me.cboCustomerIDTabCustomerTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.cboCustomerIDTabCustomerTbcMain.Name = "cboCustomerIDTabCustomerTbcMain"
        Me.cboCustomerIDTabCustomerTbcMain.Size = New System.Drawing.Size(82, 21)
        Me.cboCustomerIDTabCustomerTbcMain.TabIndex = 0
        '
        'lblCountTrxTabCustomerTbcMain
        '
        Me.lblCountTrxTabCustomerTbcMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCountTrxTabCustomerTbcMain.Location = New System.Drawing.Point(462, 204)
        Me.lblCountTrxTabCustomerTbcMain.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCountTrxTabCustomerTbcMain.Name = "lblCountTrxTabCustomerTbcMain"
        Me.lblCountTrxTabCustomerTbcMain.Size = New System.Drawing.Size(40, 15)
        Me.lblCountTrxTabCustomerTbcMain.TabIndex = 6
        Me.lblCountTrxTabCustomerTbcMain.Text = "Label7"
        Me.lblCountTrxTabCustomerTbcMain.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(421, 205)
        Me.Label16.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(38, 13)
        Me.Label16.TabIndex = 5
        Me.Label16.Text = "Count:"
        '
        'lstTrxIDTabCustomerTbcMain
        '
        Me.lstTrxIDTabCustomerTbcMain.FormattingEnabled = True
        Me.lstTrxIDTabCustomerTbcMain.Location = New System.Drawing.Point(424, 39)
        Me.lstTrxIDTabCustomerTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.lstTrxIDTabCustomerTbcMain.Name = "lstTrxIDTabCustomerTbcMain"
        Me.lstTrxIDTabCustomerTbcMain.Size = New System.Drawing.Size(81, 160)
        Me.lstTrxIDTabCustomerTbcMain.TabIndex = 4
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(421, 23)
        Me.Label15.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(125, 13)
        Me.Label15.TabIndex = 3
        Me.Label15.Text = "Customer's &Transactions:"
        '
        'txtToStringInfoTabCustomerTbcMain
        '
        Me.txtToStringInfoTabCustomerTbcMain.Location = New System.Drawing.Point(606, 38)
        Me.txtToStringInfoTabCustomerTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtToStringInfoTabCustomerTbcMain.Multiline = True
        Me.txtToStringInfoTabCustomerTbcMain.Name = "txtToStringInfoTabCustomerTbcMain"
        Me.txtToStringInfoTabCustomerTbcMain.ReadOnly = True
        Me.txtToStringInfoTabCustomerTbcMain.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtToStringInfoTabCustomerTbcMain.Size = New System.Drawing.Size(293, 161)
        Me.txtToStringInfoTabCustomerTbcMain.TabIndex = 8
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(603, 23)
        Me.Label14.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(105, 13)
        Me.Label14.TabIndex = 7
        Me.Label14.Text = "ToString &Information:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(23, 25)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(68, 13)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Customer I&D:"
        '
        'tabAccountTbcMain
        '
        Me.tabAccountTbcMain.Controls.Add(Me.lblCountOwnersTabAccountTbcMain)
        Me.tabAccountTbcMain.Controls.Add(Me.Label26)
        Me.tabAccountTbcMain.Controls.Add(Me.grpClosedTabAccountTbcMain)
        Me.tabAccountTbcMain.Controls.Add(Me.lstCustomerIDTabAccountTbcMain)
        Me.tabAccountTbcMain.Controls.Add(Me.btnModifyAccountTabAccountTbcMain)
        Me.tabAccountTbcMain.Controls.Add(Me.Label27)
        Me.tabAccountTbcMain.Controls.Add(Me.grpCreateModifyTabAccountTbcMain)
        Me.tabAccountTbcMain.Controls.Add(Me.cboAccountIDTabAccountTbcMain)
        Me.tabAccountTbcMain.Controls.Add(Me.lblCountTrxLinesTabAccountTbcMain)
        Me.tabAccountTbcMain.Controls.Add(Me.Label20)
        Me.tabAccountTbcMain.Controls.Add(Me.lstTrxLineIDTabAccountTbcMain)
        Me.tabAccountTbcMain.Controls.Add(Me.Label21)
        Me.tabAccountTbcMain.Controls.Add(Me.txtToStringInfoTabAccountTbcMain)
        Me.tabAccountTbcMain.Controls.Add(Me.btnCreateAccountTabAccountTbcMain)
        Me.tabAccountTbcMain.Controls.Add(Me.Label22)
        Me.tabAccountTbcMain.Controls.Add(Me.Label23)
        Me.tabAccountTbcMain.Location = New System.Drawing.Point(4, 22)
        Me.tabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.tabAccountTbcMain.Name = "tabAccountTbcMain"
        Me.tabAccountTbcMain.Size = New System.Drawing.Size(1160, 343)
        Me.tabAccountTbcMain.TabIndex = 2
        Me.tabAccountTbcMain.Text = "Account"
        Me.tabAccountTbcMain.UseVisualStyleBackColor = True
        '
        'lblCountOwnersTabAccountTbcMain
        '
        Me.lblCountOwnersTabAccountTbcMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCountOwnersTabAccountTbcMain.Location = New System.Drawing.Point(601, 203)
        Me.lblCountOwnersTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCountOwnersTabAccountTbcMain.Name = "lblCountOwnersTabAccountTbcMain"
        Me.lblCountOwnersTabAccountTbcMain.Size = New System.Drawing.Size(40, 15)
        Me.lblCountOwnersTabAccountTbcMain.TabIndex = 7
        Me.lblCountOwnersTabAccountTbcMain.Text = "Label7"
        Me.lblCountOwnersTabAccountTbcMain.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(560, 205)
        Me.Label26.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(38, 13)
        Me.Label26.TabIndex = 6
        Me.Label26.Text = "Count:"
        '
        'grpClosedTabAccountTbcMain
        '
        Me.grpClosedTabAccountTbcMain.Controls.Add(Me.dtpClosedDateGrpClosedTabAccountTbcMain)
        Me.grpClosedTabAccountTbcMain.Controls.Add(Me.chkClosedGrpClosedTabAccountTbcMain)
        Me.grpClosedTabAccountTbcMain.Controls.Add(Me.Label97)
        Me.grpClosedTabAccountTbcMain.Location = New System.Drawing.Point(189, 10)
        Me.grpClosedTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.grpClosedTabAccountTbcMain.Name = "grpClosedTabAccountTbcMain"
        Me.grpClosedTabAccountTbcMain.Padding = New System.Windows.Forms.Padding(2)
        Me.grpClosedTabAccountTbcMain.Size = New System.Drawing.Size(329, 45)
        Me.grpClosedTabAccountTbcMain.TabIndex = 2
        Me.grpClosedTabAccountTbcMain.TabStop = False
        Me.grpClosedTabAccountTbcMain.Text = "Closed"
        '
        'dtpClosedDateGrpClosedTabAccountTbcMain
        '
        Me.dtpClosedDateGrpClosedTabAccountTbcMain.Location = New System.Drawing.Point(141, 18)
        Me.dtpClosedDateGrpClosedTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpClosedDateGrpClosedTabAccountTbcMain.Name = "dtpClosedDateGrpClosedTabAccountTbcMain"
        Me.dtpClosedDateGrpClosedTabAccountTbcMain.Size = New System.Drawing.Size(182, 20)
        Me.dtpClosedDateGrpClosedTabAccountTbcMain.TabIndex = 1
        '
        'chkClosedGrpClosedTabAccountTbcMain
        '
        Me.chkClosedGrpClosedTabAccountTbcMain.AutoSize = True
        Me.chkClosedGrpClosedTabAccountTbcMain.Location = New System.Drawing.Point(13, 18)
        Me.chkClosedGrpClosedTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.chkClosedGrpClosedTabAccountTbcMain.Name = "chkClosedGrpClosedTabAccountTbcMain"
        Me.chkClosedGrpClosedTabAccountTbcMain.Size = New System.Drawing.Size(58, 17)
        Me.chkClosedGrpClosedTabAccountTbcMain.TabIndex = 0
        Me.chkClosedGrpClosedTabAccountTbcMain.Text = "Closed"
        Me.chkClosedGrpClosedTabAccountTbcMain.UseVisualStyleBackColor = True
        '
        'Label97
        '
        Me.Label97.AutoSize = True
        Me.Label97.Location = New System.Drawing.Point(73, 19)
        Me.Label97.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label97.Name = "Label97"
        Me.Label97.Size = New System.Drawing.Size(68, 13)
        Me.Label97.TabIndex = 1
        Me.Label97.Text = "Closed Date:"
        '
        'lstCustomerIDTabAccountTbcMain
        '
        Me.lstCustomerIDTabAccountTbcMain.FormattingEnabled = True
        Me.lstCustomerIDTabAccountTbcMain.Location = New System.Drawing.Point(563, 38)
        Me.lstCustomerIDTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.lstCustomerIDTabAccountTbcMain.Name = "lstCustomerIDTabAccountTbcMain"
        Me.lstCustomerIDTabAccountTbcMain.Size = New System.Drawing.Size(81, 160)
        Me.lstCustomerIDTabAccountTbcMain.TabIndex = 5
        '
        'btnModifyAccountTabAccountTbcMain
        '
        Me.btnModifyAccountTabAccountTbcMain.Location = New System.Drawing.Point(172, 306)
        Me.btnModifyAccountTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.btnModifyAccountTabAccountTbcMain.Name = "btnModifyAccountTabAccountTbcMain"
        Me.btnModifyAccountTabAccountTbcMain.Size = New System.Drawing.Size(126, 21)
        Me.btnModifyAccountTabAccountTbcMain.TabIndex = 3
        Me.btnModifyAccountTabAccountTbcMain.Text = "&Modify Account"
        Me.ToolTip1.SetToolTip(Me.btnModifyAccountTabAccountTbcMain, "modify account")
        Me.btnModifyAccountTabAccountTbcMain.UseVisualStyleBackColor = True
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(560, 22)
        Me.Label27.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(110, 13)
        Me.Label27.TabIndex = 4
        Me.Label27.Text = "Account's &Owner IDs:"
        '
        'grpCreateModifyTabAccountTbcMain
        '
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.txtTrxIDGrpCreateModifyTabAccountTbcMain)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.Label19)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.txtTrxLineIDGrpCreateModifyTabAccountTbcMain)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.Label31)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.Label71)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.dtpNextInterestAccrualDateGrpCreateModifyTabAccountTbcMain)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.lstNewOwnerIDGrpCreateModifyTabAccountTbcMain)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.Label73)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.Label96)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.nudAPRGrpCreateModifyTabAccountTbcMain)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.Label95)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.txtAmountGrpCreateModifyTabAccountTbcMain)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.Label94)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.grpTypeGrpCreateModifyTabAccountTbcMain)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.btnAddAccountOwnerGrpCreateModifyTabAccountTbcMain)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.cboCustomerIDGrpCreateModifyTabAccountTbcMain)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.Label24)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.txtNameGrpCreateModifyTabAccountTbcMain)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.Label17)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.Label18)
        Me.grpCreateModifyTabAccountTbcMain.Controls.Add(Me.dtpDateOpenedGrpCreateModifyTabAccountTbcMain)
        Me.grpCreateModifyTabAccountTbcMain.Location = New System.Drawing.Point(25, 59)
        Me.grpCreateModifyTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.grpCreateModifyTabAccountTbcMain.Name = "grpCreateModifyTabAccountTbcMain"
        Me.grpCreateModifyTabAccountTbcMain.Padding = New System.Windows.Forms.Padding(2)
        Me.grpCreateModifyTabAccountTbcMain.Size = New System.Drawing.Size(408, 231)
        Me.grpCreateModifyTabAccountTbcMain.TabIndex = 3
        Me.grpCreateModifyTabAccountTbcMain.TabStop = False
        Me.grpCreateModifyTabAccountTbcMain.Text = "Create/&Modify"
        '
        'txtTrxIDGrpCreateModifyTabAccountTbcMain
        '
        Me.txtTrxIDGrpCreateModifyTabAccountTbcMain.Location = New System.Drawing.Point(236, 152)
        Me.txtTrxIDGrpCreateModifyTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTrxIDGrpCreateModifyTabAccountTbcMain.Name = "txtTrxIDGrpCreateModifyTabAccountTbcMain"
        Me.txtTrxIDGrpCreateModifyTabAccountTbcMain.Size = New System.Drawing.Size(58, 20)
        Me.txtTrxIDGrpCreateModifyTabAccountTbcMain.TabIndex = 4
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(176, 155)
        Me.Label19.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(39, 13)
        Me.Label19.TabIndex = 12
        Me.Label19.Text = "Trx ID:"
        '
        'txtTrxLineIDGrpCreateModifyTabAccountTbcMain
        '
        Me.txtTrxLineIDGrpCreateModifyTabAccountTbcMain.Location = New System.Drawing.Point(236, 178)
        Me.txtTrxLineIDGrpCreateModifyTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTrxLineIDGrpCreateModifyTabAccountTbcMain.Name = "txtTrxLineIDGrpCreateModifyTabAccountTbcMain"
        Me.txtTrxLineIDGrpCreateModifyTabAccountTbcMain.Size = New System.Drawing.Size(58, 20)
        Me.txtTrxLineIDGrpCreateModifyTabAccountTbcMain.TabIndex = 6
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(176, 181)
        Me.Label31.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(59, 13)
        Me.Label31.TabIndex = 17
        Me.Label31.Text = "TrxLine ID:"
        '
        'Label71
        '
        Me.Label71.AutoSize = True
        Me.Label71.Location = New System.Drawing.Point(17, 207)
        Me.Label71.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(135, 13)
        Me.Label71.TabIndex = 19
        Me.Label71.Text = "Next Interest Accrual Date:"
        '
        'dtpNextInterestAccrualDateGrpCreateModifyTabAccountTbcMain
        '
        Me.dtpNextInterestAccrualDateGrpCreateModifyTabAccountTbcMain.Enabled = False
        Me.dtpNextInterestAccrualDateGrpCreateModifyTabAccountTbcMain.Location = New System.Drawing.Point(154, 205)
        Me.dtpNextInterestAccrualDateGrpCreateModifyTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpNextInterestAccrualDateGrpCreateModifyTabAccountTbcMain.Name = "dtpNextInterestAccrualDateGrpCreateModifyTabAccountTbcMain"
        Me.dtpNextInterestAccrualDateGrpCreateModifyTabAccountTbcMain.Size = New System.Drawing.Size(236, 20)
        Me.dtpNextInterestAccrualDateGrpCreateModifyTabAccountTbcMain.TabIndex = 7
        '
        'lstNewOwnerIDGrpCreateModifyTabAccountTbcMain
        '
        Me.lstNewOwnerIDGrpCreateModifyTabAccountTbcMain.FormattingEnabled = True
        Me.lstNewOwnerIDGrpCreateModifyTabAccountTbcMain.Location = New System.Drawing.Point(309, 38)
        Me.lstNewOwnerIDGrpCreateModifyTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.lstNewOwnerIDGrpCreateModifyTabAccountTbcMain.Name = "lstNewOwnerIDGrpCreateModifyTabAccountTbcMain"
        Me.lstNewOwnerIDGrpCreateModifyTabAccountTbcMain.Size = New System.Drawing.Size(81, 160)
        Me.lstNewOwnerIDGrpCreateModifyTabAccountTbcMain.TabIndex = 4
        '
        'Label73
        '
        Me.Label73.AutoSize = True
        Me.Label73.Location = New System.Drawing.Point(105, 181)
        Me.Label73.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(15, 13)
        Me.Label73.TabIndex = 16
        Me.Label73.Text = "%"
        '
        'Label96
        '
        Me.Label96.AutoSize = True
        Me.Label96.Location = New System.Drawing.Point(307, 21)
        Me.Label96.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label96.Name = "Label96"
        Me.Label96.Size = New System.Drawing.Size(85, 13)
        Me.Label96.TabIndex = 3
        Me.Label96.Text = "N&ew Owner IDs:"
        '
        'nudAPRGrpCreateModifyTabAccountTbcMain
        '
        Me.nudAPRGrpCreateModifyTabAccountTbcMain.DecimalPlaces = 2
        Me.nudAPRGrpCreateModifyTabAccountTbcMain.Location = New System.Drawing.Point(51, 179)
        Me.nudAPRGrpCreateModifyTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.nudAPRGrpCreateModifyTabAccountTbcMain.Name = "nudAPRGrpCreateModifyTabAccountTbcMain"
        Me.nudAPRGrpCreateModifyTabAccountTbcMain.Size = New System.Drawing.Size(50, 20)
        Me.nudAPRGrpCreateModifyTabAccountTbcMain.TabIndex = 5
        Me.nudAPRGrpCreateModifyTabAccountTbcMain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Location = New System.Drawing.Point(17, 181)
        Me.Label95.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(32, 13)
        Me.Label95.TabIndex = 14
        Me.Label95.Text = "APR:"
        '
        'txtAmountGrpCreateModifyTabAccountTbcMain
        '
        Me.txtAmountGrpCreateModifyTabAccountTbcMain.Location = New System.Drawing.Point(101, 152)
        Me.txtAmountGrpCreateModifyTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtAmountGrpCreateModifyTabAccountTbcMain.Name = "txtAmountGrpCreateModifyTabAccountTbcMain"
        Me.txtAmountGrpCreateModifyTabAccountTbcMain.Size = New System.Drawing.Size(68, 20)
        Me.txtAmountGrpCreateModifyTabAccountTbcMain.TabIndex = 3
        Me.txtAmountGrpCreateModifyTabAccountTbcMain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Location = New System.Drawing.Point(17, 154)
        Me.Label94.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(82, 13)
        Me.Label94.TabIndex = 10
        Me.Label94.Text = "Initial Amount: &$"
        '
        'grpTypeGrpCreateModifyTabAccountTbcMain
        '
        Me.grpTypeGrpCreateModifyTabAccountTbcMain.Controls.Add(Me.radCreditCardGrpTypeGrpCreateModifyTabAccountTbcMain)
        Me.grpTypeGrpCreateModifyTabAccountTbcMain.Controls.Add(Me.radLoanGrpTypeGrpCreateModifyTabAccountTbcMain)
        Me.grpTypeGrpCreateModifyTabAccountTbcMain.Controls.Add(Me.radCheckingGrpTypeGrpCreateModifyTabAccountTbcMain)
        Me.grpTypeGrpCreateModifyTabAccountTbcMain.Location = New System.Drawing.Point(17, 44)
        Me.grpTypeGrpCreateModifyTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.grpTypeGrpCreateModifyTabAccountTbcMain.Name = "grpTypeGrpCreateModifyTabAccountTbcMain"
        Me.grpTypeGrpCreateModifyTabAccountTbcMain.Padding = New System.Windows.Forms.Padding(2)
        Me.grpTypeGrpCreateModifyTabAccountTbcMain.Size = New System.Drawing.Size(277, 47)
        Me.grpTypeGrpCreateModifyTabAccountTbcMain.TabIndex = 5
        Me.grpTypeGrpCreateModifyTabAccountTbcMain.TabStop = False
        Me.grpTypeGrpCreateModifyTabAccountTbcMain.Text = "Type"
        '
        'radCreditCardGrpTypeGrpCreateModifyTabAccountTbcMain
        '
        Me.radCreditCardGrpTypeGrpCreateModifyTabAccountTbcMain.AutoSize = True
        Me.radCreditCardGrpTypeGrpCreateModifyTabAccountTbcMain.Location = New System.Drawing.Point(192, 19)
        Me.radCreditCardGrpTypeGrpCreateModifyTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.radCreditCardGrpTypeGrpCreateModifyTabAccountTbcMain.Name = "radCreditCardGrpTypeGrpCreateModifyTabAccountTbcMain"
        Me.radCreditCardGrpTypeGrpCreateModifyTabAccountTbcMain.Size = New System.Drawing.Size(77, 17)
        Me.radCreditCardGrpTypeGrpCreateModifyTabAccountTbcMain.TabIndex = 2
        Me.radCreditCardGrpTypeGrpCreateModifyTabAccountTbcMain.TabStop = True
        Me.radCreditCardGrpTypeGrpCreateModifyTabAccountTbcMain.Text = "Credit Card"
        Me.radCreditCardGrpTypeGrpCreateModifyTabAccountTbcMain.UseVisualStyleBackColor = True
        '
        'radLoanGrpTypeGrpCreateModifyTabAccountTbcMain
        '
        Me.radLoanGrpTypeGrpCreateModifyTabAccountTbcMain.AutoSize = True
        Me.radLoanGrpTypeGrpCreateModifyTabAccountTbcMain.Location = New System.Drawing.Point(111, 19)
        Me.radLoanGrpTypeGrpCreateModifyTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.radLoanGrpTypeGrpCreateModifyTabAccountTbcMain.Name = "radLoanGrpTypeGrpCreateModifyTabAccountTbcMain"
        Me.radLoanGrpTypeGrpCreateModifyTabAccountTbcMain.Size = New System.Drawing.Size(49, 17)
        Me.radLoanGrpTypeGrpCreateModifyTabAccountTbcMain.TabIndex = 1
        Me.radLoanGrpTypeGrpCreateModifyTabAccountTbcMain.TabStop = True
        Me.radLoanGrpTypeGrpCreateModifyTabAccountTbcMain.Text = "Loan"
        Me.radLoanGrpTypeGrpCreateModifyTabAccountTbcMain.UseVisualStyleBackColor = True
        '
        'radCheckingGrpTypeGrpCreateModifyTabAccountTbcMain
        '
        Me.radCheckingGrpTypeGrpCreateModifyTabAccountTbcMain.AutoSize = True
        Me.radCheckingGrpTypeGrpCreateModifyTabAccountTbcMain.Checked = True
        Me.radCheckingGrpTypeGrpCreateModifyTabAccountTbcMain.Location = New System.Drawing.Point(11, 19)
        Me.radCheckingGrpTypeGrpCreateModifyTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.radCheckingGrpTypeGrpCreateModifyTabAccountTbcMain.Name = "radCheckingGrpTypeGrpCreateModifyTabAccountTbcMain"
        Me.radCheckingGrpTypeGrpCreateModifyTabAccountTbcMain.Size = New System.Drawing.Size(70, 17)
        Me.radCheckingGrpTypeGrpCreateModifyTabAccountTbcMain.TabIndex = 0
        Me.radCheckingGrpTypeGrpCreateModifyTabAccountTbcMain.TabStop = True
        Me.radCheckingGrpTypeGrpCreateModifyTabAccountTbcMain.Text = "Checking"
        Me.radCheckingGrpTypeGrpCreateModifyTabAccountTbcMain.UseVisualStyleBackColor = True
        '
        'btnAddAccountOwnerGrpCreateModifyTabAccountTbcMain
        '
        Me.btnAddAccountOwnerGrpCreateModifyTabAccountTbcMain.Location = New System.Drawing.Point(180, 19)
        Me.btnAddAccountOwnerGrpCreateModifyTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.btnAddAccountOwnerGrpCreateModifyTabAccountTbcMain.Name = "btnAddAccountOwnerGrpCreateModifyTabAccountTbcMain"
        Me.btnAddAccountOwnerGrpCreateModifyTabAccountTbcMain.Size = New System.Drawing.Size(114, 21)
        Me.btnAddAccountOwnerGrpCreateModifyTabAccountTbcMain.TabIndex = 2
        Me.btnAddAccountOwnerGrpCreateModifyTabAccountTbcMain.Text = "&Add Account Owner"
        Me.ToolTip1.SetToolTip(Me.btnAddAccountOwnerGrpCreateModifyTabAccountTbcMain, "add account owner")
        Me.btnAddAccountOwnerGrpCreateModifyTabAccountTbcMain.UseVisualStyleBackColor = True
        '
        'cboCustomerIDGrpCreateModifyTabAccountTbcMain
        '
        Me.cboCustomerIDGrpCreateModifyTabAccountTbcMain.BackColor = System.Drawing.SystemColors.Window
        Me.cboCustomerIDGrpCreateModifyTabAccountTbcMain.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCustomerIDGrpCreateModifyTabAccountTbcMain.FormattingEnabled = True
        Me.cboCustomerIDGrpCreateModifyTabAccountTbcMain.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.cboCustomerIDGrpCreateModifyTabAccountTbcMain.Location = New System.Drawing.Point(89, 21)
        Me.cboCustomerIDGrpCreateModifyTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.cboCustomerIDGrpCreateModifyTabAccountTbcMain.Name = "cboCustomerIDGrpCreateModifyTabAccountTbcMain"
        Me.cboCustomerIDGrpCreateModifyTabAccountTbcMain.Size = New System.Drawing.Size(82, 21)
        Me.cboCustomerIDGrpCreateModifyTabAccountTbcMain.TabIndex = 0
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(17, 21)
        Me.Label24.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(68, 13)
        Me.Label24.TabIndex = 0
        Me.Label24.Text = "C&ustomer ID:"
        '
        'txtNameGrpCreateModifyTabAccountTbcMain
        '
        Me.txtNameGrpCreateModifyTabAccountTbcMain.Location = New System.Drawing.Point(57, 100)
        Me.txtNameGrpCreateModifyTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtNameGrpCreateModifyTabAccountTbcMain.Name = "txtNameGrpCreateModifyTabAccountTbcMain"
        Me.txtNameGrpCreateModifyTabAccountTbcMain.Size = New System.Drawing.Size(238, 20)
        Me.txtNameGrpCreateModifyTabAccountTbcMain.TabIndex = 1
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(17, 102)
        Me.Label17.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(38, 13)
        Me.Label17.TabIndex = 6
        Me.Label17.Text = "&Name:"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(17, 128)
        Me.Label18.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(74, 13)
        Me.Label18.TabIndex = 8
        Me.Label18.Text = "Date O&pened:"
        '
        'dtpDateOpenedGrpCreateModifyTabAccountTbcMain
        '
        Me.dtpDateOpenedGrpCreateModifyTabAccountTbcMain.Location = New System.Drawing.Point(94, 125)
        Me.dtpDateOpenedGrpCreateModifyTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpDateOpenedGrpCreateModifyTabAccountTbcMain.Name = "dtpDateOpenedGrpCreateModifyTabAccountTbcMain"
        Me.dtpDateOpenedGrpCreateModifyTabAccountTbcMain.Size = New System.Drawing.Size(201, 20)
        Me.dtpDateOpenedGrpCreateModifyTabAccountTbcMain.TabIndex = 2
        '
        'cboAccountIDTabAccountTbcMain
        '
        Me.cboAccountIDTabAccountTbcMain.FormattingEnabled = True
        Me.cboAccountIDTabAccountTbcMain.Location = New System.Drawing.Point(91, 19)
        Me.cboAccountIDTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.cboAccountIDTabAccountTbcMain.Name = "cboAccountIDTabAccountTbcMain"
        Me.cboAccountIDTabAccountTbcMain.Size = New System.Drawing.Size(82, 21)
        Me.cboAccountIDTabAccountTbcMain.TabIndex = 1
        '
        'lblCountTrxLinesTabAccountTbcMain
        '
        Me.lblCountTrxLinesTabAccountTbcMain.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCountTrxLinesTabAccountTbcMain.Location = New System.Drawing.Point(725, 204)
        Me.lblCountTrxLinesTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblCountTrxLinesTabAccountTbcMain.Name = "lblCountTrxLinesTabAccountTbcMain"
        Me.lblCountTrxLinesTabAccountTbcMain.Size = New System.Drawing.Size(40, 15)
        Me.lblCountTrxLinesTabAccountTbcMain.TabIndex = 11
        Me.lblCountTrxLinesTabAccountTbcMain.Text = "Label7"
        Me.lblCountTrxLinesTabAccountTbcMain.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(684, 205)
        Me.Label20.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(38, 13)
        Me.Label20.TabIndex = 10
        Me.Label20.Text = "Count:"
        '
        'lstTrxLineIDTabAccountTbcMain
        '
        Me.lstTrxLineIDTabAccountTbcMain.FormattingEnabled = True
        Me.lstTrxLineIDTabAccountTbcMain.Location = New System.Drawing.Point(687, 39)
        Me.lstTrxLineIDTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.lstTrxLineIDTabAccountTbcMain.Name = "lstTrxLineIDTabAccountTbcMain"
        Me.lstTrxLineIDTabAccountTbcMain.Size = New System.Drawing.Size(81, 160)
        Me.lstTrxLineIDTabAccountTbcMain.TabIndex = 9
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(684, 23)
        Me.Label21.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(117, 13)
        Me.Label21.TabIndex = 8
        Me.Label21.Text = "Account's &Trx Line IDs:"
        '
        'txtToStringInfoTabAccountTbcMain
        '
        Me.txtToStringInfoTabAccountTbcMain.Location = New System.Drawing.Point(845, 38)
        Me.txtToStringInfoTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtToStringInfoTabAccountTbcMain.Multiline = True
        Me.txtToStringInfoTabAccountTbcMain.Name = "txtToStringInfoTabAccountTbcMain"
        Me.txtToStringInfoTabAccountTbcMain.ReadOnly = True
        Me.txtToStringInfoTabAccountTbcMain.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtToStringInfoTabAccountTbcMain.Size = New System.Drawing.Size(293, 161)
        Me.txtToStringInfoTabAccountTbcMain.TabIndex = 13
        '
        'btnCreateAccountTabAccountTbcMain
        '
        Me.btnCreateAccountTabAccountTbcMain.Location = New System.Drawing.Point(25, 306)
        Me.btnCreateAccountTabAccountTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.btnCreateAccountTabAccountTbcMain.Name = "btnCreateAccountTabAccountTbcMain"
        Me.btnCreateAccountTabAccountTbcMain.Size = New System.Drawing.Size(126, 21)
        Me.btnCreateAccountTabAccountTbcMain.TabIndex = 2
        Me.btnCreateAccountTabAccountTbcMain.Text = "&Create Account"
        Me.ToolTip1.SetToolTip(Me.btnCreateAccountTabAccountTbcMain, "create account")
        Me.btnCreateAccountTabAccountTbcMain.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(842, 23)
        Me.Label22.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(105, 13)
        Me.Label22.TabIndex = 12
        Me.Label22.Text = "ToString &Information:"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(23, 23)
        Me.Label23.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(64, 13)
        Me.Label23.TabIndex = 0
        Me.Label23.Text = "Account I&D:"
        '
        'tabTransactionsTbcMain
        '
        Me.tabTransactionsTbcMain.Controls.Add(Me.tbcTransactionsTabTransactionsTbcMain)
        Me.tabTransactionsTbcMain.Location = New System.Drawing.Point(4, 22)
        Me.tabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.tabTransactionsTbcMain.Name = "tabTransactionsTbcMain"
        Me.tabTransactionsTbcMain.Size = New System.Drawing.Size(1160, 343)
        Me.tabTransactionsTbcMain.TabIndex = 3
        Me.tabTransactionsTbcMain.Text = "Transactions"
        Me.tabTransactionsTbcMain.UseVisualStyleBackColor = True
        '
        'tbcTransactionsTabTransactionsTbcMain
        '
        Me.tbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain)
        Me.tbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain)
        Me.tbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain)
        Me.tbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(2, 2)
        Me.tbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.tbcTransactionsTabTransactionsTbcMain.Name = "tbcTransactionsTabTransactionsTbcMain"
        Me.tbcTransactionsTabTransactionsTbcMain.SelectedIndex = 0
        Me.tbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(1215, 344)
        Me.tbcTransactionsTabTransactionsTbcMain.TabIndex = 0
        '
        'tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain
        '
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label25)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.dtpTrxDateTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label100)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.nudAmountTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label99)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.txtTrxLineIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label101)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label102)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label103)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.btnProcessTrxTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.txtTrxIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label104)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(4, 22)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Name = "tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain"
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(1207, 318)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabIndex = 10
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = "Make Deposit & Withdrawal, Use Debit Card, and Charge Purchase"
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.UseVisualStyleBackColor = True
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(17, 205)
        Me.Label25.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(33, 13)
        Me.Label25.TabIndex = 10
        Me.Label25.Text = "Date:"
        '
        'dtpTrxDateTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain
        '
        Me.dtpTrxDateTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(89, 205)
        Me.dtpTrxDateTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpTrxDateTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Name = "dtpTrxDateTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTb" &
    "cMain"
        Me.dtpTrxDateTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(201, 20)
        Me.dtpTrxDateTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabIndex = 5
        '
        'Label100
        '
        Me.Label100.AutoSize = True
        Me.Label100.Location = New System.Drawing.Point(17, 180)
        Me.Label100.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label100.Name = "Label100"
        Me.Label100.Size = New System.Drawing.Size(46, 13)
        Me.Label100.TabIndex = 8
        Me.Label100.Text = "Amount:"
        '
        'nudAmountTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain
        '
        Me.nudAmountTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.DecimalPlaces = 2
        Me.nudAmountTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(89, 178)
        Me.nudAmountTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.nudAmountTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Name = "nudAmountTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbc" &
    "Main"
        Me.nudAmountTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(67, 20)
        Me.nudAmountTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabIndex = 4
        Me.nudAmountTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label99
        '
        Me.Label99.AutoSize = True
        Me.Label99.Location = New System.Drawing.Point(17, 128)
        Me.Label99.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label99.Name = "Label99"
        Me.Label99.Size = New System.Drawing.Size(64, 13)
        Me.Label99.TabIndex = 4
        Me.Label99.Text = "Account ID:"
        '
        'txtTrxLineIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain
        '
        Me.txtTrxLineIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(89, 153)
        Me.txtTrxLineIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTrxLineIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Name = "txtTrxLineIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactions" &
    "TbcMain"
        Me.txtTrxLineIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(68, 20)
        Me.txtTrxLineIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabIndex = 3
        '
        'cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain
        '
        Me.cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.FormattingEnabled = True
        Me.cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(89, 74)
        Me.cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Name = "cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransaction" &
    "sTbcMain"
        Me.cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(82, 21)
        Me.cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabIndex = 0
        '
        'Label101
        '
        Me.Label101.AutoSize = True
        Me.Label101.Location = New System.Drawing.Point(17, 154)
        Me.Label101.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label101.Name = "Label101"
        Me.Label101.Size = New System.Drawing.Size(59, 13)
        Me.Label101.TabIndex = 6
        Me.Label101.Text = "TrxLine ID:"
        '
        'Label102
        '
        Me.Label102.AutoSize = True
        Me.Label102.Location = New System.Drawing.Point(17, 76)
        Me.Label102.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label102.Name = "Label102"
        Me.Label102.Size = New System.Drawing.Size(68, 13)
        Me.Label102.TabIndex = 0
        Me.Label102.Text = "Customer ID:"
        '
        'cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain
        '
        Me.cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.FormattingEnabled = True
        Me.cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(89, 126)
        Me.cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Name = "cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactions" &
    "TbcMain"
        Me.cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(82, 21)
        Me.cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabIndex = 2
        '
        'txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain
        '
        Me.txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(376, 93)
        Me.txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Multiline = True
        Me.txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Name = "txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsT" &
    "bcMain"
        Me.txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.ReadOnly = True
        Me.txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(380, 132)
        Me.txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabIndex = 13
        '
        'Label103
        '
        Me.Label103.AutoSize = True
        Me.Label103.Location = New System.Drawing.Point(373, 76)
        Me.Label103.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label103.Name = "Label103"
        Me.Label103.Size = New System.Drawing.Size(105, 13)
        Me.Label103.TabIndex = 12
        Me.Label103.Text = "ToString Information:"
        '
        'btnProcessTrxTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain
        '
        Me.btnProcessTrxTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(92, 285)
        Me.btnProcessTrxTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.btnProcessTrxTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Name = "btnProcessTrxTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransaction" &
    "sTbcMain"
        Me.btnProcessTrxTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(134, 21)
        Me.btnProcessTrxTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabIndex = 6
        Me.btnProcessTrxTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = "&Process Transaction"
        Me.ToolTip1.SetToolTip(Me.btnProcessTrxTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain, "Process Transaction")
        Me.btnProcessTrxTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.UseVisualStyleBackColor = True
        '
        'txtTrxIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain
        '
        Me.txtTrxIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(89, 101)
        Me.txtTrxIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTrxIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Name = "txtTrxIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcM" &
    "ain"
        Me.txtTrxIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(68, 20)
        Me.txtTrxIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabIndex = 1
        '
        'Label104
        '
        Me.Label104.AutoSize = True
        Me.Label104.Location = New System.Drawing.Point(17, 102)
        Me.Label104.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label104.Name = "Label104"
        Me.Label104.Size = New System.Drawing.Size(39, 13)
        Me.Label104.TabIndex = 2
        Me.Label104.Text = "Trx ID:"
        '
        'grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain
        '
        Me.grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.radChargePurchaseGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain)
        Me.grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.radUseDCGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain)
        Me.grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.radMakeWDGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain)
        Me.grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.radMakeDepositGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain)
        Me.grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(17, 10)
        Me.grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Name = "grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain"
        Me.grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Padding = New System.Windows.Forms.Padding(2)
        Me.grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(477, 45)
        Me.grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabIndex = 0
        Me.grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabStop = False
        Me.grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = "Type"
        '
        'radChargePurchaseGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain
        '
        Me.radChargePurchaseGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.AutoSize = True
        Me.radChargePurchaseGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(359, 16)
        Me.radChargePurchaseGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.radChargePurchaseGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Name = "radChargePurchaseGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTab" &
    "TransactionsTbcMain"
        Me.radChargePurchaseGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(107, 17)
        Me.radChargePurchaseGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabIndex = 3
        Me.radChargePurchaseGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabStop = True
        Me.radChargePurchaseGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = "Charge Purchase"
        Me.radChargePurchaseGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.UseVisualStyleBackColor = True
        '
        'radUseDCGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain
        '
        Me.radUseDCGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.AutoSize = True
        Me.radUseDCGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(245, 16)
        Me.radUseDCGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.radUseDCGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Name = "radUseDCGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransacti" &
    "onsTbcMain"
        Me.radUseDCGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(97, 17)
        Me.radUseDCGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabIndex = 2
        Me.radUseDCGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabStop = True
        Me.radUseDCGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = "Use Debit Card"
        Me.radUseDCGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.UseVisualStyleBackColor = True
        '
        'radMakeWDGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain
        '
        Me.radMakeWDGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.AutoSize = True
        Me.radMakeWDGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(123, 16)
        Me.radMakeWDGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.radMakeWDGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Name = "radMakeWDGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransact" &
    "ionsTbcMain"
        Me.radMakeWDGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(108, 17)
        Me.radMakeWDGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabIndex = 1
        Me.radMakeWDGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabStop = True
        Me.radMakeWDGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = "Make Withdrawal"
        Me.radMakeWDGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.UseVisualStyleBackColor = True
        '
        'radMakeDepositGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain
        '
        Me.radMakeDepositGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.AutoSize = True
        Me.radMakeDepositGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Checked = True
        Me.radMakeDepositGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(17, 16)
        Me.radMakeDepositGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.radMakeDepositGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Name = "radMakeDepositGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTra" &
    "nsactionsTbcMain"
        Me.radMakeDepositGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(91, 17)
        Me.radMakeDepositGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabIndex = 0
        Me.radMakeDepositGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.TabStop = True
        Me.radMakeDepositGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.Text = "Make Deposit"
        Me.radMakeDepositGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.UseVisualStyleBackColor = True
        '
        'tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain
        '
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.txtToTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.txtFromTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label34)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label35)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label28)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.dtpTrxDateTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label32)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label64)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label65)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.nudTrxLineAmountTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label67)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.txtToStringTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label68)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.btnProcessTransactionTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.txtTrxIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label69)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(4, 22)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Name = "tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain"
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(1207, 318)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.TabIndex = 3
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = "Make Payment & Transfer Funds"
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.UseVisualStyleBackColor = True
        '
        'txtToTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain
        '
        Me.txtToTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(303, 159)
        Me.txtToTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtToTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Name = "txtToTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain"
        Me.txtToTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(68, 20)
        Me.txtToTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.TabIndex = 5
        '
        'txtFromTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain
        '
        Me.txtFromTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(303, 131)
        Me.txtFromTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtFromTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Name = "txtFromTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain"
        Me.txtFromTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(68, 20)
        Me.txtFromTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.TabIndex = 4
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(224, 159)
        Me.Label34.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(75, 13)
        Me.Label34.TabIndex = 19
        Me.Label34.Text = "To TrxLine ID:"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(214, 132)
        Me.Label35.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(85, 13)
        Me.Label35.TabIndex = 18
        Me.Label35.Text = "From TrxLine ID:"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(17, 239)
        Me.Label28.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(33, 13)
        Me.Label28.TabIndex = 13
        Me.Label28.Text = "Date:"
        '
        'dtpTrxDateTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain
        '
        Me.dtpTrxDateTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(110, 233)
        Me.dtpTrxDateTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpTrxDateTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Name = "dtpTrxDateTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain"
        Me.dtpTrxDateTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(201, 20)
        Me.dtpTrxDateTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.TabIndex = 7
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(17, 157)
        Me.Label32.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(80, 13)
        Me.Label32.TabIndex = 7
        Me.Label32.Text = "To Account ID:"
        '
        'grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain
        '
        Me.grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.radTransferFundsGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain)
        Me.grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.radMakePaymentGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain)
        Me.grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(17, 10)
        Me.grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Name = "grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain"
        Me.grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Padding = New System.Windows.Forms.Padding(2)
        Me.grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(287, 45)
        Me.grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.TabIndex = 0
        Me.grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.TabStop = False
        Me.grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = "Type"
        '
        'radTransferFundsGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain
        '
        Me.radTransferFundsGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.AutoSize = True
        Me.radTransferFundsGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(123, 16)
        Me.radTransferFundsGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.radTransferFundsGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Name = "radTransferFundsGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsT" &
    "bcMain"
        Me.radTransferFundsGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(96, 17)
        Me.radTransferFundsGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.TabIndex = 1
        Me.radTransferFundsGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.TabStop = True
        Me.radTransferFundsGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = "Transfer Funds"
        Me.radTransferFundsGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.UseVisualStyleBackColor = True
        '
        'radMakePaymentGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain
        '
        Me.radMakePaymentGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.AutoSize = True
        Me.radMakePaymentGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Checked = True
        Me.radMakePaymentGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(17, 16)
        Me.radMakePaymentGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.radMakePaymentGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Name = "radMakePaymentGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbc" &
    "Main"
        Me.radMakePaymentGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(96, 17)
        Me.radMakePaymentGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.TabIndex = 0
        Me.radMakePaymentGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.TabStop = True
        Me.radMakePaymentGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = "Make Payment"
        Me.radMakePaymentGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.UseVisualStyleBackColor = True
        '
        'cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain
        '
        Me.cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.FormattingEnabled = True
        Me.cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(110, 156)
        Me.cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Name = "cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain"
        Me.cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(82, 21)
        Me.cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.TabIndex = 3
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(17, 131)
        Me.Label64.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(90, 13)
        Me.Label64.TabIndex = 5
        Me.Label64.Text = "From Account ID:"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(17, 191)
        Me.Label65.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(46, 13)
        Me.Label65.TabIndex = 11
        Me.Label65.Text = "Amount:"
        '
        'cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain
        '
        Me.cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.FormattingEnabled = True
        Me.cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(110, 77)
        Me.cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Name = "cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain"
        Me.cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(82, 21)
        Me.cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.TabIndex = 0
        '
        'nudTrxLineAmountTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain
        '
        Me.nudTrxLineAmountTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.DecimalPlaces = 2
        Me.nudTrxLineAmountTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(110, 191)
        Me.nudTrxLineAmountTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.nudTrxLineAmountTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Name = "nudTrxLineAmountTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain"
        Me.nudTrxLineAmountTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(67, 20)
        Me.nudTrxLineAmountTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.TabIndex = 6
        Me.nudTrxLineAmountTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(17, 79)
        Me.Label67.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(68, 13)
        Me.Label67.TabIndex = 1
        Me.Label67.Text = "Customer ID:"
        '
        'txtToStringTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain
        '
        Me.txtToStringTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(412, 91)
        Me.txtToStringTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtToStringTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Multiline = True
        Me.txtToStringTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Name = "txtToStringTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain"
        Me.txtToStringTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.ReadOnly = True
        Me.txtToStringTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtToStringTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(374, 161)
        Me.txtToStringTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.TabIndex = 16
        '
        'cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain
        '
        Me.cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.FormattingEnabled = True
        Me.cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(110, 129)
        Me.cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Name = "cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain"
        Me.cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(82, 21)
        Me.cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.TabIndex = 2
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Location = New System.Drawing.Point(409, 76)
        Me.Label68.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(105, 13)
        Me.Label68.TabIndex = 15
        Me.Label68.Text = "ToString Information:"
        '
        'btnProcessTransactionTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain
        '
        Me.btnProcessTransactionTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(95, 284)
        Me.btnProcessTransactionTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.btnProcessTransactionTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Name = "btnProcessTransactionTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbc" &
    "Main"
        Me.btnProcessTransactionTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(134, 21)
        Me.btnProcessTransactionTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.TabIndex = 8
        Me.btnProcessTransactionTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Text = "&Process Transaction"
        Me.ToolTip1.SetToolTip(Me.btnProcessTransactionTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain, "Process Transaction")
        Me.btnProcessTransactionTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.UseVisualStyleBackColor = True
        '
        'txtTrxIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain
        '
        Me.txtTrxIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(110, 104)
        Me.txtTrxIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTrxIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Name = "txtTrxIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain"
        Me.txtTrxIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(68, 20)
        Me.txtTrxIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.TabIndex = 1
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Location = New System.Drawing.Point(17, 105)
        Me.Label69.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(39, 13)
        Me.Label69.TabIndex = 3
        Me.Label69.Text = "Trx ID:"
        '
        'tabAccrueInterestTbcTransactionsTabTransactionsTbcMain
        '
        Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain)
        Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain)
        Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.radSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain)
        Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain)
        Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.txtToStringTabAccrueInterestTbcTransactionsTabTransactionsTbcMain)
        Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label46)
        Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.btnAccrueInterestTabAccrueInterestTbcTransactionsTabTransactionsTbcMain)
        Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(4, 22)
        Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Name = "tabAccrueInterestTbcTransactionsTabTransactionsTbcMain"
        Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(1207, 318)
        Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain.TabIndex = 2
        Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text = "Accrue Interest"
        Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain.UseVisualStyleBackColor = True
        '
        'grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain
        '
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label29)
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.txtTrxIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain)
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label30)
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.txtTrxIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain)
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label57)
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.txtTrxLineIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain)
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label42)
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.txtTrxLineIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain)
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(19, 36)
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Name = "grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain"
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Padding = New System.Windows.Forms.Padding(2)
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(339, 72)
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.TabIndex = 1
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.TabStop = False
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text = "All Accounts"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(3, 45)
        Me.Label29.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(71, 13)
        Me.Label29.TabIndex = 6
        Me.Label29.Text = "Trx ID# Start:"
        '
        'txtTrxIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain
        '
        Me.txtTrxIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(85, 42)
        Me.txtTrxIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTrxIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Name = "txtTrxIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsT" &
    "bcMain"
        Me.txtTrxIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(68, 20)
        Me.txtTrxIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.TabIndex = 2
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(4, 23)
        Me.Label30.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(68, 13)
        Me.Label30.TabIndex = 4
        Me.Label30.Text = "Trx ID Prefix:"
        '
        'txtTrxIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain
        '
        Me.txtTrxIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(85, 20)
        Me.txtTrxIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTrxIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Name = "txtTrxIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMai" &
    "n"
        Me.txtTrxIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(68, 20)
        Me.txtTrxIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.TabIndex = 0
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(172, 45)
        Me.Label57.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(91, 13)
        Me.Label57.TabIndex = 2
        Me.Label57.Text = "TrxLine ID# Start:"
        '
        'txtTrxLineIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain
        '
        Me.txtTrxLineIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(267, 42)
        Me.txtTrxLineIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTrxLineIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Name = "txtTrxLineIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransacti" &
    "onsTbcMain"
        Me.txtTrxLineIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(68, 20)
        Me.txtTrxLineIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.TabIndex = 3
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(175, 23)
        Me.Label42.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(88, 13)
        Me.Label42.TabIndex = 0
        Me.Label42.Text = "TrxLine ID Prefix:"
        '
        'txtTrxLineIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain
        '
        Me.txtTrxLineIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(267, 20)
        Me.txtTrxLineIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTrxLineIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Name = "txtTrxLineIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTb" &
    "cMain"
        Me.txtTrxLineIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(68, 20)
        Me.txtTrxLineIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.TabIndex = 1
        '
        'grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain
        '
        Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.txtTrxIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain)
        Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label33)
        Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.txtTrxLineIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain)
        Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label41)
        Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.Label44)
        Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Controls.Add(Me.cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain)
        Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(19, 144)
        Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Name = "grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain"
        Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Padding = New System.Windows.Forms.Padding(2)
        Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(339, 80)
        Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.TabIndex = 3
        Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.TabStop = False
        Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text = "Specific Account"
        '
        'txtTrxIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain
        '
        Me.txtTrxIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(83, 54)
        Me.txtTrxIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTrxIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Name = "txtTrxIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain"
        Me.txtTrxIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(82, 20)
        Me.txtTrxIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.TabIndex = 1
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(16, 57)
        Me.Label33.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(39, 13)
        Me.Label33.TabIndex = 4
        Me.Label33.Text = "Trx ID:"
        '
        'txtTrxLineIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain
        '
        Me.txtTrxLineIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(267, 53)
        Me.txtTrxLineIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTrxLineIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Name = "txtTrxLineIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcM" &
    "ain"
        Me.txtTrxLineIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(68, 20)
        Me.txtTrxLineIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.TabIndex = 2
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(16, 27)
        Me.Label41.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(64, 13)
        Me.Label41.TabIndex = 0
        Me.Label41.Text = "Account ID:"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(195, 57)
        Me.Label44.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(59, 13)
        Me.Label44.TabIndex = 2
        Me.Label44.Text = "TrxLine ID:"
        '
        'cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain
        '
        Me.cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.FormattingEnabled = True
        Me.cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(83, 25)
        Me.cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Name = "cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcM" &
    "ain"
        Me.cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(82, 21)
        Me.cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.TabIndex = 0
        '
        'radSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain
        '
        Me.radSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.AutoSize = True
        Me.radSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(19, 124)
        Me.radSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.radSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Name = "radSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain"
        Me.radSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(106, 17)
        Me.radSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.TabIndex = 1
        Me.radSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.TabStop = True
        Me.radSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text = "Specific Account"
        Me.radSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.UseVisualStyleBackColor = True
        '
        'radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain
        '
        Me.radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.AutoSize = True
        Me.radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Checked = True
        Me.radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(19, 16)
        Me.radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Name = "radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain"
        Me.radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(84, 17)
        Me.radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.TabIndex = 0
        Me.radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.TabStop = True
        Me.radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text = "All Accounts"
        Me.radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.UseVisualStyleBackColor = True
        '
        'txtToStringTabAccrueInterestTbcTransactionsTabTransactionsTbcMain
        '
        Me.txtToStringTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(393, 32)
        Me.txtToStringTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtToStringTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Multiline = True
        Me.txtToStringTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Name = "txtToStringTabAccrueInterestTbcTransactionsTabTransactionsTbcMain"
        Me.txtToStringTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.ReadOnly = True
        Me.txtToStringTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtToStringTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(408, 257)
        Me.txtToStringTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.TabIndex = 5
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(388, 16)
        Me.Label46.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(105, 13)
        Me.Label46.TabIndex = 4
        Me.Label46.Text = "ToString Information:"
        '
        'btnAccrueInterestTabAccrueInterestTbcTransactionsTabTransactionsTbcMain
        '
        Me.btnAccrueInterestTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Location = New System.Drawing.Point(19, 260)
        Me.btnAccrueInterestTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.btnAccrueInterestTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Name = "btnAccrueInterestTabAccrueInterestTbcTransactionsTabTransactionsTbcMain"
        Me.btnAccrueInterestTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Size = New System.Drawing.Size(184, 27)
        Me.btnAccrueInterestTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.TabIndex = 2
        Me.btnAccrueInterestTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.Text = "&Accrue Interest"
        Me.ToolTip1.SetToolTip(Me.btnAccrueInterestTabAccrueInterestTbcTransactionsTabTransactionsTbcMain, "Accrue Interest")
        Me.btnAccrueInterestTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.UseVisualStyleBackColor = True
        '
        'tabReportsTbcMain
        '
        Me.tabReportsTbcMain.Controls.Add(Me.TextBox4)
        Me.tabReportsTbcMain.Location = New System.Drawing.Point(4, 22)
        Me.tabReportsTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.tabReportsTbcMain.Name = "tabReportsTbcMain"
        Me.tabReportsTbcMain.Size = New System.Drawing.Size(1160, 343)
        Me.tabReportsTbcMain.TabIndex = 4
        Me.tabReportsTbcMain.Text = "Reports"
        Me.tabReportsTbcMain.UseVisualStyleBackColor = True
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(502, 165)
        Me.TextBox4.Margin = New System.Windows.Forms.Padding(2)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(211, 20)
        Me.TextBox4.TabIndex = 0
        Me.TextBox4.Text = "#### No reports configured at this time..."
        '
        'tabFilesTbcMain
        '
        Me.tabFilesTbcMain.Controls.Add(Me.btnDisplayBankTabFilesTbcMain)
        Me.tabFilesTbcMain.Controls.Add(Me.txtFileNameTabFilesTbcMain)
        Me.tabFilesTbcMain.Controls.Add(Me.Label59)
        Me.tabFilesTbcMain.Controls.Add(Me.btnProcessTestDataTabFilesTbcMain)
        Me.tabFilesTbcMain.Controls.Add(Me.btnResetAllTabFilesTbcMain)
        Me.tabFilesTbcMain.Controls.Add(Me.btnSaveTabFilesTbcMain)
        Me.tabFilesTbcMain.Controls.Add(Me.btnOpenTabFilesTbcMain)
        Me.tabFilesTbcMain.Location = New System.Drawing.Point(4, 22)
        Me.tabFilesTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.tabFilesTbcMain.Name = "tabFilesTbcMain"
        Me.tabFilesTbcMain.Size = New System.Drawing.Size(1160, 343)
        Me.tabFilesTbcMain.TabIndex = 5
        Me.tabFilesTbcMain.Text = "Files"
        Me.tabFilesTbcMain.UseVisualStyleBackColor = True
        '
        'btnDisplayBankTabFilesTbcMain
        '
        Me.btnDisplayBankTabFilesTbcMain.Location = New System.Drawing.Point(630, 121)
        Me.btnDisplayBankTabFilesTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.btnDisplayBankTabFilesTbcMain.Name = "btnDisplayBankTabFilesTbcMain"
        Me.btnDisplayBankTabFilesTbcMain.Size = New System.Drawing.Size(159, 21)
        Me.btnDisplayBankTabFilesTbcMain.TabIndex = 6
        Me.btnDisplayBankTabFilesTbcMain.Text = "&Display Bank"
        Me.ToolTip1.SetToolTip(Me.btnDisplayBankTabFilesTbcMain, "display band to string")
        Me.btnDisplayBankTabFilesTbcMain.UseVisualStyleBackColor = True
        '
        'txtFileNameTabFilesTbcMain
        '
        Me.txtFileNameTabFilesTbcMain.Location = New System.Drawing.Point(348, 167)
        Me.txtFileNameTabFilesTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.txtFileNameTabFilesTbcMain.Name = "txtFileNameTabFilesTbcMain"
        Me.txtFileNameTabFilesTbcMain.Size = New System.Drawing.Size(201, 20)
        Me.txtFileNameTabFilesTbcMain.TabIndex = 2
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(293, 169)
        Me.Label59.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(52, 13)
        Me.Label59.TabIndex = 1
        Me.Label59.Text = "Filename:"
        '
        'btnProcessTestDataTabFilesTbcMain
        '
        Me.btnProcessTestDataTabFilesTbcMain.Location = New System.Drawing.Point(429, 121)
        Me.btnProcessTestDataTabFilesTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.btnProcessTestDataTabFilesTbcMain.Name = "btnProcessTestDataTabFilesTbcMain"
        Me.btnProcessTestDataTabFilesTbcMain.Size = New System.Drawing.Size(159, 21)
        Me.btnProcessTestDataTabFilesTbcMain.TabIndex = 0
        Me.btnProcessTestDataTabFilesTbcMain.Text = "&Process Test Data"
        Me.ToolTip1.SetToolTip(Me.btnProcessTestDataTabFilesTbcMain, "process test data")
        Me.btnProcessTestDataTabFilesTbcMain.UseVisualStyleBackColor = True
        '
        'btnResetAllTabFilesTbcMain
        '
        Me.btnResetAllTabFilesTbcMain.Location = New System.Drawing.Point(527, 209)
        Me.btnResetAllTabFilesTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.btnResetAllTabFilesTbcMain.Name = "btnResetAllTabFilesTbcMain"
        Me.btnResetAllTabFilesTbcMain.Size = New System.Drawing.Size(159, 21)
        Me.btnResetAllTabFilesTbcMain.TabIndex = 5
        Me.btnResetAllTabFilesTbcMain.Text = "&Reset All"
        Me.tipMain.SetToolTip(Me.btnResetAllTabFilesTbcMain, "WARNING: started.")
        Me.btnResetAllTabFilesTbcMain.UseVisualStyleBackColor = True
        '
        'btnSaveTabFilesTbcMain
        '
        Me.btnSaveTabFilesTbcMain.Location = New System.Drawing.Point(761, 163)
        Me.btnSaveTabFilesTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.btnSaveTabFilesTbcMain.Name = "btnSaveTabFilesTbcMain"
        Me.btnSaveTabFilesTbcMain.Size = New System.Drawing.Size(159, 21)
        Me.btnSaveTabFilesTbcMain.TabIndex = 4
        Me.btnSaveTabFilesTbcMain.Text = "&Save (Write Trx To) File"
        Me.ToolTip1.SetToolTip(Me.btnSaveTabFilesTbcMain, "it saves the file")
        Me.btnSaveTabFilesTbcMain.UseVisualStyleBackColor = True
        '
        'btnOpenTabFilesTbcMain
        '
        Me.btnOpenTabFilesTbcMain.Location = New System.Drawing.Point(591, 163)
        Me.btnOpenTabFilesTbcMain.Margin = New System.Windows.Forms.Padding(2)
        Me.btnOpenTabFilesTbcMain.Name = "btnOpenTabFilesTbcMain"
        Me.btnOpenTabFilesTbcMain.Size = New System.Drawing.Size(159, 21)
        Me.btnOpenTabFilesTbcMain.TabIndex = 3
        Me.btnOpenTabFilesTbcMain.Text = "&Open (Read Trx From) File"
        Me.ToolTip1.SetToolTip(Me.btnOpenTabFilesTbcMain, "opens files to read")
        Me.btnOpenTabFilesTbcMain.UseVisualStyleBackColor = True
        '
        'dlgFileOpen
        '
        Me.dlgFileOpen.FileName = "OpenFileDialog1"
        '
        'FrmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1223, 666)
        Me.Controls.Add(Me.tbcMain)
        Me.Controls.Add(Me.txtTrxLog)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.mnuMain)
        Me.MainMenuStrip = Me.mnuMain
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.MaximumSize = New System.Drawing.Size(1285, 716)
        Me.Name = "FrmMain"
        Me.Text = "FrmMain"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.mnuMain.ResumeLayout(False)
        Me.mnuMain.PerformLayout()
        Me.tbcMain.ResumeLayout(False)
        Me.tabSummaryTbcMain.ResumeLayout(False)
        Me.tabSummaryTbcMain.PerformLayout()
        Me.grpMetricsTabSummaryTbcMain.ResumeLayout(False)
        Me.grpMetricsTabSummaryTbcMain.PerformLayout()
        Me.tbcCustomerTbcMain.ResumeLayout(False)
        Me.tbcCustomerTbcMain.PerformLayout()
        Me.grpCreateTabCustomerTbcMain.ResumeLayout(False)
        Me.grpCreateTabCustomerTbcMain.PerformLayout()
        Me.tabAccountTbcMain.ResumeLayout(False)
        Me.tabAccountTbcMain.PerformLayout()
        Me.grpClosedTabAccountTbcMain.ResumeLayout(False)
        Me.grpClosedTabAccountTbcMain.PerformLayout()
        Me.grpCreateModifyTabAccountTbcMain.ResumeLayout(False)
        Me.grpCreateModifyTabAccountTbcMain.PerformLayout()
        CType(Me.nudAPRGrpCreateModifyTabAccountTbcMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpTypeGrpCreateModifyTabAccountTbcMain.ResumeLayout(False)
        Me.grpTypeGrpCreateModifyTabAccountTbcMain.PerformLayout()
        Me.tabTransactionsTbcMain.ResumeLayout(False)
        Me.tbcTransactionsTabTransactionsTbcMain.ResumeLayout(False)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.ResumeLayout(False)
        Me.tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.PerformLayout()
        CType(Me.nudAmountTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.ResumeLayout(False)
        Me.grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain.PerformLayout()
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.ResumeLayout(False)
        Me.tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.PerformLayout()
        Me.grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.ResumeLayout(False)
        Me.grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain.PerformLayout()
        CType(Me.nudTrxLineAmountTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain.ResumeLayout(False)
        Me.tabAccrueInterestTbcTransactionsTabTransactionsTbcMain.PerformLayout()
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.ResumeLayout(False)
        Me.grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.PerformLayout()
        Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.ResumeLayout(False)
        Me.grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain.PerformLayout()
        Me.tabReportsTbcMain.ResumeLayout(False)
        Me.tabReportsTbcMain.PerformLayout()
        Me.tabFilesTbcMain.ResumeLayout(False)
        Me.tabFilesTbcMain.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents mnuMain As MenuStrip
    Friend WithEvents mniFileMnuMain As ToolStripMenuItem
    Friend WithEvents mniExitMniFileMnuMain As ToolStripMenuItem
    Friend WithEvents mniHelpMnuMain As ToolStripMenuItem
    Friend WithEvents mniAboutMniHelpMnuMain As ToolStripMenuItem
    Friend WithEvents Label1 As Label
    Friend WithEvents txtTrxLog As TextBox
    Friend WithEvents tbcMain As TabControl
    Friend WithEvents tabSummaryTbcMain As TabPage
    Friend WithEvents lstTrxLineIDTabSummaryTbcMain As ListBox
    Friend WithEvents Label5 As Label
    Friend WithEvents lstTrxIDTabSummaryTbcMain As ListBox
    Friend WithEvents Label4 As Label
    Friend WithEvents lstAccountIDTabSummaryTbcMain As ListBox
    Friend WithEvents Label3 As Label
    Friend WithEvents lstCustomerIDTabSummaryTbcMain As ListBox
    Friend WithEvents Label2 As Label
    Friend WithEvents tbcCustomerTbcMain As TabPage
    Friend WithEvents tabAccountTbcMain As TabPage
    Friend WithEvents tabTransactionsTbcMain As TabPage
    Friend WithEvents tabReportsTbcMain As TabPage
    Friend WithEvents lblCountTrxLineTabSummaryTbcMain As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents lblCountTrxTabSummaryTbcMain As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents lblCountAccountTabSummaryTbcMain As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents lblCountCustomerTabCustomerTbcMain As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents grpMetricsTabSummaryTbcMain As GroupBox
    Friend WithEvents txtToStringInfoTabSummaryTbcMain As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents txtMetricsGrpMetricsTabSummaryTbcMain As TextBox
    Friend WithEvents tabFilesTbcMain As TabPage
    Friend WithEvents txtToStringInfoTabCustomerTbcMain As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents dtpBirthdateGrpCreateTabCustomerTbcMain As DateTimePicker
    Friend WithEvents txtNameGrpCreateTabCustomerTbcMain As TextBox
    Friend WithEvents btnCreateCustomerGrpCreateTabCustomerTbcMain As Button
    Friend WithEvents Label13 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents lblCountTrxTabCustomerTbcMain As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents lstTrxIDTabCustomerTbcMain As ListBox
    Friend WithEvents Label15 As Label
    Friend WithEvents cboCustomerIDTabCustomerTbcMain As ComboBox
    Friend WithEvents grpCreateTabCustomerTbcMain As GroupBox
    Friend WithEvents grpCreateModifyTabAccountTbcMain As GroupBox
    Friend WithEvents btnAddAccountOwnerGrpCreateModifyTabAccountTbcMain As Button
    Friend WithEvents cboCustomerIDGrpCreateModifyTabAccountTbcMain As ComboBox
    Friend WithEvents Label24 As Label
    Friend WithEvents btnCreateAccountTabAccountTbcMain As Button
    Friend WithEvents txtNameGrpCreateModifyTabAccountTbcMain As TextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents dtpDateOpenedGrpCreateModifyTabAccountTbcMain As DateTimePicker
    Friend WithEvents cboAccountIDTabAccountTbcMain As ComboBox
    Friend WithEvents lblCountTrxLinesTabAccountTbcMain As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents lstTrxLineIDTabAccountTbcMain As ListBox
    Friend WithEvents Label21 As Label
    Friend WithEvents txtToStringInfoTabAccountTbcMain As TextBox
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents lblCountOwnersTabAccountTbcMain As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents lstCustomerIDTabAccountTbcMain As ListBox
    Friend WithEvents Label27 As Label
    Friend WithEvents tbcTransactionsTabTransactionsTbcMain As TabControl
    Friend WithEvents tabAccrueInterestTbcTransactionsTabTransactionsTbcMain As TabPage
    Friend WithEvents tabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain As TabPage
    Friend WithEvents mniOpenMniFileMnuMain As ToolStripMenuItem
    Friend WithEvents mniSaveMniFileMnuMain As ToolStripMenuItem
    Friend WithEvents mniResetAllMniFileMnuMain As ToolStripMenuItem
    Friend WithEvents btnResetAllTabFilesTbcMain As Button
    Friend WithEvents btnSaveTabFilesTbcMain As Button
    Friend WithEvents btnOpenTabFilesTbcMain As Button
    Friend WithEvents tipMain As ToolTip
    Friend WithEvents mniProcessTestDataMniFileMnuMain As ToolStripMenuItem
    Friend WithEvents btnProcessTestDataTabFilesTbcMain As Button
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Label64 As Label
    Friend WithEvents Label65 As Label
    Friend WithEvents nudTrxLineAmountTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain As NumericUpDown
    Friend WithEvents cboFromAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain As ComboBox
    Friend WithEvents cboCustomerIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain As ComboBox
    Friend WithEvents Label67 As Label
    Friend WithEvents txtToStringTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain As TextBox
    Friend WithEvents Label68 As Label
    Friend WithEvents btnProcessTransactionTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain As Button
    Friend WithEvents txtTrxIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain As TextBox
    Friend WithEvents Label69 As Label
    Friend WithEvents grpTypeGrpCreateModifyTabAccountTbcMain As GroupBox
    Friend WithEvents radCreditCardGrpTypeGrpCreateModifyTabAccountTbcMain As RadioButton
    Friend WithEvents radLoanGrpTypeGrpCreateModifyTabAccountTbcMain As RadioButton
    Friend WithEvents radCheckingGrpTypeGrpCreateModifyTabAccountTbcMain As RadioButton
    Friend WithEvents txtAmountGrpCreateModifyTabAccountTbcMain As TextBox
    Friend WithEvents Label94 As Label
    Friend WithEvents grpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain As GroupBox
    Friend WithEvents Label57 As Label
    Friend WithEvents txtTrxLineIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain As TextBox
    Friend WithEvents Label42 As Label
    Friend WithEvents txtTrxLineIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain As TextBox
    Friend WithEvents grpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain As GroupBox
    Friend WithEvents txtTrxLineIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain As TextBox
    Friend WithEvents Label41 As Label
    Friend WithEvents Label44 As Label
    Friend WithEvents cboAccountIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain As ComboBox
    Friend WithEvents radSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain As RadioButton
    Friend WithEvents radAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain As RadioButton
    Friend WithEvents txtToStringTabAccrueInterestTbcTransactionsTabTransactionsTbcMain As TextBox
    Friend WithEvents Label46 As Label
    Friend WithEvents btnAccrueInterestTabAccrueInterestTbcTransactionsTabTransactionsTbcMain As Button
    Friend WithEvents txtFileNameTabFilesTbcMain As TextBox
    Friend WithEvents Label59 As Label
    Friend WithEvents dlgFileOpen As OpenFileDialog
    Friend WithEvents btnModifyAccountTabAccountTbcMain As Button
    Friend WithEvents Label97 As Label
    Friend WithEvents Label95 As Label
    Friend WithEvents grpClosedTabAccountTbcMain As GroupBox
    Friend WithEvents dtpClosedDateGrpClosedTabAccountTbcMain As DateTimePicker
    Friend WithEvents chkClosedGrpClosedTabAccountTbcMain As CheckBox
    Friend WithEvents Label73 As Label
    Friend WithEvents nudAPRGrpCreateModifyTabAccountTbcMain As NumericUpDown
    Friend WithEvents Label71 As Label
    Friend WithEvents dtpNextInterestAccrualDateGrpCreateModifyTabAccountTbcMain As DateTimePicker
    Friend WithEvents lstNewOwnerIDGrpCreateModifyTabAccountTbcMain As ListBox
    Friend WithEvents Label96 As Label
    Friend WithEvents tabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain As TabPage
    Friend WithEvents grpTypeMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain As GroupBox
    Friend WithEvents txtTrxLineIDGrpCreateModifyTabAccountTbcMain As TextBox
    Friend WithEvents Label31 As Label
    Friend WithEvents Label99 As Label
    Friend WithEvents Label100 As Label
    Friend WithEvents nudAmountTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain As NumericUpDown
    Friend WithEvents txtTrxLineIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain As TextBox
    Friend WithEvents cboAccountIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain As ComboBox
    Friend WithEvents Label101 As Label
    Friend WithEvents cboCustomerIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain As ComboBox
    Friend WithEvents Label102 As Label
    Friend WithEvents txtToStringTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain As TextBox
    Friend WithEvents Label103 As Label
    Friend WithEvents btnProcessTrxTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain As Button
    Friend WithEvents txtTrxIDTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain As TextBox
    Friend WithEvents Label104 As Label
    Friend WithEvents radChargePurchaseGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain As RadioButton
    Friend WithEvents radUseDCGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain As RadioButton
    Friend WithEvents radMakeWDGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain As RadioButton
    Friend WithEvents radMakeDepositGrpTypeTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain As RadioButton
    Friend WithEvents Label32 As Label
    Friend WithEvents cboToAccountIDTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain As ComboBox
    Friend WithEvents grpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain As GroupBox
    Friend WithEvents radTransferFundsGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain As RadioButton
    Friend WithEvents radMakePaymentGrpTypeTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain As RadioButton
    Friend WithEvents txtTrxIDGrpCreateModifyTabAccountTbcMain As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents dtpTrxDateTabMakeDepositMakeWDUseDCChargePurchaseTbcTransactionsTabTransactionsTbcMain As DateTimePicker
    Friend WithEvents Label28 As Label
    Friend WithEvents dtpTrxDateTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain As DateTimePicker
    Friend WithEvents Label29 As Label
    Friend WithEvents txtTrxIDStartNumberGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain As TextBox
    Friend WithEvents Label30 As Label
    Friend WithEvents txtTrxIDPrefixGrpAllAccountsTabAccrueInterestTbcTransactionsTabTransactionsTbcMain As TextBox
    Friend WithEvents txtTrxIDGrpSpecificAccountTabAccrueInterestTbcTransactionsTabTransactionsTbcMain As TextBox
    Friend WithEvents Label33 As Label
    Friend WithEvents txtToTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain As TextBox
    Friend WithEvents txtFromTrxLineTabMakePaymentTransferFundsTbcTransactionsTabTransactionsTbcMain As TextBox
    Friend WithEvents Label34 As Label
    Friend WithEvents Label35 As Label
    Friend WithEvents btnDisplayBankTabFilesTbcMain As Button
    Friend WithEvents ToolTip1 As ToolTip
End Class
