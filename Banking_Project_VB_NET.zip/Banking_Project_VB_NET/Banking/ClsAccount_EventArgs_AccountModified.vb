﻿'Copyright (c) 2009-2016 Dan Turk

#Region "Class / File Comment Header block"
'Program:                Banking
'File:                   ClsAccount_EventArgs_AccountCreated
'Author:                 shreesh maurya
'Description:            its an event class 
'Date:                   updated: 9 dec 2016
'                        14 nov 2016
'Tier:                   event class
'Exceptions:             none
'Exception-Handling:     none handled
'Events:                 none
'Event-Handling:         none
#End Region 'Class / File Comment Header block

#Region "Option / Imports"
Option Explicit On      'Must declare variables before using them
Option Strict On        'Must perform explicit data type conversions
#End Region 'Option / Imports

Public Class Account_EventArgs_AccountCreated
    Inherits System.EventArgs

#Region "Attributes"
    '******************************************************************
    'Attributes + Module-level Constants+Variables
    '******************************************************************

    '********** Module-level variables

    Private mAccount As Account

#End Region 'Attributes

#Region "Constructors"
    '******************************************************************
    'Constructors
    '******************************************************************

    '********** Special constructor(s)
    '             - typically constructors have parameters 
    '               that are used to initialize attributes

    Public Sub New(
            ByVal pAccount As Account
            )

        'Special constructor - create the EventArgs object.

        MyBase.New()

        _account = pAccount

    End Sub

    '********** Copy constructor(s)
    '             - one parameter, an object of the same class

#End Region 'Constructors

#Region "Get/Set Methods"
    '******************************************************************
    'Get/Set Methods
    '******************************************************************

    '********** Public Get/Set Methods
    '             - call private get/set methods to implement
    Public ReadOnly Property account As Account
        Get
            Return _account
        End Get
    End Property

    'Private Get/Set Methods - access attributes, 
    '                          begin name with underscore (_)

    Private Property _account As Account
        Get
            Return mAccount
        End Get
        Set(pValue As Account)
            mAccount = pValue
        End Set
    End Property





#End Region 'Get/Set Methods

#Region "Behavioral Methods"
    '******************************************************************
    'Behavioral Methods
    '******************************************************************



    '********** Public Non-Shared Behavioral Methods

    Public Overrides Function ToString() As String

        'ToString() is the public interface that
        'provides a String version of the data
        'stored in the class attributes.

        Return _toString()

    End Function 'ToString()

    'Private Non-Shared Behavioral Methods

    Private Function _toString() As String

        '_toString() is the private interface that
        'provides a String version of the data
        'stored in the class attributes.
        '_toString() does the actual work of composing
        'and formatting the string.

        Dim tmpStr As String

        tmpStr =
            "( Account EVENT_ARGS account_ADDED: " _
            & "account=" & _account.ToString _
            & " )"

        Return tmpStr

    End Function '_toString()

#End Region 'Behavioral Methods

#Region "Event Procedures"
    '******************************************************************
    'Event Procedures
    '******************************************************************

    'No Event Procedures are currently defined.
    'These are all private.


#End Region 'Event Procedures

#Region "Events"
    '******************************************************************
    'Events
    '******************************************************************


#End Region 'Events

End Class 'Account_EventArgs_AccountCreated
