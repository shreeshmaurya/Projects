﻿
Imports Team126DB
Imports Team126DBTableAdapters
Partial Class SecureSeeker_applyJob
    Inherits System.Web.UI.Page

    Private Sub SecureSeeker_applyJob_Load(sender As Object, e As EventArgs) Handles Me.Load

        Dim jobid As Long = Request.QueryString("jobid").ToString


        Dim emailid As String = Session("emailid1").ToString
        Dim currDate As Date = Date.Now
        Dim a As String = currDate.ToString("M/d/yyyy")



        Using aAdapter As New tbJobsAppliedTableAdapter

            Dim aTable As tbJobsAppliedDataTable
            aTable = aAdapter.GetJobAppliedByEmailAndJobid(jobid, emailid)

            If aTable.Rows.Count = 0 Then


                aAdapter.applyJobsByIdEmail(jobid, emailid, a)
                Response.Redirect("~/SecureSeeker/seekerJobSearch.aspx")
                Response.Write("<script type=""text/javascript"">alert(""Application Submitted"");</script")

            Else
                Response.Write("<script type=""text/javascript"">alert(""You have already applied for this job!!"");</script")
                Response.Redirect("~/SecureSeeker/seekerJobSearch.aspx")


            End If


        End Using



    End Sub
End Class
