﻿
Partial Class SecureSeeker_AboutUs
    Inherits System.Web.UI.Page

    Private Sub SecureSeeker_AboutUs_Load(sender As Object, e As EventArgs) Handles Me.Load
        If HttpContext.Current.User.Identity.IsAuthenticated Then

            Label1.Text = String.Format("Welcome Back {0}", HttpContext.Current.User.Identity.Name)

        End If
    End Sub
End Class
