﻿
Partial Class SecureSeeker_viewJobsApplied
    Inherits System.Web.UI.Page

    Private Sub SecureSeeker_viewJobsApplied_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim emailid As String = Session("emailid1")
        TextBox1.Text = emailid

        If HttpContext.Current.User.Identity.IsAuthenticated Then

            Label1.Text = String.Format("Welcome Back {0}", HttpContext.Current.User.Identity.Name)

        End If

    End Sub
End Class
