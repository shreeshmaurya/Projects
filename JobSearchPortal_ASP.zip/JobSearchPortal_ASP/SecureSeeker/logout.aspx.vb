﻿Option Strict On
Partial Class SecureSeeker_logout
    Inherits System.Web.UI.Page

    Private Sub SecureSeeker_logout_Load(sender As Object, e As EventArgs) Handles Me.Load


        FormsAuthentication.SignOut()
        Response.Clear()
        Session.RemoveAll()
        Response.Redirect("~/index.aspx")

    End Sub
End Class
