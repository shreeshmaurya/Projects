﻿Option Strict On

Partial Class SecureRecruiter_jobPost
    Inherits System.Web.UI.Page

    'Private Sub DetailsView1_ItemCreated(sender As Object, e As EventArgs) Handles DetailsView1.ItemCreated


    '    Response.Write("<script type=""text/javascript"">alert(""The file is already closed"");</script")

    '    Dim lb As Label

    '    Dim email As String
    '    email = CType(System.Web.HttpContext.Current.Session("emailid"), String)

    '    lb = CType(DetailsView1.FindControl("Label8"), Label)
    '    lb.Text = email


    'End Sub





    Private Sub SecureRecruiter_jobPost_Load(sender As Object, e As EventArgs) Handles Me.Load, DetailsView1.Load, DetailsView1.ItemInserted, form2.Load, DetailsView1.ItemCreated

        Dim lb As Label

        Dim email As String
        email = CType(System.Web.HttpContext.Current.Session("emailid"), String)

        lb = CType(DetailsView1.FindControl("Label8"), Label)
        lb.Text = email



        If HttpContext.Current.User.Identity.IsAuthenticated Then

            Label1.Text = String.Format("Welcome Back {0}", HttpContext.Current.User.Identity.Name)

        End If


    End Sub



    'Private Sub DetailsView1_DataBound(sender As Object, e As EventArgs) Handles DetailsView1.DataBound

    '    Dim email As String = CType(Session.Item("emailid"), String)
    '    Dim email As String
    '    email = CType(System.Web.HttpContext.Current.Session("emailid"), String)




    '    If DetailsView1.CurrentMode = DetailsViewMode.Insert Then
    '        Dim txtOriginalRegistrationFee As TextBox
    '        txtOriginalRegistrationFee = CType(FindControl("TextBox5"), TextBox)

    '        txtOriginalRegistrationFee.Text = email.ToString()

    '    End If

    'End Sub
End Class
