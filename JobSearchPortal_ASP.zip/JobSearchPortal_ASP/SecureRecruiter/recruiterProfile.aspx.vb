﻿
Partial Class SecureRecruiter_recruiterProfile
    Inherits System.Web.UI.Page

    Private Sub DetailsView1_ItemUpdated(sender As Object, e As DetailsViewUpdatedEventArgs) Handles DetailsView1.ItemUpdated


        Response.Redirect("~/SecureRecruiter/recruiterJobPost.aspx")

    End Sub

    Private Sub SecureRecruiter_recruiterProfile_Load(sender As Object, e As EventArgs) Handles Me.Load

        If HttpContext.Current.User.Identity.IsAuthenticated Then

            Label1.Text = String.Format("Welcome Back {0}", HttpContext.Current.User.Identity.Name)

        End If


    End Sub

End Class
