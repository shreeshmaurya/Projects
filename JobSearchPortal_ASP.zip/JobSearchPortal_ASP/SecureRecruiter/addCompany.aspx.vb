﻿Option Strict On
Partial Class SecureRecruiter_addCompany
    Inherits System.Web.UI.Page

    Private Sub DetailsView1_ItemCreated(sender As Object, e As EventArgs) Handles DetailsView1.ItemInserted


        Dim lb As Label

        Dim email As String
        email = CType(System.Web.HttpContext.Current.Session("emailid"), String)

        lb = CType(DetailsView1.FindControl("Label5"), Label)
        lb.Text = email






        Response.Write("<script type=""text/javascript"">alert(""Company Created"");</script")

    End Sub

    Private Sub SecureRecruiter_recruiterJobPost_Load(sender As Object, e As EventArgs) Handles Me.Load, form2.Load, DetailsView1.ItemCreated



        Dim lb As Label

        Dim email As String
        email = CType(System.Web.HttpContext.Current.Session("emailid"), String)

        lb = CType(DetailsView1.FindControl("Label5"), Label)
        lb.Text = email



        If HttpContext.Current.User.Identity.IsAuthenticated Then

            Label1.Text = String.Format("Welcome Back {0}", HttpContext.Current.User.Identity.Name)

        End If


    End Sub


End Class
