﻿
Imports Team126DB
Imports Team126DBTableAdapters
Partial Class SecureRecruiter_recruiterJobPost
    Inherits System.Web.UI.Page

    Private Sub GridView1_RowDeleting(sender As Object, e As GridViewDeleteEventArgs) Handles GridView1.RowDeleting

        Dim title As String = e.Values("title").ToString
        Dim description As String = e.Values("description").ToString
        Dim department As String = e.Values("department").ToString

        Dim aTable As getJobByTitleDescriptionDataTable




        Using aAdapter As New tbJobsAppliedTableAdapter

            Using bAdapter As New getJobByTitleDescriptionTableAdapterTableAdapter

                aTable = bAdapter.getJobsPostedbytitle(title, description, department)


                For Each row As Object In aTable.Rows
                    Dim jobid1 As Long
                    jobid1 = DirectCast(row, getJobByTitleDescriptionRow).jobid
                    aAdapter.deleteJobsApplied(jobid1)
                Next row







            End Using

        End Using


    End Sub

    Private Sub SecureRecruiter_recruiterJobPost_Load(sender As Object, e As EventArgs) Handles Me.Load, GridView1.Load
        If HttpContext.Current.User.Identity.IsAuthenticated Then

            Label1.Text = String.Format("Welcome Back {0}", HttpContext.Current.User.Identity.Name)

        End If
    End Sub




End Class
