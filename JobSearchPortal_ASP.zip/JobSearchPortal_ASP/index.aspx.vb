﻿Option Strict On
Imports Team126DB
Imports Team126DBTableAdapters
Partial Class index
    Inherits System.Web.UI.Page

    Private Sub Login1_Authenticate(sender As Object, e As AuthenticateEventArgs) Handles Login1.Authenticate


        Using aAdapter As New tbRecruiterTableAdapter
            Dim aTable As tbRecruiterDataTable
            aTable = aAdapter.GetDataByCredentials(Login1.UserName, Login1.Password)


            If aTable.Rows.Count = 1 Then
                Dim emailid As String = Convert.ToString(aTable.Rows(0).Item("emailid"))
                Dim name As String = Convert.ToString(aTable.Rows(0).Item("name"))
                Dim userrole As String = Convert.ToString(aTable.Rows(0).Item("userrole"))

                Session.Add("emailid", emailid)
                Session.Add("userrole", userrole)

                Session.Add("name", name)


                If Request.QueryString("ReturnURL") <> String.Empty Then
                    FormsAuthentication.RedirectFromLoginPage(name, False)
                Else
                    FormsAuthentication.SetAuthCookie(name, False)
                    Response.Redirect("~/SecureRecruiter/recruiterJobPost.aspx")
                End If


            End If

        End Using


    End Sub

    Private Sub Login2_Authenticate(sender As Object, e As AuthenticateEventArgs) Handles Login2.Authenticate


        Using aAdapter As New tbSeekerTableAdapter
            Dim aTable As tbSeekerDataTable
            aTable = aAdapter.GetDataByCredentials(Login2.UserName, Login2.Password)


            If aTable.Rows.Count = 1 Then
                Dim emailid1 As String = Convert.ToString(aTable.Rows(0).Item("emailid"))
                Dim name1 As String = Convert.ToString(aTable.Rows(0).Item("name"))
                Dim userrole1 As String = Convert.ToString(aTable.Rows(0).Item("userrole"))

                Session.Add("emailid1", emailid1)
                Session.Add("userrole1", userrole1)

                Session.Add("name1", name1)


                If Request.QueryString("ReturnURL") <> String.Empty Then
                    FormsAuthentication.RedirectFromLoginPage(name1, False)
                Else
                    FormsAuthentication.SetAuthCookie(name1, False)
                    Response.Redirect("~/SecureSeeker/seekerJobSearch.aspx")
                End If


            End If

        End Using


    End Sub
End Class
