﻿
Partial Class registerSeeker
    Inherits System.Web.UI.Page

End Class
