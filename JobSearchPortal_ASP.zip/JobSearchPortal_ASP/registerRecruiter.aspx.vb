﻿Option Strict On
Partial Class registerRecruiter
    Inherits System.Web.UI.Page


End Class
